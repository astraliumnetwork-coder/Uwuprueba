# Control Comercial · Cotizaciones integradas

SaaS de ventas, inventario y resultados. Frontend React + TypeScript + Vite conectado directamente a Supabase Auth y Postgres. La API Express y las conexiones PostgreSQL privadas ya no forman parte del arranque.

## Iniciar

Requisitos: Node.js 22.12 o superior y el proyecto Supabase configurado en `.env.example`.

```powershell
npm install
npm run dev
```

Si el equipo no permite instalar paquetes, `npm run dev` abre la versión precompilada de `dist/` con un servidor basado solo en Node.js. En ese modo funciona como vista previa: no recompila cambios de TypeScript/React. Para editar y recompilar el código fuente se necesitan las dependencias, que pueden instalarse en otro equipo con acceso y copiarse junto con el proyecto; para usar el sistema basta con llevar el ZIP que incluye `dist/`.

El ZIP incluye `.env` con la URL y la clave publicable del proyecto Supabase. Si falta, en PowerShell ejecuta `Copy-Item .env.example .env`. Las variables deben usar el prefijo `VITE_`, porque el cliente está hecho con Vite.

Accede con la cuenta existente **admin@sistema.com** y la contraseña configurada. No necesitas crear otra empresa ni ejecutar `setup:admin` nuevamente: los productos están en Supabase y se comparten entre equipos al entrar con la misma cuenta.

Para activar códigos PED automáticos, ejecuta **`supabase/order_codes.sql`** en Supabase → SQL Editor. Es reejecutable; los historiales funcionan también sin esa migración. No ejecutes el esquema completo sobre tu base existente. Antes de desplegar esta versión ejecuta `supabase/inventory_management.sql`: habilita el catálogo ordenable por stock y el borrado con historial conservado.

Incluye los logos del cotizador recibido, separados en public/quote-assets, y su logo REYPRO como respaldo del sidebar.

`.env` solo contiene `VITE_APP_NAME`, `VITE_SUPABASE_URL` y `VITE_SUPABASE_PUBLISHABLE_KEY`. La clave publicable está diseñada para el cliente web; RLS protege las tablas. No agregues una `service_role` al frontend.

## Funciones

- Login con Supabase Auth y cuenta vinculada a la empresa existente.
- Tenant derivado de `auth.uid()` en políticas RLS; el cliente nunca decide su tenant como autorización.
- Catálogo paginado, edición y existencias separadas para menudeo y pedidos.
- Ventas, entregas de pedidos, ajustes de stock y gastos atómicos mediante funciones SQL.
- Claves de idempotencia en mutaciones con efecto financiero o de inventario.
- Reportes diarios y por rango agrupados en PostgreSQL, en PEN y zona horaria America/Lima.

## Estructura

| Ruta                     | Responsabilidad                                                  |
| ------------------------ | ---------------------------------------------------------------- |
| `src/features`           | Pantallas, hooks y repositorios por módulo                       |
| `src/shared/supabase`    | Cliente Supabase y normalización de errores                      |
| `packages/domain`        | Esquemas, tipos, dinero y fechas compartidos                     |
| `supabase/schema.sql`    | Tablas, índices, RLS, trigger de alta y operaciones SQL          |
| `tests`                  | Reglas de dominio y pruebas del esquema/transacciones con PGlite |
| `docs/PROJECT_MEMORY.md` | Decisiones vigentes y punto de continuación                      |

Las vistas usan React Query. Las consultas llevan el signal de cancelación; la caché se segmenta por tenant y se limpia al cerrar sesión. Las lecturas se paginan en Supabase. Las operaciones que modifican varias tablas usan funciones SQL para que stock, auditoría y documentos se confirmen juntos o se reviertan juntos.

## Validar

```bash
npm run check
npm run build
```

El proyecto no requiere Docker, PostgreSQL local, `DATABASE_URL`, certificados ni servidor API para desarrollo. El esquema SQL se instala desde el editor de Supabase; después, solo se actualiza cuando se agregan cambios de base de datos.

## Reglas operativas

- Importes en céntimos enteros; ventas guardan el nombre, costo y precio utilizados.
- Un pedido pendiente no reserva stock ni cuenta como ingreso. Entregar valida y descuenta stock en una sola transacción.
- El resultado operativo simplificado es venta menos costo de mercadería y gastos registrados; no es un estado contable certificado.
- El proyecto no carga las cifras del Excel histórico. El archivo original no está disponible y el MD contiene una discrepancia en la utilidad declarada.

## Productos y códigos internos

Ejecuta una vez **`supabase/product_codes.sql`** en SQL Editor para una base existente. Convierte códigos `EXCEL-*` a `PRD-000001` sin modificar identificadores, stock ni ventas vinculadas. Nuevos productos reciben código automáticamente. El esquema completo se usa solo en bases nuevas.

Alta, edición y ajuste de stock se abren en modales. La tabla muestra precio, costo, utilidad/margen, existencias por canal. La carga del catálogo Excel ya fue utilizada y se retiró de la interfaz.

La auditoría del archivo original sigue en `docs/excel/LEEME.md`. Las ventas históricas no se importaron automáticamente.

## Inventario y edición

Buscador único por nombre o código, filtro de existencias y 10/25/50 artículos por página. Orden mediante flechas en Código, Producto, Menudeo y Pedidos; en móvil controles equivalentes sobre las tarjetas. Por defecto código PRD descendente (últimos asignados). Se aplican en Supabase antes de paginar.

Al crear o editar se conservan los filtros y la página y aparece un aviso durante cuatro segundos. El menú Acciones contiene Editar, Ajustar stock y Borrar. Borrar retira del catálogo sin destruir ventas o movimientos históricos; requiere stock cero y ningún pedido pendiente.

Para trabajar desde otro equipo con dependencias instaladas, extrae el ZIP y ejecuta `npm run dev`. Si no puedes instalarlas, extrae igualmente el ZIP completo y usa `npm run dev`: abrirá `dist/` como vista previa. La carpeta `dist/` se incluye en el ZIP y en el repositorio para este modo. Para Vercel usa las mismas variables VITE_ y conserva `vercel.json`.

## Cotizaciones dentro de Pedidos

Ejecuta **supabase/quotations.sql** antes de desplegar esta actualización. Nuevo pedido abre el cotizador con REYPRO/JUFLEX/BETMIN, PDF/Excel, historial, duplicados, catálogo compartido y artículos manuales. Generar pedido pide confirmación y crea un pedido pendiente sin descontar stock. Se conserva Pedido directo.

El ZIP incluye el código y la carpeta dist ya compilada para Netlify. No necesitas instalar npm para subir dist. Instrucciones completas: **docs/COTIZACIONES.md**. El histórico de la base antigua del cotizador no se migró automáticamente.
