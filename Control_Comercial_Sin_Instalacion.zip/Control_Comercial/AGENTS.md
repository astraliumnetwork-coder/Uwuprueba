# Reglas del proyecto

Aplicar la skill principal `arquitecto-saas-erp` y, al editar código, `entregar-codigo-completo`. Leer primero `docs/PROJECT_MEMORY.md`, `docs/REQUISITOS.md` y los archivos actuales del módulo afectado.

- Conservar TypeScript estricto, módulos por funcionalidad y contratos en `packages/domain`.
- Obtener tenant y actor desde Supabase Auth. Mantener RLS y claves foráneas compuestas; nunca aceptar un tenant del cliente como autorización.
- Mantener dinero en céntimos enteros y validar límites. No recalcular operaciones históricas desde precios actuales del catálogo.
- Hacer ventas, entregas y cambios de stock en una transacción; conservar idempotencia y auditoría.
- Menudeo y pedidos tienen stock independiente. Los pedidos pendientes no reservan stock y se contabilizan al entregar. No cambiar estas decisiones sin documentarlo.
- Mantener frontend → hooks → repositorios → Supabase. Las escrituras que afectan varias tablas deben ser RPC SQL atómicas. No añadir consultas a páginas.
- Ejecutar `npm run check` y `npm run build`; añadir pruebas cuando el cambio afecte dinero, stock, autorización o concurrencia.
- Antes de finalizar cada trabajo, actualizar PROJECT_MEMORY.md con cambios, verificaciones reales, pendientes y siguiente punto de entrada. Guardar la entrega vigente sin perder su identidad persistente.
- No afirmar memoria permanente automática, certificación contable, importación del Excel original o validaciones que no se ejecutaron.
