# Mantenimiento

Leer `PROJECT_MEMORY.md` y `AGENTS.md` antes de modificar el proyecto.

| Síntoma                    | Revisión                                                                                          |
| -------------------------- | ------------------------------------------------------------------------------------------------- |
| Vite falla al iniciar      | Node 22.12+ y dependencias (`npm install`)                                                        |
| Error de configuración     | `VITE_SUPABASE_URL` y `VITE_SUPABASE_PUBLISHABLE_KEY` en `.env`                                   |
| Tabla/RPC no existe        | Ejecutar inicialmente `supabase/schema.sql` en Supabase SQL Editor                                |
| Registro falla             | Auth habilitado, correo confirmado si corresponde y `organization_name` enviado por el formulario |
| Error RLS                  | Revisar `current_tenant_id()`, perfil en `public.users` y política de la tabla; no desactivar RLS |
| Stock insuficiente         | Revisar existencias del canal; RPC revierte la operación completa                                 |
| Importe incorrecto         | Revisar contratos de `packages/domain`, snapshot de `sale_items` y función SQL `get_report`       |
| Datos antiguos en pantalla | Revisar query keys/invalidation del hook; no duplicar estado local                                |

## Base de datos

La instalación inicial se realiza pegando `supabase/schema.sql` en SQL Editor. Para cambios posteriores, crear migraciones SQL incrementales; no sobrescribir datos ni volver a instalar el esquema en una base ya usada. Las operaciones con varias escrituras deben permanecer dentro de un RPC probado como transacción.

## Validación

Antes de entregar, ejecutar `npm run check` y `npm run build`. La suite PGlite prueba RLS, aislamiento entre tenants, idempotencia, stock, rollback de venta y agregación de reportes. PGlite no demuestra comportamiento de concurrencia entre conexiones reales ni reemplaza una comprobación en el proyecto Supabase.

No guardar claves privadas ni tokens en el repositorio. La publishable key puede estar en el frontend; las políticas RLS son la barrera de autorización. No incluir `service_role` en `VITE_*`.
