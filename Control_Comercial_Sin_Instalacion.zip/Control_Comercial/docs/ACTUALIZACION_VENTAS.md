# Ventas y cotizaciones

1. En Supabase → SQL Editor, ejecuta el archivo completo `supabase/cancel_sales.sql`. Es incremental y se puede repetir; conserva ventas, productos y usuarios. No ejecutes `schema.sql` sobre tu proyecto existente.
2. Publica el contenido de `dist` o actualiza el código de `proyecto` y compila.
3. Menudeo o historial de pedidos → Anular → indicar motivo → Confirmar anulación. El registro queda Anulado; si ya estaba contabilizado vuelve el stock al mismo canal y deja de sumar en resultados. Si estaba pendiente no modifica stock.
4. Nueva venta → agregar producto → Detalle → Precio de venta S/: escribe75 si el precio de catálogo es80. La referencia del catálogo y la rebaja se muestran debajo; al confirmar se guarda75 y se conserva el costo.
5. Cotización: modal de escritorio reducido a máximo1280px.

Anular es una reversión completa del registro y las existencias, no un reembolso bancario ni una devolución parcial. El precio negociado se establece antes de confirmar; los documentos históricos conservan su precio registrado.

La migración se validó en PostgreSQL embebido PGlite. No se aplicó al Supabase remoto desde esta entrega ni se probaron carreras con conexiones independientes.
