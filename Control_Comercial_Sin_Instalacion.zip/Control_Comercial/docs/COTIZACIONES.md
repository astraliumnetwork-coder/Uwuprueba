# Cotizaciones integradas en Pedidos

## Instalar esta actualización

1. En el proyecto Supabase del ERP, abre SQL Editor y ejecuta **supabase/quotations.sql**. Es reejecutable y conserva productos, ventas y pedidos actuales. No ejecutes schema.sql sobre una base existente.
2. Para Netlify, sube la carpeta dist del ZIP a Deploys de tu sitio existente. Para Vercel, actualiza el repositorio y conserva las variables VITE_ del ERP.
3. Inicia sesión con tu cuenta actual. No necesitas crear otra cuenta ni usar las credenciales del cotizador separado.

## Operación

- Pedidos → Nuevo pedido abre el cotizador. Pedido directo conserva el formulario rápido anterior.
- Selecciona REYPRO, JUFLEX o BETMIN; ingresa cliente, RUC opcional y dirección.
- Busca productos por nombre o código en el catálogo del ERP, o agrega artículos manuales. Las tallas y colores aparecen en la descripción al seleccionar el artículo.
- Cantidad, descripción, precio y costo interno son editables. El costo nunca aparece en el documento del cliente.
- Los precios se consideran finales. Si marcas IGV, se descompone el precio incluido usando el redondeo por unidad del cotizador original. No se suma 18% encima del precio ingresado. El costo interno debe registrarse con el criterio que uses en el ERP.
- Guardar asigna un número automático por empresa emisora y tenant. El correlativo se genera en servidor para evitar colisiones entre equipos.
- PDF y Excel guardan primero la cotización. Se conservan las tres plantillas, logos, datos y cuentas de los archivos originales; revisa que esos datos comerciales sigan vigentes antes de enviar propuestas.
- Duplicar abre una copia independiente; selecciona otra empresa y guarda. El documento original permanece intacto. Si cambias la empresa de una cotización existente, el editor crea una copia al guardar.
- Generar pedido guarda la propuesta, pide pago y fecha de entrega, y crea un pedido pendiente. Reintentar la misma conversión devuelve el pedido ya creado.
- Los artículos manuales se incorporan al catálogo al generar el pedido, con precio y costo indicados, y stock cero en ambos canales. Carga su stock de Pedidos antes de entregar.
- Una propuesta convertida queda bloqueada para editar. Usa Duplicar para reformularla. No se generan varios pedidos desde la misma propuesta; una copia sí puede generar otro.
- Las cotizaciones no descuentan stock ni aparecen como ingresos. La conversión conserva el importe final cotizado. La entrega sigue las reglas del ERP: valida y descuenta stock de Pedidos y contabiliza.

## Historial e importación

Pedidos tiene pestañas Cotizaciones e Historial de pedidos. El historial de cotizaciones permite buscar cliente, filtrar empresa, abrir, exportar, duplicar, retirar propuestas no convertidas y ver el pedido vinculado.

El borrador nuevo se conserva en este navegador por tenant. El historial guardado está en Supabase y se comparte entre equipos de la misma empresa. Las propuestas ya guardadas no dependen del borrador local.

Pegar artículos admite columnas separadas por tabulaciones o punto y coma: Producto, Cantidad, Precio y Costo opcional. También admite el bloque de filas numeradas del formato anterior. PDF y Excel importan renglones reconocibles para revisión; un PDF escaneado no tiene texto y necesita OCR externo. Máximo 15 MB, 50 páginas y 100 artículos. Si no se reconoce, copia y pega las filas. Un archivo externo no ofrece siempre costos ni asociación al inventario: se marca como artículo manual y el costo inicial es cero; revisa todo antes de guardar.

El histórico del cotizador separado **no se copia automáticamente**: usa otra base de datos y sus productos tienen identificadores diferentes. La integración no modifica esa base. Esta entrega incorpora las funciones y plantillas; una migración histórica exige exportar y mapear esos registros de forma explícita.

## Estructura y reglas técnicas

`src/features/quotes`: contratos con Zod, API Supabase, hooks, editor, historial, importación y exportación. PDF/Excel y lector PDF se cargan bajo demanda; el worker PDF se empaqueta localmente, sin depender de un CDN. Logos en `public/quote-assets`, separados del sidebar.

`supabase/quotations.sql`: tablas aisladas por tenant, RLS de lectura, permisos de escritura solo RPC, contador por empresa, guardado idempotente con bloqueo y comparación de versión, conversión atómica y archivo lógico. Las líneas usan instantáneas de precios, costos y descripción. No se confía en totales ni tenant enviados desde el navegador.

La cotización y su IGV no sustituyen facturación electrónica ni convierten los reportes simplificados del ERP en contabilidad tributaria. No se modificaron los reportes para separar IGV de ventas.

La revisión de geometría en dispositivos reales y la ejecución del SQL en Supabase remoto quedan pendientes. Las verificaciones locales se registran en PROJECT_MEMORY.md.

## Diseño del editor

Datos del cliente, productos y revisión se distinguen con secciones e iconos. Los campos muestran ejemplos y las acciones incluyen ayudas al pasar el cursor. Guardar conserva una cotización; PDF/Excel guardan y descargan; Generar pedido abre confirmación de pago y entrega. El resumen y las acciones permanecen visibles mientras se recorre el formulario. Este rediseño no requiere SQL adicional si quotations.sql ya fue instalado.

## Editor compacto vigente

En PC se usa casi toda la pantalla. Cliente, empresa, RUC, dirección y fecha comparten fila; inventario y detalle se paginan según el alto disponible para evitar desplazar el modal. En móvil se permite desplazamiento vertical y se conservan los botones al pie. El detalle solo muestra precio de venta; los costos existentes siguen guardados internamente. Esta actualización visual no necesita ejecutar SQL adicional.

## Detalles y documentos (actualización vigente)

En Cotizaciones, utiliza Detalles para consultar cliente, artículos, precios y totales. Duplicar está dentro del modal y abre una copia editable independiente. Editar mantiene disponible el editor para propuestas no convertidas. Las propuestas convertidas abren el detalle del pedido con su pago, entrega y estado. Los pedidos directos también tienen documentos basados en sus datos reales; campos no registrados se muestran como tales.

Exportar PDF abre el selector REYPRO/JUFLEX/BETMIN. Pulsa Mostrar PDF para revisar la plantilla y Descargar PDF para obtener el archivo. La vista previa usa PDF.js y canvas adaptable, con páginas y fuentes locales. Excel descarga el archivo con la plantilla seleccionada; inicialmente usa la del documento. El selector cambia la empresa emisora en el archivo exportado, sin cambiar los datos guardados. Los pedidos se identifican como PEDIDO con su código real, y las cotizaciones conservan su número. Los costos y la utilidad internos no se exportan.

El proyecto añade buffer para compatibilidad de los logos PNG de react-pdf en navegador. Si usas el código fuente, instala las dependencias de package-lock.json. El dist incluido ya está compilado y listo para publicar. Sin SQL adicional.
