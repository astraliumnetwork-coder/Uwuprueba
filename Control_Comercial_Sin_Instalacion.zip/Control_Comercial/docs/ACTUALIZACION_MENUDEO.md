# Menudeo simplificado

1. Abre Nueva venta e indica el cliente si lo necesitas y el método de pago.
2. Busca el producto y pulsa +. En móvil, pasa después a «2. Venta».
3. Ajusta Cantidad y escribe el Precio final que cobrarás por cada unidad.
4. Revisa el descuento automático y el Total a cobrar. Confirma la venta.

Ejemplo: el chaleco tiene precio de lista S/ 20 y se vende a S/ 18. Escribe 18 en Precio final. El descuento será S/ 2 por unidad; con dos chalecos cobrarás S/ 36 y el descuento total será S/ 4. El catálogo conserva S/ 20.

El costo no se edita al vender. La sección plegada Rentabilidad interna permite consultar el costo y la utilidad de la operación. Si necesitas volver al importe original, pulsa Usar precio de lista; se conserva la cantidad.

El modal mantiene la validación de existencias y los precios en céntimos. Un precio vacío o inválido no permite confirmar; precio cero y venta bajo costo siguen permitidos, con aviso de utilidad negativa. Los botones y el total permanecen visibles en móvil. Pedido directo y cotizaciones conservan sus flujos anteriores.

No necesita SQL ni nuevas dependencias. Publica el dist actualizado del ZIP o reemplaza los archivos del proyecto y compila.
