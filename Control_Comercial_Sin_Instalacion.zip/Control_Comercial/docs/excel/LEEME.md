# Base real del sistema: VENTAS SANDIA (1).xlsx

Fuente: Hoja1, filas 3–635. El archivo original no se modifica. `scripts/audit_sales_excel.py` permite regenerar la extracción desde el XLSX recibido, sin dependencias externas.

## Conciliación

| Métrica                                 |      Importe |
| --------------------------------------- | -----------: |
| Filas con artículo y valores numéricos  |          624 |
| Filas numéricas sin descripción (53–58) |            6 |
| Total de líneas de venta                |          630 |
| Venta original G                        | S/ 32,259.50 |
| Costo original H                        | S/ 24,267.40 |
| Utilidad original I de las ventas       |  S/ 7,992.10 |
| Venta recalculada D × E                 | S/ 32,259.50 |
| Costo recalculado D × F                 | S/ 24,263.40 |
| Utilidad recalculada                    |  S/ 7,996.10 |

Las filas 633–635 contienen solo 283, 0.5 y 141.5 en I. Suman S/ 425; agregarlas a la utilidad de ventas produce S/ 8,417.10. No tienen artículo, cantidad ni costo para tratarlas como ventas. No se deduce su finalidad.

En la fila 590, 4 × S/ 5.50 = S/ 22; H registra S/ 26 e I registra S/ 22. Se conserva la diferencia sin corregir el histórico automáticamente. La utilidad recalculada de esa línea es S/ 26.

Hay 44 líneas sin fecha resoluble después de marcadores como “sabado” y “viernes”; no se convierte un día de semana en una fecha inventada. También hay bloques con fechas anteriores a las previas (incluida una fecha de marzo dentro de abril): se marcan para revisión. La fecha explícita se propaga hacia las filas siguientes hasta otro marcador relevante.

Los pagos se leen en A y B; 622 de las 630 líneas no tienen un método explícito. No se asume efectivo ni se propaga Yape a otras ventas. No se identifica una cuenta bancaria ni el canal menudeo/pedidos en el archivo; esos datos quedan sin asignar.

## Archivos de revisión

- `ventas_normalizadas.csv`: 630 líneas, fila de origen, fecha, cantidad, precio/costo en céntimos, importes originales y recalculados, pago identificado y observaciones. Vacío significa dato no identificado; cero es un importe real.
- `auditoria.json`: totales, filas con incidencias y valores de cierre, para conciliación técnica.

## Catálogo precargable (etapa anterior)

La carga ya fue utilizada. El botón se retiró; la interfaz actual utiliza códigos internos generados automáticamente. Ejecutar `supabase/product_codes.sql` para convertir los códigos existentes. La siguiente descripción documenta el proceso previo, no una opción actualmente visible.

En **Productos → Catálogo del Excel**, buscar y seleccionar artículos; luego cargar la selección. Se crean en Supabase para el tenant autenticado, sin modificar productos ya existentes con el mismo código. La transacción es atómica; repetir la carga omite códigos existentes. Si otra operación usa simultáneamente el mismo código, puede fallar la carga completa sin crear un lote parcial.

Se obtuvieron 337 nombres distintos tras normalizar espacios y mayúsculas. No se fusionan abreviaturas, tallas o nombres similares: “masca”, “mascarilla” u otras variantes requieren revisión humana. Los códigos EXCEL usan la primera fila del artículo; el precio y costo de referencia proceden de su última aparición en el orden del archivo, que no necesariamente es la fecha más reciente.

Los importes de 2021 son referencias editables, no precios actuales. El stock inicial es cero; registrar el conteo físico por canal antes de vender. La carga no crea ventas históricas, gastos ni cobros y no aumenta la utilidad actual.

## Instalación

Para una base existente, ejecutar una vez `supabase/excel_catalog.sql` en SQL Editor. No volver a ejecutar el esquema completo. Para una base nueva, `schema.sql` ya incluye esta función.

## Cobertura del requerimiento

| Requerimiento                     | Implementación                                                        |
| --------------------------------- | --------------------------------------------------------------------- |
| Fecha y hora automáticas          | RPC de ventas con timestamp del servidor y fecha de reporte Lima      |
| Artículo, cantidad, venta y costo | Compositor de venta y pedido, con snapshots históricos                |
| Total venta, costo y utilidad     | Cálculos en céntimos en formulario y servidor                         |
| Reportes diarios y semanales      | Resultados, botones Hoy/Esta semana y rango personalizado             |
| Costos operativos                 | Gastos por canal; resultado operativo = utilidad bruta − gastos       |
| Menudeo y pedidos separados       | Módulos, stock y reportes por canal; pedido contabilizado al entregar |
| Método de pago dedicado           | Efectivo, Yape, Plin y Transferencia; desglose en Resultados          |
| Dashboard                         | Utilidad de hoy y semana, resultado después de gastos                 |
| Catálogo de referencia del Excel  | Selección y carga a Supabase, revisión de precios y stock real        |

El archivo no permite reconstruir con certeza tickets de venta, fechas ambiguas, métodos ausentes, gastos operativos, cuentas bancarias o canales. Las 630 filas son líneas, no 630 tickets confirmados. Una eventual migración contable del histórico requiere resolver esos datos primero; los CSV no se importan como ventas activas.
