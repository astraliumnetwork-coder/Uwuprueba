# Cuenta compartida de administración

Correo: admin@sistema.com. Contraseña inicial solicitada: admin123.

1. Desde la raíz del proyecto ejecuta `npm run setup:admin` una sola vez en tu equipo.
2. Pega en la terminal la clave secret o service_role del mismo proyecto Supabase. Se solicita sin mostrarla ni guardarla. No uses la clave publicable y no envíes esta clave por chat ni la pongas en variables VITE_. La URL se lee del .env existente.
3. Elige la empresa que contiene tus productos: se muestran ID, cantidad exacta de productos y operaciones. El script crea/confirma la cuenta con la API administrativa oficial y vincula su perfil a esa empresa. No traslada ni elimina productos. Si ya existe, puede actualizar su contraseña, pero bloquea cambio de empresa si tiene operaciones registradas.
4. Sube el proyecto actualizado a Vercel y entra con las mismas credenciales en ambos sitios. Los dos deben usar el mismo VITE_SUPABASE_URL y VITE_SUPABASE_PUBLISHABLE_KEY.

El frontend no crea más usuarios anónimos ni empresas al abrirse. Las sesiones anónimas anteriores llevan a Iniciar sesión. RLS sigue aislando empresas. La contraseña no está embebida en el navegador: Supabase la valida. La clave administrativa solo se necesita para ejecutar el script local una vez; no se configura en Vercel.

Si Supabase rechaza admin123 por su política de contraseñas, el script mostrará el error real; no desactiva esa política. El aprovisionamiento no es una transacción global: ante un fallo puede haberse creado la cuenta; volver a ejecutar detecta la cuenta existente y permite completar los pasos.
