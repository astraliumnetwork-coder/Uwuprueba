# Documento de Análisis de Requerimientos: Sistema de Ventas y Control Financiero

## 1. Resumen del Proyecto

El cliente requiere la creación de un sistema de control financiero y de ventas basado en un modelo operativo utilizado durante la pandemia. El objetivo principal es migrar de un registro manual en Excel a un sistema automatizado que permita calcular utilidades en tiempo real, generar estados de resultados periódicos y separar las líneas de negocio.

---

## 2. Requerimientos Extraídos de los Audios

A partir de las notas de voz enviadas por el cliente, se han identificado las siguientes necesidades core para el nuevo sistema:

### A. Estructura de Registro Base

El sistema debe contar con un formulario o tabla de ingreso rápido que replique y mejore el orden de las siguientes columnas:

- Fecha de la transacción.
- Descripción del Artículo (Ej. EPPs).
- Cantidad vendida.
- Precio de Venta (unitario).
- Costo / Precio de Llegada (unitario).

### B. Automatización de Cálculos Financieros

El cliente solicita que el sistema elimine el cálculo manual realizando las siguientes operaciones por cada registro:

- **Total de Venta:** `Cantidad * Precio de Venta`
- **Total de Costo:** `Cantidad * Precio de Costo`
- **Utilidad Bruta (Ganancia):** `Total de Venta - Total de Costo`

### C. Reportes y Estados Financieros

Es vital que el sistema agrupe la información para generar balances automáticos.

- **Cortes temporales:** Capacidad de filtrar la utilidad y movimientos para obtener un "Estado de Ganancias y Pérdidas" **diario** y **semanal**.
- **Objetivo:** Evaluar al final del día si se cubrieron los costos operativos y mantener un orden estricto en el sistema financiero.

### D. Segmentación de Líneas de Negocio

Para evitar el cruce de información y mantener un control exacto del inventario y los ingresos, el sistema debe contar con dos módulos independientes:

1.  **Ventas al Menudeo:** Para ventas de mostrador o unidades sueltas.
2.  **Pedidos:** Para ventas al por mayor o despachos programados.

---

## 3. Auditoría del Archivo Excel (`VENTAS SANDIA.xlsx`)

El análisis del archivo histórico proporcionado por el cliente revela cómo operaba el negocio y cuáles son los puntos críticos a resolver en el nuevo desarrollo.

### Mapeo de la Estructura Actual

- **Columna A (Fechas y Pagos):** Contiene la fecha del día, pero solo se anota en la primera venta de la jornada. Las filas inferiores se dejan en blanco. Además, se usa esta misma columna para anotar métodos de pago (ej. "yape", "TRANSF").
- **Columna C (Artículos):** Nombres descriptivos de los productos (ej. capas, mamelucos, mascarillas KN, lentes).
- **Columnas D, E, F:** Cantidad, Precio Venta y Costo (Ingresados manualmente).
- **Columnas G, H, I:** Fórmulas de Total Venta, Total Costo y Utilidad.

### Resumen Histórico del Documento

Al consolidar la data del archivo, se obtienen las siguientes métricas de rendimiento de esa época (inicio en marzo 2021):

- **Total de Transacciones Registradas:** 624
- **Total de Ventas Acumuladas:** S/ 32,259.50
- **Costo Total de Mercadería:** S/ 24,267.40
- **Utilidad Bruta Generada:** S/ 8,417.10

### Limitaciones del Formato Anterior (El "Dolor" del Cliente)

La práctica de agrupar visualmente las ventas dejando la columna de fecha en blanco bajo un mismo día impide hacer tablas dinámicas o sumas automáticas rápidas. Para saber cuánto se ganó en un día, el cliente tenía que seleccionar y sumar las celdas manualmente.

---

## 4. Propuestas de Mejora para el Nuevo Sistema

Basado en el análisis cruzado (Audios + Excel), el nuevo desarrollo deberá incluir las siguientes mejoras arquitectónicas:

1.  **Fechas Ancladas e Invisibles:** Cada venta registrada guardará automáticamente la fecha y hora en la base de datos (Timestamp), eliminando la necesidad de escribirla o de agrupar visualmente en bloques. Esto permitirá que el sistema sume el día completo con un solo clic.
2.  **Campo de Método de Pago Dedicado:** Se creará un menú desplegable (Yape, Plin, Efectivo, Transferencia) para no mezclar este dato con las fechas, permitiendo luego filtrar cuánto dinero entró por cada cuenta bancaria.
3.  **Dashboard (Panel de Control):** Una pantalla inicial que muestre automáticamente la suma de la **Utilidad de Hoy** y la **Utilidad de la Semana**.
4.  **Base de Datos de Productos:** En lugar de tipear "masca" o "mame", se sugiere un catálogo pre-cargado de artículos con su costo por defecto, para agilizar las ventas.
