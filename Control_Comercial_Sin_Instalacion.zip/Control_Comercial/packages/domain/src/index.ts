import { z } from 'zod';
export const channelSchema = z.enum(['retail', 'orders']);
export type Channel = z.infer<typeof channelSchema>;
export const paymentSchema = z.enum(['cash', 'yape', 'plin', 'transfer']);
export const paymentLabels = {
  cash: 'Efectivo',
  yape: 'Yape',
  plin: 'Plin',
  transfer: 'Transferencia',
};
export const channelLabels = { retail: 'Menudeo', orders: 'Pedidos' };
export const centsSchema = z.number().int().min(0).max(100_000_000);
export const integerSchema = z.number().int().safe();

export const productCategoryGroups = [
  {
    id: 'cabeza',
    category: 'Protección de cabeza',
    subcategories: [
      '3M',
      'Msa',
      'Deltaplus',
      'Libus',
      'Clute',
      'Masters',
      'Steelpro',
      'Tridente',
      'Suspensiones',
    ],
  },
  {
    id: 'manos',
    category: 'Protección de manos',
    subcategories: ['Segpro', 'Clute', 'Ansell', 'Steelpro', 'DeltaPlus', 'KleenGuard', 'Tecseg'],
  },
  {
    id: 'pies',
    category: 'Calzado industrial',
    subcategories: [
      'Botines de seguridad',
      'Botines dieléctricos',
      'Botas de PVC',
      'Botas de jebe',
      'Calzado para dama',
    ],
  },
  {
    id: 'altura',
    category: 'Protección en altura',
    subcategories: ['Arnes', 'Línea de vida', 'Conectores'],
  },
  {
    id: 'ojos',
    category: 'Protección visual',
    subcategories: [
      'Antiparra',
      'Lentes 3M',
      'Lentes Clute',
      'Lentes de Malla',
      'Lentes Libus',
      'Lentes MSA',
      'Lentes Spro',
      'Lentes Steelpro',
    ],
  },
  {
    id: 'facial',
    category: 'Protección Facial',
    subcategories: ['Protección Facial'],
  },
  {
    id: 'oidos',
    category: 'Protección auditiva',
    subcategories: ['Orejeras 3M', 'Orejeras MSA', 'Tapones Auditivos'],
  },
  {
    id: 'senal',
    category: 'Señalización',
    subcategories: [
      'Barra Retráctil',
      'Cintas Antideslizantes',
      'Cintas Reflectivas',
      'Conos de Seguridad',
      'Mallas de Seguridad',
    ],
  },
  {
    id: 'solar',
    category: 'Protección Solar',
    subcategories: [
      'Bloqueador Solar 3M',
      'Bloqueador Bahia',
      'Bloqueador Palmera Sun',
      'Bloqueador Sugar Sun',
    ],
  },
  {
    id: 'respiratoria',
    category: 'Protección Respiratoria',
    subcategories: [
      'Cartuchos 3M',
      'Filtros 3M',
      'Máscara Full Face',
      'Mascarillas',
      'Respiradores',
    ],
  },
  {
    id: 'corporal',
    category: 'Ropa de Trabajo',
    subcategories: ['Abrigos', 'Corta vientos'],
  },
] as const;

export const productCategories = [
  'Protección de cabeza',
  'Protección de manos',
  'Calzado industrial',
  'Protección en altura',
  'Protección visual',
  'Protección Facial',
  'Protección auditiva',
  'Señalización',
  'Protección Solar',
  'Protección Respiratoria',
  'Ropa de Trabajo',
] as const;
export type ProductCategory = (typeof productCategories)[number];

export const productCategoryOptions = productCategoryGroups.map((group) => ({
  id: group.id,
  value: group.category,
  label: group.category,
  subcategories: group.subcategories,
}));

export function getSubcategoriesForCategory(category?: string | null): readonly string[] {
  const clean = normalizeProductCategory(category);
  const found = productCategoryGroups.find(
    (g) => g.category.toLowerCase() === clean.toLowerCase() || g.id === clean.toLowerCase(),
  );
  return found ? found.subcategories : [];
}

export const productColors = [
  'Negro',
  'Blanco',
  'Azul',
  'Amarillo',
  'Naranja',
  'Rojo',
  'Verde',
  'Verde Fosforescente',
  'Plomo',
  'Gris',
  'Marrón',
  'Beige',
  'Celeste',
] as const;
export type ProductColor = (typeof productColors)[number];

const CATEGORY_ALIAS_MAP: Record<string, ProductCategory> = {
  cabeza: 'Protección de cabeza',
  'proteccion de cabeza': 'Protección de cabeza',
  'protección de cabeza': 'Protección de cabeza',
  casco: 'Protección de cabeza',
  cascos: 'Protección de cabeza',
  'cascos y caretas': 'Protección de cabeza',
  manos: 'Protección de manos',
  'proteccion de manos': 'Protección de manos',
  'protección de manos': 'Protección de manos',
  guante: 'Protección de manos',
  guantes: 'Protección de manos',
  pies: 'Calzado industrial',
  calzado: 'Calzado industrial',
  calzados: 'Calzado industrial',
  'calzado industrial': 'Calzado industrial',
  'calzado (botas, botines y zapatos)': 'Calzado industrial',
  bota: 'Calzado industrial',
  botas: 'Calzado industrial',
  botin: 'Calzado industrial',
  botín: 'Calzado industrial',
  botines: 'Calzado industrial',
  zapato: 'Calzado industrial',
  zapatos: 'Calzado industrial',
  zapatilla: 'Calzado industrial',
  zapatillas: 'Calzado industrial',
  altura: 'Protección en altura',
  'proteccion en altura': 'Protección en altura',
  'protección en altura': 'Protección en altura',
  arnes: 'Protección en altura',
  arnés: 'Protección en altura',
  ojos: 'Protección visual',
  'proteccion visual': 'Protección visual',
  'protección visual': 'Protección visual',
  lentes: 'Protección visual',
  'lentes y auditivos': 'Protección visual',
  facial: 'Protección Facial',
  'proteccion facial': 'Protección Facial',
  'protección facial': 'Protección Facial',
  careta: 'Protección Facial',
  caretas: 'Protección Facial',
  oidos: 'Protección auditiva',
  oídos: 'Protección auditiva',
  'proteccion auditiva': 'Protección auditiva',
  'protección auditiva': 'Protección auditiva',
  auditivos: 'Protección auditiva',
  orejeras: 'Protección auditiva',
  tapones: 'Protección auditiva',
  senal: 'Señalización',
  señal: 'Señalización',
  senalizacion: 'Señalización',
  señalización: 'Señalización',
  'seguridad y accesorios': 'Señalización',
  solar: 'Protección Solar',
  'proteccion solar': 'Protección Solar',
  'protección solar': 'Protección Solar',
  bloqueador: 'Protección Solar',
  respiratoria: 'Protección Respiratoria',
  'proteccion respiratoria': 'Protección Respiratoria',
  'protección respiratoria': 'Protección Respiratoria',
  respiradores: 'Protección Respiratoria',
  mascarillas: 'Protección Respiratoria',
  corporal: 'Ropa de Trabajo',
  ropa: 'Ropa de Trabajo',
  'ropa de trabajo': 'Ropa de Trabajo',
  'ropa e indumentaria': 'Ropa de Trabajo',
  indumentaria: 'Ropa de Trabajo',
  vestimenta: 'Ropa de Trabajo',
};

export const CATEGORY_KEYWORDS: ReadonlyArray<{
  category: ProductCategory;
  keywords: readonly string[];
}> = [
  {
    category: 'Calzado industrial',
    keywords: ['bota', 'botin', 'botín', 'zapat', 'borseg', 'borceg', 'calzado'],
  },
  {
    category: 'Protección de manos',
    keywords: [
      'guant',
      'showa',
      'cut5',
      'cut.5',
      'cut 5',
      'anticorte',
      'cueriq',
      'ansell',
      'segpro',
      'kleenguard',
      'tecseg',
    ],
  },
  {
    category: 'Protección de cabeza',
    keywords: [
      'casco',
      'semicasco',
      'toca',
      'barbiquejo',
      'suspension',
      'suspensión',
      'tridente',
      'masters',
    ],
  },
  {
    category: 'Protección Facial',
    keywords: ['careta', 'mica', 'facial', 'facil'],
  },
  {
    category: 'Protección visual',
    keywords: ['lent', 'antiparra'],
  },
  {
    category: 'Protección auditiva',
    keywords: ['orejera', 'tapon', 'tapón', 'auditiv'],
  },
  {
    category: 'Protección en altura',
    keywords: ['arnes', 'arnés', 'linea de vida', 'línea de vida', 'conector', 'mosqueton'],
  },
  {
    category: 'Protección Solar',
    keywords: ['bloqueador', 'solar', 'bahia', 'palmera sun', 'sugar sun'],
  },
  {
    category: 'Protección Respiratoria',
    keywords: [
      'respi',
      'masca',
      'kn95',
      'kn ',
      'cj kn',
      'filtro',
      'prefiltro',
      'cartucho',
      'full face',
      '5n11',
      '2097',
      '7093',
    ],
  },
  {
    category: 'Señalización',
    keywords: [
      'cachac',
      'bara',
      'vara',
      'barra retractil',
      'cadena',
      'cinta',
      'cono',
      'malla',
      'senal',
      'señal',
      'linterna',
      'botiquin',
      'porta herramienta',
      'extin',
    ],
  },
  {
    category: 'Ropa de Trabajo',
    keywords: [
      'mamelu',
      'capa',
      'capás',
      'capotin',
      'abrigo',
      'chalec',
      'panta',
      'camisa',
      'polo',
      'traje',
      'mandil',
      'corta viento',
      'cortaviento',
      'gorro',
      'gorra',
      'sombrero',
    ],
  },
];

export function normalizeProductCategory(raw?: string | null): string {
  const trimmed = (raw ?? '').trim();
  if (!trimmed) return '';
  const mapped = CATEGORY_ALIAS_MAP[trimmed.toLowerCase()];
  if (mapped) return mapped;
  const exact = productCategories.find((c) => c.toLowerCase() === trimmed.toLowerCase());
  return exact ?? trimmed;
}

export function normalizeProductSubcategory(raw?: string | null, category?: string | null): string {
  const trimmed = (raw ?? '').trim();
  if (!trimmed) return '';
  const subList = getSubcategoriesForCategory(category);
  const exactInCat = subList.find((s) => s.toLowerCase() === trimmed.toLowerCase());
  if (exactInCat) return exactInCat;
  for (const group of productCategoryGroups) {
    const match = group.subcategories.find((s) => s.toLowerCase() === trimmed.toLowerCase());
    if (match) return match;
  }
  return trimmed;
}

export function isFootwearCategory(category?: string | null, subcategory?: string | null): boolean {
  const cleanCat = (category ?? '').trim().toLowerCase();
  const cleanSub = (subcategory ?? '').trim().toLowerCase();
  if (!cleanCat && !cleanSub) return false;
  if (normalizeProductCategory(cleanCat) === 'Calzado industrial') return true;
  return CATEGORY_KEYWORDS[0]!.keywords.some(
    (kw) => cleanCat.includes(kw) || cleanSub.includes(kw),
  );
}

export function inferProductCategoryAndSubcategory(name?: string | null): {
  category: string;
  subcategory: string;
} {
  const lower = (name ?? '').trim().toLowerCase();
  if (!lower) return { category: '', subcategory: '' };

  // Inferencia directa de subcategorías conocidas
  if (lower.includes('bota') && lower.includes('jebe')) {
    return { category: 'Calzado industrial', subcategory: 'Botas de jebe' };
  }
  if (lower.includes('bota') && (lower.includes('pvc') || lower.includes('bla'))) {
    return { category: 'Calzado industrial', subcategory: 'Botas de PVC' };
  }
  if (
    lower.includes('dama') &&
    (lower.includes('zapat') || lower.includes('bota') || lower.includes('calzado'))
  ) {
    return { category: 'Calzado industrial', subcategory: 'Calzado para dama' };
  }
  if (lower.includes('dielectric') || lower.includes('dieléctric')) {
    return { category: 'Calzado industrial', subcategory: 'Botines dieléctricos' };
  }
  if (CATEGORY_KEYWORDS[0]!.keywords.some((kw) => lower.includes(kw))) {
    return { category: 'Calzado industrial', subcategory: 'Botines de seguridad' };
  }
  if (lower.includes('corta viento') || lower.includes('cortaviento')) {
    return { category: 'Ropa de Trabajo', subcategory: 'Corta vientos' };
  }
  if (
    lower.includes('capa') ||
    lower.includes('capotin') ||
    lower.includes('abrigo') ||
    lower.includes('mamelu') ||
    lower.includes('traje')
  ) {
    return { category: 'Ropa de Trabajo', subcategory: 'Abrigos' };
  }
  if (lower.includes('bara') || lower.includes('barra')) {
    return { category: 'Señalización', subcategory: 'Barra Retráctil' };
  }
  if (lower.includes('orejera')) {
    return {
      category: 'Protección auditiva',
      subcategory: lower.includes('msa') ? 'Orejeras MSA' : 'Orejeras 3M',
    };
  }
  if (lower.includes('tapon') || lower.includes('tapón')) {
    return { category: 'Protección auditiva', subcategory: 'Tapones Auditivos' };
  }
  if (lower.includes('antiparra')) {
    return { category: 'Protección visual', subcategory: 'Antiparra' };
  }
  if (lower.includes('lent')) {
    if (lower.includes('3m')) return { category: 'Protección visual', subcategory: 'Lentes 3M' };
    if (lower.includes('clute'))
      return { category: 'Protección visual', subcategory: 'Lentes Clute' };
    if (lower.includes('malla'))
      return { category: 'Protección visual', subcategory: 'Lentes de Malla' };
    if (lower.includes('libus'))
      return { category: 'Protección visual', subcategory: 'Lentes Libus' };
    if (lower.includes('msa')) return { category: 'Protección visual', subcategory: 'Lentes MSA' };
    if (lower.includes('steelpro'))
      return { category: 'Protección visual', subcategory: 'Lentes Steelpro' };
    return { category: 'Protección visual', subcategory: 'Lentes Clute' };
  }
  if (
    lower.includes('careta') ||
    lower.includes('mica') ||
    lower.includes('facial') ||
    lower.includes('facil')
  ) {
    return { category: 'Protección Facial', subcategory: 'Protección Facial' };
  }
  if (lower.includes('cartucho')) {
    return { category: 'Protección Respiratoria', subcategory: 'Cartuchos 3M' };
  }
  if (
    lower.includes('filtro') ||
    lower.includes('prefiltro') ||
    lower.includes('2097') ||
    lower.includes('7093') ||
    lower.includes('5n11')
  ) {
    return { category: 'Protección Respiratoria', subcategory: 'Filtros 3M' };
  }
  if (lower.includes('full face')) {
    return { category: 'Protección Respiratoria', subcategory: 'Máscara Full Face' };
  }
  if (
    lower.includes('masca') ||
    lower.includes('kn95') ||
    lower.includes('kn ') ||
    lower.includes('cj kn')
  ) {
    return { category: 'Protección Respiratoria', subcategory: 'Mascarillas' };
  }
  if (lower.includes('respi')) {
    return { category: 'Protección Respiratoria', subcategory: 'Respiradores' };
  }

  for (const entry of CATEGORY_KEYWORDS) {
    if (entry.keywords.some((kw) => lower.includes(kw))) {
      const subs = getSubcategoriesForCategory(entry.category);
      const matchedSub = subs.find((s) => lower.includes(s.toLowerCase())) ?? '';
      return { category: entry.category, subcategory: matchedSub };
    }
  }
  return { category: 'Ropa de Trabajo', subcategory: '' };
}

export function inferProductCategory(name?: string | null): string {
  return inferProductCategoryAndSubcategory(name).category;
}

export function normalizeProductColor(raw?: string | null): string {
  const trimmed = (raw ?? '').trim();
  if (!trimmed) return '';
  if (trimmed.includes(',')) {
    return trimmed
      .split(',')
      .map((part) => part.trim())
      .filter(Boolean)
      .join(', ');
  }
  return trimmed;
}

export const productColorSchema = z
  .string()
  .trim()
  .max(80)
  .default('')
  .transform((v) => normalizeProductColor(v));

export const productCategorySchema = z
  .string()
  .trim()
  .max(60)
  .default('')
  .transform((v) => normalizeProductCategory(v));

export const productSubcategorySchema = z
  .string()
  .trim()
  .max(60)
  .default('')
  .transform((v) => normalizeProductSubcategory(v));

export const productSizeOptions = [
  { value: 'S', label: 'S (Small)' },
  { value: 'M', label: 'M (Medium)' },
  { value: 'L', label: 'L (Large)' },
  { value: 'XL', label: 'XL (Extra Large)' },
  { value: 'XXL', label: 'XXL (2XL)' },
  { value: 'XXXL', label: 'XXXL (3XL)' },
] as const;

export const productSizes = ['S', 'M', 'L', 'XL', 'XXL', 'XXXL'] as const;
export type ProductSize = (typeof productSizes)[number];

export const bootSizes = [
  '35',
  '36',
  '37',
  '38',
  '39',
  '40',
  '41',
  '42',
  '43',
  '44',
  '45',
  '46',
] as const;
export type BootSize = (typeof bootSizes)[number];

export const bootSizeOptions = [
  { value: '35', label: 'Talla 35' },
  { value: '36', label: 'Talla 36' },
  { value: '37', label: 'Talla 37' },
  { value: '38', label: 'Talla 38' },
  { value: '39', label: 'Talla 39' },
  { value: '40', label: 'Talla 40' },
  { value: '41', label: 'Talla 41' },
  { value: '42', label: 'Talla 42' },
  { value: '43', label: 'Talla 43' },
  { value: '44', label: 'Talla 44' },
  { value: '45', label: 'Talla 45' },
  { value: '46', label: 'Talla 46' },
] as const;

export function getSizeOptionsForCategory(category?: string | null) {
  return isFootwearCategory(category) ? bootSizeOptions : productSizeOptions;
}

const LEGACY_SIZE_MAP: Record<string, string> = {
  small: 'S',
  's (small)': 'S',
  medium: 'M',
  'm (medium)': 'M',
  large: 'L',
  'l (large)': 'L',
  'extra large': 'XL',
  'xl (extra large)': 'XL',
  'xxl (2xl)': 'XXL',
  'xxxl (3xl)': 'XXXL',
};

export function normalizeProductSize(raw?: string | null): string {
  const trimmed = (raw ?? '').trim();
  if (!trimmed) return '';
  if (trimmed.includes(',')) {
    return trimmed
      .split(',')
      .map((part) => normalizeProductSize(part))
      .filter(Boolean)
      .join(', ');
  }
  const mapped = LEGACY_SIZE_MAP[trimmed.toLowerCase()];
  if (mapped) return mapped;
  const bootMatch = /^talla\s+(\d{2})$/i.exec(trimmed);
  if (bootMatch?.[1]) return bootMatch[1];
  const upper = trimmed.toUpperCase();
  if ((productSizes as readonly string[]).includes(upper)) return upper;
  return trimmed;
}

export const productSizeSchema = z
  .string()
  .trim()
  .max(60)
  .default('')
  .transform((v) => normalizeProductSize(v));

const SIZE_SUFFIX_PATTERN = /^(.*?)\s*·\s*Talla:\s*(.+)$/i;
const COLOR_SUFFIX_PATTERN = /^(.*?)\s*·\s*Color:\s*(.+)$/i;
const SUB_SUFFIX_PATTERN = /^(.*?)\s*·\s*Sub:\s*(.+)$/i;
const CAT_SUFFIX_PATTERN = /^(.*?)\s*·\s*Cat:\s*(.+)$/i;

export function splitProductMetadata(
  rawName: string,
  rawSize?: string | null,
  rawCategory?: string | null,
  rawColor?: string | null,
  inferFallback = false,
  rawSubcategory?: string | null,
): { name: string; size: string; category: string; subcategory: string; color: string } {
  let working = rawName.trim();
  let embeddedSize = '';
  let embeddedColor = '';
  let embeddedSubcategory = '';
  let embeddedCategory = '';

  const sizeMatch = SIZE_SUFFIX_PATTERN.exec(working);
  if (sizeMatch) {
    working = sizeMatch[1]?.trim() || working;
    embeddedSize = sizeMatch[2]?.trim() || '';
  }

  const colorMatch = COLOR_SUFFIX_PATTERN.exec(working);
  if (colorMatch) {
    working = colorMatch[1]?.trim() || working;
    embeddedColor = colorMatch[2]?.trim() || '';
  }

  const subMatch = SUB_SUFFIX_PATTERN.exec(working);
  if (subMatch) {
    working = subMatch[1]?.trim() || working;
    embeddedSubcategory = subMatch[2]?.trim() || '';
  }

  const catMatch = CAT_SUFFIX_PATTERN.exec(working);
  if (catMatch) {
    working = catMatch[1]?.trim() || working;
    const rawCatPart = catMatch[2]?.trim() || '';
    if (rawCatPart.includes('›')) {
      const [cPart = '', sPart = ''] = rawCatPart.split('›');
      embeddedCategory = cPart.trim();
      if (!embeddedSubcategory) embeddedSubcategory = sPart.trim();
    } else {
      embeddedCategory = rawCatPart;
    }
  }

  const explicitSize = (rawSize ?? '').trim();
  const explicitColor = (rawColor ?? '').trim();
  const explicitCategory = (rawCategory ?? '').trim();
  const explicitSubcategory = (rawSubcategory ?? '').trim();

  const resolvedCategory = normalizeProductCategory(explicitCategory || embeddedCategory);
  const resolvedSubcategory = normalizeProductSubcategory(
    explicitSubcategory || embeddedSubcategory,
    resolvedCategory,
  );

  const inferred =
    !resolvedCategory && inferFallback
      ? inferProductCategoryAndSubcategory(working)
      : { category: resolvedCategory, subcategory: resolvedSubcategory };

  return {
    name: working,
    size: normalizeProductSize(explicitSize || embeddedSize),
    color: normalizeProductColor(explicitColor || embeddedColor),
    category: resolvedCategory || inferred.category,
    subcategory: resolvedSubcategory || inferred.subcategory,
  };
}

export function splitProductNameAndSize(
  rawName: string,
  rawSize?: string | null,
): { name: string; size: string } {
  const { name, size } = splitProductMetadata(rawName, rawSize);
  return { name, size };
}

export function formatProductNameWithSize(
  name: string,
  size?: string | null,
  category?: string | null,
  color?: string | null,
  subcategory?: string | null,
): string {
  const { name: baseName } = splitProductMetadata(name);
  const cleanCategory = normalizeProductCategory(category);
  const cleanSubcategory = normalizeProductSubcategory(subcategory, cleanCategory);
  const cleanColor = normalizeProductColor(color);
  const cleanSize = normalizeProductSize(size);
  const catPart = cleanCategory ? ` · Cat: ${cleanCategory}` : '';
  const subPart = cleanSubcategory ? ` · Sub: ${cleanSubcategory}` : '';
  const colorPart = cleanColor ? ` · Color: ${cleanColor}` : '';
  const sizePart = cleanSize ? ` · Talla: ${cleanSize}` : '';
  const suffix = `${catPart}${subPart}${colorPart}${sizePart}`;
  if (!suffix) return baseName;
  const maxBase = Math.max(2, 120 - suffix.length);
  return `${baseName.slice(0, maxBase).trim()}${suffix}`;
}

export function parseMoney(value: string): number {
  if (!/^\d{1,7}(\.\d{1,2})?$/.test(value.trim()))
    throw new Error('Ingresa un monto positivo con máximo 2 decimales.');
  const [whole = '0', fraction = ''] = value.trim().split('.');
  return centsSchema.parse(Number(whole) * 100 + Number(fraction.padEnd(2, '0')));
}
export function money(cents: number): string {
  return new Intl.NumberFormat('es-PE', { style: 'currency', currency: 'PEN' }).format(cents / 100);
}
export function calculateLine(quantity: number, priceCents: number, costCents: number) {
  z.number().int().min(1).max(100_000).parse(quantity);
  centsSchema.parse(priceCents);
  centsSchema.parse(costCents);
  const salesCents = quantity * priceCents;
  const costTotalCents = quantity * costCents;
  return { salesCents, costTotalCents, grossCents: salesCents - costTotalCents };
}
export function localDate(now = new Date()): string {
  const parts = new Intl.DateTimeFormat('en-CA', {
    timeZone: 'America/Lima',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).formatToParts(now);
  const get = (type: string) => parts.find((p) => p.type === type)?.value;
  return `${get('year')}-${get('month')}-${get('day')}`;
}
export const dateSchema = z
  .string()
  .regex(/^\d{4}-\d{2}-\d{2}$/)
  .refine((value) => {
    const date = new Date(`${value}T12:00:00Z`);
    return !Number.isNaN(date.getTime()) && date.toISOString().slice(0, 10) === value;
  }, 'Fecha inválida');
export const productInput = z.object({
  sku: z.string().trim().min(1).max(40),
  category: productCategorySchema,
  subcategory: productSubcategorySchema,
  color: productColorSchema,
  name: z.string().trim().min(2).max(120),
  size: productSizeSchema,
  priceCents: centsSchema,
  costCents: centsSchema,
  retailStock: z.number().int().min(0).max(1_000_000),
  ordersStock: z.number().int().min(0).max(1_000_000),
});
export const productSchema = productInput.extend({ id: z.string().uuid(), active: z.boolean() });
export type Product = Omit<
  z.infer<typeof productSchema>,
  'category' | 'subcategory' | 'color' | 'size'
> & {
  category?: string | undefined;
  subcategory?: string | undefined;
  color?: string | undefined;
  size?: string | undefined;
};
export const itemInput = z.object({
  productId: z.string().uuid(),
  quantity: z.number().int().min(1).max(100_000),
  priceCents: centsSchema,
  costCents: centsSchema,
});
export const saleInput = z
  .object({
    channel: channelSchema,
    payment: paymentSchema,
    customer: z.string().trim().max(120).default(''),
    scheduledFor: dateSchema.nullable().default(null),
    items: z.array(itemInput).min(1).max(100),
  })
  .refine(
    (v) => new Set(v.items.map((i) => i.productId)).size === v.items.length,
    'Combina los productos repetidos en una sola línea',
  )
  .refine((v) => v.channel !== 'orders' || v.customer.length > 0, 'Indica el cliente del pedido');
export type SaleInput = z.infer<typeof saleInput>;
export const saleSchema = z.object({
  orderCode: z.string().nullable().optional(),
  id: z.string().uuid(),
  channel: channelSchema,
  payment: paymentSchema,
  customer: z.string(),
  scheduledFor: z.string().nullable(),
  createdAt: z.string(),
  recognizedAt: z.string().nullable(),
  status: z.enum(['pending', 'posted', 'cancelled']),
  salesCents: integerSchema,
  costTotalCents: integerSchema,
  grossCents: integerSchema,
});
export type Sale = z.infer<typeof saleSchema>;
export const itemSchema = itemInput.extend({
  name: z.string(),
  salesCents: integerSchema,
  costTotalCents: integerSchema,
  grossCents: integerSchema,
});
export const expenseInput = z.object({
  description: z.string().trim().min(2).max(160),
  amountCents: centsSchema.refine((v) => v > 0),
  spentOn: dateSchema,
  channel: channelSchema,
});
export const expenseSchema = expenseInput.extend({ id: z.string().uuid() });
export type Expense = z.infer<typeof expenseSchema>;
export function pageSchema<T extends z.ZodTypeAny>(schema: T) {
  return z.object({
    items: z.array(schema),
    total: z.number().int().nonnegative(),
    page: z.number().int().positive(),
    pageSize: z.number().int().positive(),
  });
}
export const sessionSchema = z.object({
  userId: z.string().uuid(),
  tenantId: z.string().uuid(),
  email: z.string().min(1),
  organizationName: z.string(),
});
export type Session = z.infer<typeof sessionSchema>;
export const credentialsSchema = z.object({
  email: z
    .string()
    .trim()
    .email()
    .max(254)
    .transform((v) => v.toLowerCase()),
  password: z.string().min(1, 'Escribe tu contraseña.').max(128),
});
export const registrationSchema = credentialsSchema.extend({
  password: z.string().min(12).max(128),
  organizationName: z.string().trim().min(2).max(80),
});
export const settingsSchema = z.object({
  organizationName: z.string().trim().min(2, 'Escribe al menos 2 caracteres.').max(80),
  currency: z.literal('PEN'),
  timezone: z.literal('America/Lima'),
});
export type WorkspaceSettings = z.infer<typeof settingsSchema>;
export const reportSchema = z.object({
  from: dateSchema,
  to: dateSchema,
  salesCents: integerSchema,
  costTotalCents: integerSchema,
  grossCents: integerSchema,
  expensesCents: integerSchema,
  netCents: integerSchema,
  transactions: integerSchema,
  byPayment: z.array(z.object({ payment: paymentSchema, salesCents: integerSchema })),
  daily: z.array(
    z.object({
      date: dateSchema,
      salesCents: integerSchema,
      costTotalCents: integerSchema,
      grossCents: integerSchema,
      expensesCents: integerSchema,
      netCents: integerSchema,
    }),
  ),
});
export type Report = z.infer<typeof reportSchema>;
