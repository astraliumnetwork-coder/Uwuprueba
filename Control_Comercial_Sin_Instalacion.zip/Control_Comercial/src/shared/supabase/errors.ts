import type { PostgrestError } from '@supabase/supabase-js';

export function throwSupabaseError(error: PostgrestError | Error): never {
  if ('code' in error) {
    if (error.code === '23505') throw new Error('Ya existe un registro con esos datos.');
    if (error.code === 'P0001' || error.code === '23514') throw new Error(error.message);
    if (error.code === 'PGRST116') throw new Error('Registro no encontrado.');
  }
  throw new Error(error.message || 'No se pudo completar la operación.');
}
