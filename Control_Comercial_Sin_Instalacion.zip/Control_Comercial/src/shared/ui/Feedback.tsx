import { errorMessage } from '@/shared/lib/error-message';
export function Feedback({ error }: { error: unknown }) {
  return error ? (
    <p className="field-error" role="alert">
      {errorMessage(error)}
    </p>
  ) : null;
}
