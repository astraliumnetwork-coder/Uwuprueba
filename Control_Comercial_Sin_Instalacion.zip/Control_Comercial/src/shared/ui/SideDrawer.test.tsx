import { cleanup, fireEvent, render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { useState } from 'react';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { SideDrawer } from './SideDrawer';

const showModal = Object.getOwnPropertyDescriptor(HTMLDialogElement.prototype, 'showModal');
const close = Object.getOwnPropertyDescriptor(HTMLDialogElement.prototype, 'close');
function Harness() {
  const [open, setOpen] = useState(false);
  return (
    <>
      <button onClick={() => setOpen(true)}>Abrir menú</button>
      {open && (
        <SideDrawer
          name="Empresa"
          logo="/logo.png"
          footer={<span>Acceso temporal</span>}
          onClose={() => setOpen(false)}
        >
          <nav aria-label="Secciones">
            <a href="#productos">Productos</a>
          </nav>
        </SideDrawer>
      )}
    </>
  );
}

beforeEach(() => {
  // JSDOM has no native modal top layer. Emulate only open/close for event tests.
  Object.defineProperty(HTMLDialogElement.prototype, 'showModal', {
    configurable: true,
    value() {
      this.setAttribute('open', '');
      this.querySelector('button')?.focus();
    },
  });
  Object.defineProperty(HTMLDialogElement.prototype, 'close', {
    configurable: true,
    value() {
      this.removeAttribute('open');
    },
  });
});
afterEach(() => {
  cleanup();
  vi.restoreAllMocks();
  for (const [key, descriptor] of [
    ['showModal', showModal],
    ['close', close],
  ] as const) {
    if (descriptor) Object.defineProperty(HTMLDialogElement.prototype, key, descriptor);
    else Reflect.deleteProperty(HTMLDialogElement.prototype, key);
  }
});

describe('Side drawer interaction', () => {
  it('closes on Escape and restores focus to the menu trigger', async () => {
    const user = userEvent.setup();
    render(<Harness />);
    const trigger = screen.getByRole('button', { name: 'Abrir menú' });
    await user.click(trigger);
    const dialog = screen.getByRole('dialog', { name: 'Menú principal de Empresa' });
    expect(screen.getByRole('img', { name: 'Empresa' })).toHaveAttribute('src', '/logo.png');
    fireEvent(dialog, new Event('cancel', { bubbles: false, cancelable: true }));
    expect(screen.queryByRole('dialog')).not.toBeInTheDocument();
    expect(trigger).toHaveFocus();
  });
  it('keeps content clicks open and closes only when the backdrop is clicked', async () => {
    const user = userEvent.setup();
    render(<Harness />);
    await user.click(screen.getByRole('button', { name: 'Abrir menú' }));
    const dialog = screen.getByRole('dialog');
    vi.spyOn(dialog, 'getBoundingClientRect').mockReturnValue({
      left: 0,
      right: 300,
      top: 0,
      bottom: 800,
      width: 300,
      height: 800,
      x: 0,
      y: 0,
      toJSON: () => ({}),
    });
    fireEvent.click(dialog, { clientX: 100, clientY: 100 });
    expect(dialog).toBeInTheDocument();
    fireEvent.click(dialog, { clientX: 390, clientY: 100 });
    expect(screen.queryByRole('dialog')).not.toBeInTheDocument();
  });
});
