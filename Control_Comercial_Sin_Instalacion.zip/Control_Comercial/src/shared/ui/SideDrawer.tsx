import { useEffect, useRef } from 'react';
import type { ReactNode } from 'react';
import { createPortal } from 'react-dom';
import { X } from 'lucide-react';

export function SideDrawer({
  logo,
  name,
  children,
  footer,
  onClose,
}: {
  logo: string;
  name: string;
  children: ReactNode;
  footer: ReactNode;
  onClose: () => void;
}) {
  const ref = useRef<HTMLDialogElement>(null);
  useEffect(() => {
    const drawer = ref.current;
    const previous = document.activeElement instanceof HTMLElement ? document.activeElement : null;
    drawer?.showModal();
    return () => {
      drawer?.close();
      previous?.focus();
    };
  }, []);
  return createPortal(
    <dialog
      ref={ref}
      className="side-drawer"
      aria-label={`Menú principal de ${name}`}
      onCancel={(event) => {
        event.preventDefault();
        onClose();
      }}
      onClick={(event) => {
        if (event.target !== event.currentTarget) return;
        const rect = event.currentTarget.getBoundingClientRect();
        if (
          event.clientX < rect.left ||
          event.clientX > rect.right ||
          event.clientY < rect.top ||
          event.clientY > rect.bottom
        )
          onClose();
      }}
    >
      <header className="drawer-header">
        <img src={logo} alt={name} />
        <button type="button" className="icon-button" aria-label="Cerrar menú" onClick={onClose}>
          <X size={22} />
        </button>
      </header>
      <div className="drawer-content">
        <p className="drawer-caption">PLATAFORMA</p>
        {children}
      </div>
      <footer className="drawer-footer">{footer}</footer>
    </dialog>,
    document.body,
  );
}
