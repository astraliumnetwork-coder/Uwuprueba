import { ZodError } from 'zod';
export function errorMessage(error: unknown): string {
  if (error instanceof ZodError) return error.issues[0]?.message ?? 'Revisa los datos ingresados.';
  if (error instanceof Error) return error.message;
  if (typeof error === 'string' && error) return error;
  return 'No se pudo completar la operación.';
}
