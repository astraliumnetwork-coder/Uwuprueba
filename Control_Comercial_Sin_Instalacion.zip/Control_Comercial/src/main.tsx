import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { App } from './app/App';
import './styles/index.css';
import './styles/responsive.css';
import './styles/sale-checkout.css';
import './styles/product-editor.css';
import './styles/overview.css';
createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>,
);
