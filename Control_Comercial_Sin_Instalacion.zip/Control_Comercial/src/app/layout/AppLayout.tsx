import { NavLink, Outlet, useLocation } from 'react-router-dom';
import {
  Menu,
  LayoutDashboard,
  Settings,
  PanelLeftClose,
  PanelLeftOpen,
  ShoppingCart,
  ClipboardList,
  Package,
  ChartNoAxesCombined,
  Receipt,
} from 'lucide-react';
import { SideDrawer } from '@/shared/ui/SideDrawer';
import { useState } from 'react';
import { env } from '@/shared/config/env';
import { useSession } from '@/features/auth/hooks/useSession';
const menu = [
  { to: '/menudeo', label: 'Menudeo', icon: ShoppingCart },
  { to: '/pedidos', label: 'Pedidos', icon: ClipboardList },
  { to: '/productos', label: 'Productos', icon: Package },
  { to: '/gastos', label: 'Gastos', icon: Receipt },
  { to: '/reportes', label: 'Resultados', icon: ChartNoAxesCombined },
];
export function AppLayout() {
  const session = useSession();
  const [mobileMenu, setMobileMenu] = useState(false);
  const [compact, setCompact] = useState(false);
  const { pathname } = useLocation();
  const workspace = (
    <div
      className="workspace-label"
      title={`${session.data?.organizationName ?? env.VITE_APP_NAME} · ${session.data?.email ?? 'Cuenta'}`}
    >
      <span className="workspace-avatar" aria-hidden="true">
        {(session.data?.organizationName ?? env.VITE_APP_NAME).trim().charAt(0).toUpperCase()}
      </span>
      <span className="nav-label workspace-details">
        <strong>{session.data?.organizationName ?? env.VITE_APP_NAME}</strong>
        <small>
          <span className="status-dot" />
          {session.data?.email ?? 'Cuenta'}
        </small>
      </span>
    </div>
  );
  return (
    <div className={`app-shell ${compact ? 'is-compact' : ''}`}>
      <a className="skip-link" href="#main">
        Saltar al contenido
      </a>
      <aside className="sidebar" aria-label="Menú principal">
        <LinkBrand />
        <p className="nav-caption">PLATAFORMA</p>
        <nav>
          <NavLink to="/" end aria-label="Vista general">
            <LayoutDashboard size={19} />
            <span className="nav-label">Vista general</span>
          </NavLink>
          {menu.map(({ to, label, icon: Icon }) => (
            <NavLink key={to} to={to} aria-label={label}>
              <Icon size={19} />
              <span className="nav-label">{label}</span>
            </NavLink>
          ))}
          <NavLink to="/configuracion" aria-label="Configuración">
            <Settings size={19} />
            <span className="nav-label">Configuración</span>
          </NavLink>
        </nav>
        <div className="sidebar-footer">{workspace}</div>
      </aside>
      {mobileMenu && (
        <SideDrawer
          logo={`${import.meta.env.BASE_URL}logo.png`}
          name={env.VITE_APP_NAME}
          footer={workspace}
          onClose={() => setMobileMenu(false)}
        >
          <nav className="mobile-navigation" aria-label="Navegación móvil">
            {[
              { to: '/', label: 'Vista general', icon: LayoutDashboard },
              ...menu,
              { to: '/configuracion', label: 'Configuración', icon: Settings },
            ].map(({ to, label, icon: Icon }) => (
              <NavLink key={to} to={to} end={to === '/'} onClick={() => setMobileMenu(false)}>
                <Icon size={21} />
                <span>{label}</span>
              </NavLink>
            ))}
          </nav>
        </SideDrawer>
      )}
      <div className="main-shell">
        <header className="topbar">
          <div className="topbar-left">
            <button
              className="button mobile-menu-button"
              aria-label="Abrir menú de navegación"
              aria-expanded={mobileMenu}
              onClick={() => setMobileMenu(true)}
            >
              <Menu size={21} />
              <span>Menú</span>
            </button>
            <button
              className="icon-button collapse-button"
              aria-label={compact ? 'Expandir menú' : 'Contraer menú'}
              aria-expanded={!compact}
              onClick={() => setCompact(!compact)}
            >
              {compact ? <PanelLeftOpen size={20} /> : <PanelLeftClose size={20} />}
            </button>
            <span>
              <span className="breadcrumb-prefix">
                Plataforma <span className="breadcrumb-slash">/</span>
              </span>{' '}
              <strong>
                {pathname === '/configuracion'
                  ? 'Configuración'
                  : (menu.find((i) => i.to === pathname)?.label ?? 'Vista general')}
              </strong>
            </span>
          </div>
          <div className="row-actions topbar-badges">
            <span className="badge">Sesión iniciada</span>
            <span className="badge">PEN · Lima</span>
          </div>
        </header>
        <main id="main" className="main-content" tabIndex={-1}>
          <Outlet />
        </main>
      </div>
    </div>
  );
}
function LinkBrand() {
  return (
    <NavLink className="brand" to="/" aria-label={`${env.VITE_APP_NAME}, inicio`}>
      <img
        className="brand-logo"
        src={`${import.meta.env.BASE_URL}logo.png`}
        alt={env.VITE_APP_NAME}
      />
    </NavLink>
  );
}
