import { useRouteError } from 'react-router-dom';
import { useEffect } from 'react';
import { PageState } from '@/shared/ui/PageState';
import { logger } from '@/shared/lib/logger';

export function RouteError() {
  const error = useRouteError();
  useEffect(() => {
    if (error) logger.error('route', error);
  }, [error]);
  return (
    <PageState
      title="No pudimos cargar esta página"
      action={
        <button className="button primary" onClick={() => window.location.reload()}>
          Reintentar
        </button>
      }
    >
      Si el problema continúa, informa al administrador.
    </PageState>
  );
}
