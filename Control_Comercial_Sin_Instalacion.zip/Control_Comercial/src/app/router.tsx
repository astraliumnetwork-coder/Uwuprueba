import { createBrowserRouter, Link } from 'react-router-dom';
import { ProtectedLayout } from './layout/ProtectedLayout';
import { PageState } from '@/shared/ui/PageState';
import { RouteError } from './layout/RouteError';
import { Component as AuthPage } from '@/features/auth/pages/AuthPage';
import { Component as DashboardPage } from '@/features/dashboard/pages/DashboardPage';
import { Component as ProductsPage } from '@/features/products/pages/ProductsPage';
import { Component as RetailPage } from '@/features/retail/pages/RetailPage';
import { Component as OrdersPage } from '@/features/orders/pages/OrdersPage';
import { Component as ExpensesPage } from '@/features/finance/pages/ExpensesPage';
import { Component as ReportsPage } from '@/features/finance/pages/ReportsPage';
import { Component as SettingsPage } from '@/features/settings/pages/SettingsPage';

export const router = createBrowserRouter([
  {
    path: '/acceso',
    Component: AuthPage,
    ErrorBoundary: RouteError,
  },
  {
    path: '/',
    Component: ProtectedLayout,
    ErrorBoundary: RouteError,
    children: [
      { index: true, Component: DashboardPage, ErrorBoundary: RouteError },
      { path: 'productos', Component: ProductsPage, ErrorBoundary: RouteError },
      { path: 'menudeo', Component: RetailPage, ErrorBoundary: RouteError },
      { path: 'pedidos', Component: OrdersPage, ErrorBoundary: RouteError },
      { path: 'gastos', Component: ExpensesPage, ErrorBoundary: RouteError },
      { path: 'reportes', Component: ReportsPage, ErrorBoundary: RouteError },
      { path: 'configuracion', Component: SettingsPage, ErrorBoundary: RouteError },
      {
        path: '*',
        element: (
          <PageState
            title="Página no encontrada"
            action={
              <Link className="button primary" to="/">
                Volver al inicio
              </Link>
            }
          >
            La dirección no corresponde a una página disponible.
          </PageState>
        ),
      },
    ],
  },
]);
