import { z } from 'zod';
import { expenseSchema, pageSchema, reportSchema } from '@saas/domain';
import type { Channel } from '@saas/domain';
import { supabase } from '@/shared/supabase/client';
import { throwSupabaseError } from '@/shared/supabase/errors';
export const financeApi = {
  async report(from: string, to: string, channel: Channel | 'all', signal: AbortSignal) {
    const { data, error } = await supabase
      .rpc('get_report', {
        p_from: from,
        p_to: to,
        p_channel: channel === 'all' ? null : channel,
      })
      .abortSignal(signal);
    if (error) throwSupabaseError(error);
    return reportSchema.parse(data);
  },
  async expenses(page: number, signal: AbortSignal) {
    const pageSize = 25;
    const { data, error, count } = await supabase
      .from('expenses')
      .select('id,channel,description,amount_cents,spent_on', { count: 'exact' })
      .order('spent_on', { ascending: false })
      .order('created_at', { ascending: false })
      .range((page - 1) * pageSize, page * pageSize - 1)
      .abortSignal(signal);
    if (error) throwSupabaseError(error);
    const items = (data ?? []).map((row) => ({
      id: row.id,
      channel: row.channel,
      description: row.description,
      amountCents: Number(row.amount_cents),
      spentOn: row.spent_on,
    }));
    return pageSchema(expenseSchema).parse({ items, total: count ?? 0, page, pageSize });
  },
  async createExpense(input: unknown, key: string) {
    const { data, error } = await supabase.rpc('create_expense', { p_input: input, p_key: key });
    if (error) throwSupabaseError(error);
    return expenseResultSchema.parse(data);
  },
};

const expenseResultSchema = z.object({ id: z.string().uuid() });
