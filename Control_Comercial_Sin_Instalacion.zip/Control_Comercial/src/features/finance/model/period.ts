import { localDate } from '@saas/domain';
export function currentWeek() {
  const to = localDate();
  const d = new Date(`${to}T12:00:00Z`);
  d.setUTCDate(d.getUTCDate() - ((d.getUTCDay() + 6) % 7));
  return { from: d.toISOString().slice(0, 10), to };
}
