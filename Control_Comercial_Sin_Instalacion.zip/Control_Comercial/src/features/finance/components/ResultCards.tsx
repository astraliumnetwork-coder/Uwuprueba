import { money } from '@saas/domain';
import type { Report } from '@saas/domain';
export function ResultCards({ data }: { data: Report }) {
  const values = [
    ['Ventas', data.salesCents],
    ['Costo de mercadería', data.costTotalCents],
    ['Utilidad bruta', data.grossCents],
    ['Gastos operativos', data.expensesCents],
    ['Resultado operativo', data.netCents],
  ] as const;
  return (
    <div className="metrics-grid">
      {values.map(([label, value]) => (
        <article className="metric-card" key={label}>
          <p>{label}</p>
          <strong className={value < 0 ? 'negative' : ''}>{money(value)}</strong>
        </article>
      ))}
    </div>
  );
}
