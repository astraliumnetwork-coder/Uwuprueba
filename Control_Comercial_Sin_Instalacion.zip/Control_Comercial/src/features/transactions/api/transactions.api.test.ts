import { beforeEach, expect, it, vi } from 'vitest';
const { from } = vi.hoisted(() => ({ from: vi.fn() }));
vi.mock('@/shared/supabase/client', () => ({ supabase: { from } }));
import { transactionsApi } from './transactions.api';
const row = {
  id: '00000000-0000-4000-8000-000000000001',
  channel: 'orders',
  payment: 'cash',
  customer: 'Cliente',
  scheduled_for: null,
  created_at: '2026-10-26T12:00:00Z',
  recognized_at: null,
  status: 'pending',
};
function mockDatabase(code?: string) {
  const sale = code ? { ...row, order_code: code } : row;
  from.mockImplementation((table: string) => {
    const response = { data: table === 'sales' ? [sale] : [], error: null, count: 1 };
    const builder = {
      select: vi.fn((columns: string) => {
        if (!code && columns.includes('order_code'))
          throw new Error('column sales.order_code does not exist');
        return builder;
      }),
      eq: vi.fn(() => builder),
      order: vi.fn(() => builder),
      range: vi.fn(() => builder),
      abortSignal: vi.fn(() => builder),
      in: vi.fn(() => builder),
      single: vi.fn(async () => ({ data: sale, error: null })),
      then: (resolve: (value: typeof response) => unknown) =>
        Promise.resolve(response).then(resolve),
    };
    return builder;
  });
}
beforeEach(() => vi.clearAllMocks());
it('loads history and detail without the order code migration', async () => {
  mockDatabase();
  const signal = new AbortController().signal;
  const orders = await transactionsApi.list('orders', 1, signal);
  expect(orders.items[0]?.orderCode).toBeNull();
  expect((await transactionsApi.detail(row.id, signal)).sale.id).toBe(row.id);
  await expect(transactionsApi.list('retail', 1, signal)).resolves.toHaveProperty('total', 1);
});
it('preserves persisted order codes when the migration exists', async () => {
  mockDatabase('PED-000123');
  const signal = new AbortController().signal;
  expect((await transactionsApi.list('orders', 1, signal)).items[0]?.orderCode).toBe('PED-000123');
  expect((await transactionsApi.detail(row.id, signal)).sale.orderCode).toBe('PED-000123');
});
