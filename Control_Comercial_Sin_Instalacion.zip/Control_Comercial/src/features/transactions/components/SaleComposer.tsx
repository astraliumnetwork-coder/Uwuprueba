import { useMediaQuery } from '@/shared/hooks/useMediaQuery';
import { errorMessage } from '@/shared/lib/error-message';
import { useRef, useState } from 'react';
import type { FormEvent } from 'react';
import {
  calculateLine,
  channelLabels,
  money,
  parseMoney,
  paymentLabels,
  saleInput,
} from '@saas/domain';
import type { Channel, Product } from '@saas/domain';
import {
  Minus,
  Plus,
  ShoppingCart,
  Trash2,
  BadgePercent,
  ReceiptText,
  ChevronDown,
  UserRound,
  WalletCards,
} from 'lucide-react';
import { CatalogInventory } from './CatalogInventory';
import { useTransactionAction } from '../hooks/useTransactions';
import { Modal } from '@/shared/ui/Modal';
import { Feedback } from '@/shared/ui/Feedback';
type Draft = { product: Product; quantity: string; price: string; cost: string };
export function SaleComposer({ channel, onDone }: { channel: Channel; onDone: () => void }) {
  const retail = channel === 'retail';
  const desktop = useMediaQuery('(min-width: 960px)');
  const [tab, setTab] = useState<'inventory' | 'detail'>('inventory');
  const formRef = useRef<HTMLFormElement>(null);
  const [items, setItems] = useState<Draft[]>([]);
  const [error, setError] = useState('');
  const action = useTransactionAction();
  const key = useRef(crypto.randomUUID());
  function switchTab(next: 'inventory' | 'detail') {
    setTab(next);
    formRef.current?.querySelector('.checkout-stage')?.scrollTo?.({ top: 0 });
  }
  function change(index: number, field: 'quantity' | 'price' | 'cost', value: string) {
    if (retail && field === 'cost') return;
    setItems((previous) =>
      previous.map((item, i) => (i === index ? { ...item, [field]: value } : item)),
    );
    key.current = crypto.randomUUID();
  }
  function add(product: Product) {
    setItems((previous) => {
      const currentQuantity = Number(
        previous.find((i) => i.product.id === product.id)?.quantity || 0,
      );
      if (
        !product.active ||
        currentQuantity >= 100000 ||
        (channel === 'retail' && currentQuantity >= product.retailStock) ||
        (previous.length >= 100 && !previous.some((i) => i.product.id === product.id))
      )
        return previous;
      const existing = previous.find((i) => i.product.id === product.id);
      return existing
        ? previous.map((i) =>
            i.product.id === product.id
              ? { ...i, quantity: String(Number(i.quantity || 0) + 1) }
              : i,
          )
        : [
            ...previous,
            {
              product,
              quantity: '1',
              price: (product.priceCents / 100).toFixed(2),
              cost: (product.costCents / 100).toFixed(2),
            },
          ];
    });
    key.current = crypto.randomUUID();
  }
  const computed = items.map((item) => {
    try {
      return calculateLine(
        Number(item.quantity),
        parseMoney(item.price),
        retail ? item.product.costCents : parseMoney(item.cost),
      );
    } catch {
      return null;
    }
  });
  const totals = computed.reduce<{
    salesCents: number;
    costTotalCents: number;
    grossCents: number;
  }>(
    (total, item) => ({
      salesCents: total.salesCents + (item?.salesCents ?? 0),
      costTotalCents: total.costTotalCents + (item?.costTotalCents ?? 0),
      grossCents: total.grossCents + (item?.grossCents ?? 0),
    }),
    { salesCents: 0, costTotalCents: 0, grossCents: 0 },
  );
  function submit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const data = new FormData(e.currentTarget);
    try {
      if (channel === 'orders' && !String(data.get('customer') ?? '').trim()) {
        switchTab('inventory');
        throw new Error('Indica el cliente del pedido.');
      }
      const invalid = computed.findIndex((line) => !line);
      if (invalid >= 0) {
        switchTab('detail');
        throw new Error(
          retail
            ? 'Revisa la cantidad y el precio final del producto.'
            : 'Revisa cantidad, precio y costo del artículo seleccionado.',
        );
      }
      if (stockExceeded) {
        switchTab('detail');
      }
      if (stockExceeded) throw new Error('La cantidad supera el stock de menudeo disponible.');
      const input = saleInput.parse({
        channel,
        payment: data.get('payment'),
        customer: data.get('customer') ?? '',
        scheduledFor: data.get('scheduledFor') || null,
        items: items.map((i) => ({
          productId: i.product.id,
          quantity: Number(i.quantity),
          priceCents: parseMoney(i.price),
          costCents: retail ? i.product.costCents : parseMoney(i.cost),
        })),
      });
      setError('');
      action.mutate({ kind: 'create', input, key: key.current }, { onSuccess: onDone });
    } catch (err) {
      setError(errorMessage(err));
    }
  }
  const quantities = new Map(items.map((item) => [item.product.id, Number(item.quantity) || 0]));
  const stockExceeded =
    channel === 'retail' && items.some((item) => Number(item.quantity) > item.product.retailStock);
  const unitCount = items.reduce((total, item) => total + (Number(item.quantity) || 0), 0);
  const discountCents = items.reduce((sum, item, index) => {
    if (!computed[index]) return sum;
    return (
      sum + Math.max(0, item.product.priceCents - parseMoney(item.price)) * Number(item.quantity)
    );
  }, 0);
  return (
    <Modal
      title={channel === 'retail' ? 'Venta de menudeo' : 'Crear pedido'}
      onClose={onDone}
      busy={action.isPending}
      wide
      fitted
      className={`sale-composer-modal ${retail ? 'retail-checkout-modal' : ''}`}
    >
      <form
        ref={formRef}
        onSubmit={submit}
        className={`sale-checkout checkout-tab-${tab}`}
        noValidate
      >
        <fieldset disabled={action.isPending}>
          <nav hidden={desktop} className="checkout-tabs" aria-label="Secciones de la operación">
            <button
              type="button"
              aria-pressed={tab === 'inventory'}
              onClick={() => switchTab('inventory')}
            >
              {retail ? '1. Productos' : 'Venta'}
            </button>
            <button
              type="button"
              aria-pressed={tab === 'detail'}
              onClick={() => switchTab('detail')}
            >
              {retail ? '2. Venta' : 'Detalle'} ({items.length})
            </button>
          </nav>
          <div className="checkout-stage">
            <div className="sale-workbench">
              <div className="inventory-pane" hidden={!desktop && tab !== 'inventory'}>
                <section className="sale-context" aria-label="Datos de la operación">
                  <div className="field">
                    <label
                      htmlFor="customer"
                      className="sale-context-label"
                      style={{ display: 'flex', alignItems: 'center', gap: 6 }}
                    >
                      <UserRound size={16} aria-hidden="true" />
                      Cliente {channel === 'retail' ? '(opcional)' : ''}
                    </label>
                    <div className="sale-context-input-wrap" style={{ position: 'relative' }}>
                      <UserRound
                        size={18}
                        aria-hidden="true"
                        style={{
                          position: 'absolute',
                          insetInlineStart: 14,
                          top: '50%',
                          transform: 'translateY(-50%)',
                          color: 'var(--muted)',
                          pointerEvents: 'none',
                        }}
                      />
                      <input
                        id="customer"
                        name="customer"
                        type="text"
                        autoComplete="name"
                        autoCapitalize="words"
                        enterKeyHint="next"
                        placeholder={
                          channel === 'retail'
                            ? 'Ej. nombre del cliente o Venta de mostrador'
                            : 'Ej. María Pérez o Empresa cliente'
                        }
                        maxLength={120}
                        style={{ paddingInlineStart: 42 }}
                        required={channel === 'orders'}
                        onChange={() => {
                          key.current = crypto.randomUUID();
                        }}
                      />
                    </div>
                  </div>
                  <div className="field">
                    <label
                      htmlFor="payment"
                      className="sale-context-label"
                      style={{ display: 'flex', alignItems: 'center', gap: 6 }}
                    >
                      <WalletCards size={16} aria-hidden="true" />
                      Método de pago{channel === 'orders' ? ' previsto' : ''}
                    </label>
                    <div
                      className="sale-context-input-wrap sale-context-select-wrap"
                      style={{ position: 'relative' }}
                    >
                      <WalletCards
                        size={18}
                        aria-hidden="true"
                        style={{
                          position: 'absolute',
                          insetInlineStart: 14,
                          top: '50%',
                          transform: 'translateY(-50%)',
                          color: 'var(--muted)',
                          pointerEvents: 'none',
                        }}
                      />
                      <select
                        id="payment"
                        name="payment"
                        aria-label="Método de pago"
                        style={{ paddingInlineStart: 42 }}
                        onChange={() => {
                          key.current = crypto.randomUUID();
                        }}
                      >
                        {Object.entries(paymentLabels).map(([value, label]) => (
                          <option key={value} value={value}>
                            {label}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>
                  {channel === 'orders' && (
                    <div className="field">
                      <label htmlFor="scheduled">Entrega prevista (opcional)</label>
                      <input
                        id="scheduled"
                        type="date"
                        name="scheduledFor"
                        onChange={() => {
                          key.current = crypto.randomUUID();
                        }}
                      />
                    </div>
                  )}
                </section>

                <CatalogInventory
                  channel={channel}
                  quantities={quantities}
                  onAdd={add}
                  active={desktop || tab === 'inventory'}
                />
              </div>
              <section
                className="sale-basket"
                hidden={!desktop && tab !== 'detail'}
                aria-labelledby="basket-title"
              >
                <header className="workbench-heading">
                  <div>
                    <h2 id="basket-title">{retail ? 'Tu venta' : 'Detalle de pedido'}</h2>
                    {retail && (
                      <p className="retail-basket-guide">
                        Ajusta la cantidad y el precio que acordaste con el cliente.
                      </p>
                    )}
                  </div>
                  <span className="badge" role="status">
                    {items.length} {items.length === 1 ? 'artículo' : 'artículos'} · {unitCount}{' '}
                    {unitCount === 1 ? 'unidad' : 'unidades'}
                  </span>
                </header>
                {!items.length && (
                  <div className="basket-empty">
                    <ShoppingCart size={38} />
                    <h3>Agrega tu primer artículo</h3>
                    <p>
                      {retail
                        ? 'Busca un producto y pulsa + para agregarlo. Luego indica cuánto cobrarás por unidad.'
                        : 'Busca en el inventario y pulsa +. Aquí podrás ajustar cantidades, precio y costo antes de confirmar.'}
                    </p>
                  </div>
                )}
                <div className="basket-lines">
                  {items.map((item, index) => {
                    const line = computed[index];
                    const soldPrice = line ? parseMoney(item.price) : null;
                    const exceeded =
                      channel === 'retail' && Number(item.quantity) > item.product.retailStock;
                    return (
                      <article className="basket-line" key={item.product.id}>
                        <div className="basket-line-heading">
                          <div>
                            {(item.product.category || item.product.subcategory) && (
                              <div className="product-tags">
                                {item.product.category && (
                                  <span className="product-category-badge">
                                    {item.product.category}
                                  </span>
                                )}
                                {item.product.subcategory && (
                                  <span className="product-subcategory-badge">
                                    {item.product.subcategory}
                                  </span>
                                )}
                              </div>
                            )}
                            <strong>{item.product.name}</strong>
                            <small>
                              {item.product.sku}
                              {item.product.color ? ` · Color: ${item.product.color}` : ''}
                              {item.product.size ? ` · Talla ${item.product.size}` : ''} · Stock{' '}
                              {channel === 'retail'
                                ? item.product.retailStock
                                : item.product.ordersStock}
                            </small>
                          </div>
                          <button
                            type="button"
                            className="basket-remove"
                            aria-label={`Quitar ${item.product.name}`}
                            onClick={() => {
                              setItems((previous) => previous.filter((_, i) => i !== index));
                              key.current = crypto.randomUUID();
                            }}
                          >
                            <Trash2 size={18} />
                          </button>
                        </div>
                        <div className="basket-line-fields">
                          <div className="field">
                            <label htmlFor={`quantity-${item.product.id}`}>Cantidad</label>
                            <div className="quantity-control">
                              <button
                                type="button"
                                aria-label={`Reducir cantidad de ${item.product.name}`}
                                disabled={Number(item.quantity) <= 1}
                                onClick={() =>
                                  change(
                                    index,
                                    'quantity',
                                    String(Math.max(1, (Number(item.quantity) || 1) - 1)),
                                  )
                                }
                              >
                                <Minus size={16} />
                              </button>
                              <input
                                id={`quantity-${item.product.id}`}
                                aria-label={`Cantidad de ${item.product.name}`}
                                type="number"
                                inputMode="numeric"
                                min="1"
                                max="100000"
                                step="1"
                                value={item.quantity}
                                onChange={(e) => change(index, 'quantity', e.target.value)}
                                required
                              />
                              <button
                                type="button"
                                aria-label={`Aumentar cantidad de ${item.product.name}`}
                                disabled={
                                  Number(item.quantity) >= 100000 ||
                                  (channel === 'retail' &&
                                    Number(item.quantity) >= item.product.retailStock)
                                }
                                onClick={() =>
                                  change(
                                    index,
                                    'quantity',
                                    String((Number(item.quantity) || 0) + 1),
                                  )
                                }
                              >
                                <Plus size={16} />
                              </button>
                            </div>
                          </div>
                          <div className="field">
                            <label htmlFor={`price-${item.product.id}`}>
                              {retail ? 'Precio final (S/)' : 'Precio de venta S/'}
                            </label>
                            <input
                              id={`price-${item.product.id}`}
                              aria-label={`${retail ? 'Precio final' : 'Precio'} de ${item.product.name}`}
                              type="number"
                              inputMode="decimal"
                              min="0"
                              max="1000000"
                              step="0.01"
                              value={item.price}
                              onChange={(e) => change(index, 'price', e.target.value)}
                              required
                            />
                            {retail ? (
                              <small className="retail-price-help">
                                Escribe aquí lo que cobrarás por cada unidad.
                              </small>
                            ) : (
                              <small className="sale-price-reference">
                                Catálogo: {money(item.product.priceCents)}
                              </small>
                            )}
                          </div>
                          {!retail && (
                            <div className="field">
                              <label htmlFor={`cost-${item.product.id}`}>Costo S/</label>
                              <input
                                id={`cost-${item.product.id}`}
                                aria-label={`Costo de ${item.product.name}`}
                                type="number"
                                inputMode="decimal"
                                min="0"
                                max="1000000"
                                step="0.01"
                                value={item.cost}
                                onChange={(e) => change(index, 'cost', e.target.value)}
                                required
                              />
                            </div>
                          )}
                        </div>
                        {retail && (
                          <div className="retail-price-context">
                            <span>
                              Precio de lista <strong>{money(item.product.priceCents)}</strong>
                            </span>
                            {soldPrice !== null && soldPrice < item.product.priceCents && (
                              <span className="retail-discount">
                                <BadgePercent size={16} aria-hidden="true" />
                                Descuento: {money(item.product.priceCents - soldPrice)} por unidad
                              </span>
                            )}
                            {soldPrice !== null && soldPrice > item.product.priceCents && (
                              <span className="retail-price-increase">
                                Sobre el precio de lista: +
                                {money(soldPrice - item.product.priceCents)} por unidad
                              </span>
                            )}
                            {soldPrice !== null && soldPrice !== item.product.priceCents && (
                              <button
                                type="button"
                                className="text-button"
                                aria-label={`Usar precio de lista de ${item.product.name}`}
                                onClick={() =>
                                  change(index, 'price', (item.product.priceCents / 100).toFixed(2))
                                }
                              >
                                Usar precio de lista
                              </button>
                            )}
                          </div>
                        )}
                        {exceeded && (
                          <p className="field-error" role="alert">
                            La cantidad supera el stock de menudeo disponible.
                          </p>
                        )}
                        {!line && (
                          <p className="field-error">
                            {retail
                              ? 'Indica una cantidad entera y un precio válido, desde S/ 0.00.'
                              : 'Revisa cantidad, precio y costo de este artículo.'}
                          </p>
                        )}
                        {retail ? (
                          <div className="retail-line-total">
                            <span>
                              Importe de este producto
                              {line ? ` · ${item.quantity} × ${money(parseMoney(item.price))}` : ''}
                            </span>
                            <strong>{line ? money(line.salesCents) : '—'}</strong>
                          </div>
                        ) : (
                          <dl className="basket-line-totals">
                            <div>
                              <dt>Total venta</dt>
                              <dd>{line ? money(line.salesCents) : '—'}</dd>
                            </div>
                            <div>
                              <dt>Total costo</dt>
                              <dd>{line ? money(line.costTotalCents) : '—'}</dd>
                            </div>
                            <div>
                              <dt>Utilidad bruta</dt>
                              <dd className={(line?.grossCents ?? 0) < 0 ? 'negative' : ''}>
                                {line ? money(line.grossCents) : '—'}
                              </dd>
                            </div>
                          </dl>
                        )}
                      </article>
                    );
                  })}
                </div>
                {retail && items.length > 0 && (
                  <details className="retail-profit">
                    <summary>
                      <ReceiptText size={17} aria-hidden="true" />
                      Rentabilidad interna
                      <ChevronDown size={16} aria-hidden="true" />
                    </summary>
                    <div>
                      <span>
                        Costo de los productos <strong>{money(totals.costTotalCents)}</strong>
                      </span>
                      <span>
                        Utilidad bruta{' '}
                        <strong className={totals.grossCents < 0 ? 'negative' : ''}>
                          {money(totals.grossCents)}
                        </strong>
                      </span>
                      <p>El costo se toma del producto y no se modifica al vender.</p>
                    </div>
                  </details>
                )}
              </section>
            </div>
          </div>
          <section className="checkout-summary" aria-label="Resumen de operación">
            <div className="checkout-amounts">
              <div>
                <span>Total a {channel === 'retail' ? 'cobrar' : 'programar'}</span>
                <strong>{computed.some((line) => !line) ? '—' : money(totals.salesCents)}</strong>
              </div>
              {retail ? (
                <>
                  <div>
                    <span>Productos</span>
                    <strong>
                      {items.length} {items.length === 1 ? 'artículo' : 'artículos'} · {unitCount}{' '}
                      {unitCount === 1 ? 'unidad' : 'unidades'}
                    </strong>
                  </div>
                  {discountCents > 0 && (
                    <div className="retail-discount">
                      <span>Descuento total</span>
                      <strong>{money(discountCents)}</strong>
                    </div>
                  )}
                </>
              ) : (
                <>
                  <div>
                    <span>Costo total</span>
                    <strong>{money(totals.costTotalCents)}</strong>
                  </div>
                  <div>
                    <span>Utilidad bruta</span>
                    <strong className={totals.grossCents < 0 ? 'negative' : ''}>
                      {money(totals.grossCents)}
                    </strong>
                  </div>
                </>
              )}
            </div>
            {(totals.grossCents < 0 ||
              (retail && computed.some((line) => line && line.grossCents < 0))) && (
              <p className="field-error">
                {retail
                  ? 'Hay productos vendidos por debajo del costo. Revisa el precio final antes de confirmar.'
                  : 'La operación tiene utilidad negativa. Revisa los precios antes de confirmar.'}
              </p>
            )}
            <Feedback error={error || action.error} />
            {!retail && (
              <p className="checkout-note">
                {channelLabels[channel]} · Fecha y hora automáticas.{' '}
                {channel === 'orders'
                  ? 'El pedido no reserva stock ni genera ingresos hasta entregarlo.'
                  : 'El stock se validará nuevamente al confirmar la venta.'}
              </p>
            )}
            <div className="checkout-actions">
              <button type="button" className="button secondary" onClick={onDone}>
                Cancelar
              </button>
              <button
                type="submit"
                className="button primary"
                disabled={!items.length || computed.some((value) => !value) || stockExceeded}
              >
                {action.isPending
                  ? 'Guardando…'
                  : channel === 'retail'
                    ? 'Confirmar venta'
                    : 'Guardar pedido pendiente'}
              </button>
            </div>
          </section>
        </fieldset>
      </form>
    </Modal>
  );
}
