import { cleanup, render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { MemoryRouter } from 'react-router-dom';
import type { ReactNode } from 'react';
import { afterEach, expect, it, vi } from 'vitest';
import { SalesWorkspace } from './SalesWorkspace';

const { mutate, reset } = vi.hoisted(() => ({ mutate: vi.fn(), reset: vi.fn() }));
vi.mock('../hooks/useTransactions', () => ({
  useTransactions: () => ({
    isPending: false,
    error: null,
    data: {
      total: 2,
      page: 1,
      pageSize: 25,
      items: [
        {
          id: 'sale-1',
          channel: 'retail',
          payment: 'cash',
          customer: 'Cliente',
          status: 'posted',
          createdAt: '2026-10-30T14:00:00Z',
          salesCents: 7500,
          costTotalCents: 5000,
          grossCents: 2500,
        },
        {
          id: 'sale-2',
          channel: 'retail',
          payment: 'cash',
          customer: 'Anulada',
          status: 'cancelled',
          createdAt: '2026-10-30T14:00:00Z',
          salesCents: 7500,
          costTotalCents: 5000,
          grossCents: 2500,
        },
      ],
    },
  }),
  useTransactionAction: () => ({ mutate, reset, isPending: false, error: null }),
}));
vi.mock('@/shared/ui/Modal', () => ({
  Modal: ({ children, title }: { children: ReactNode; title: string }) => (
    <div role="dialog" aria-label={title}>
      {children}
    </div>
  ),
}));
vi.mock('@/features/quotes/components/QuoteEditor', () => ({ QuoteEditor: () => null }));
vi.mock('@/features/quotes/components/QuoteWorkspace', () => ({ QuoteWorkspace: () => null }));
vi.mock('./SaleComposer', () => ({ SaleComposer: () => null }));
vi.mock('./SaleDetail', () => ({ SaleDetail: () => null }));
afterEach(() => {
  cleanup();
  vi.clearAllMocks();
});

it('offers cancellation only for active retail sales and submits a reason through the action', async () => {
  const user = userEvent.setup();
  render(
    <MemoryRouter>
      <SalesWorkspace channel="retail" />
    </MemoryRouter>,
  );
  expect(screen.getAllByRole('button', { name: 'Anular' })).toHaveLength(1);
  await user.click(screen.getByRole('button', { name: 'Anular' }));
  expect(screen.getByRole('dialog', { name: 'Anular venta' })).toBeVisible();
  expect(screen.getByText(/sus unidades volverán al stock de menudeo/)).toBeVisible();
  await user.type(screen.getByLabelText('Motivo de anulación'), 'Venta duplicada');
  await user.click(screen.getByRole('button', { name: 'Confirmar anulación' }));
  expect(mutate).toHaveBeenCalledWith(
    { kind: 'cancel', id: 'sale-1', reason: 'Venta duplicada' },
    expect.objectContaining({ onSuccess: expect.any(Function) }),
  );
});
