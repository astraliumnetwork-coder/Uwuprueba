import { localDate, money } from '@saas/domain';
import { useState } from 'react';
import { useQuoteForSale } from '@/features/quotes/hooks';
import { QuoteDetail } from '@/features/quotes/components/QuoteDetail';
import { QuoteEditor } from '@/features/quotes/components/QuoteEditor';
import type { Quote } from '@/features/quotes/model';
import { useSaleDetail } from '../hooks/useTransactions';
import { Modal } from '@/shared/ui/Modal';
import { Feedback } from '@/shared/ui/Feedback';
export function SaleDetail({ id, onClose }: { id: string; onClose: () => void }) {
  const query = useSaleDetail(id);
  const source = useQuoteForSale(query.data?.sale.channel === 'orders' ? id : null);
  const [copy, setCopy] = useState(false);
  if (query.data?.sale.channel === 'orders' && !source.isPending && !source.error) {
    const { sale, items } = query.data;
    const document: Quote = source.data ?? {
      id: sale.id,
      number: 0,
      version: 0,
      brand: 'reypro',
      customer: sale.customer,
      ruc: '',
      address: '',
      date: localDate(new Date(sale.createdAt)),
      taxIncluded: false,
      subtotalCents: sale.salesCents,
      taxCents: 0,
      totalCents: sale.salesCents,
      saleId: sale.id,
      createdAt: sale.createdAt,
      items: items.map((item) => ({
        id: item.productId,
        productId: item.productId,
        name: item.name,
        quantity: item.quantity,
        priceCents: item.priceCents,
        costCents: item.costCents,
      })),
    };
    if (copy)
      return (
        <QuoteEditor
          initial={document}
          copy
          onClose={() => setCopy(false)}
          onOrder={() => {
            setCopy(false);
            onClose();
          }}
        />
      );
    return (
      <QuoteDetail
        quote={document}
        sale={sale}
        onClose={onClose}
        onDuplicate={() => setCopy(true)}
      />
    );
  }
  return (
    <Modal
      title={
        query.data?.sale.orderCode ? `Pedido ${query.data.sale.orderCode}` : 'Detalle de operación'
      }
      onClose={onClose}
      wide
    >
      <Feedback error={query.error || source.error} />
      {query.isPending || (query.data?.sale.channel === 'orders' && source.isPending) ? (
        <p>Cargando…</p>
      ) : (
        query.data && (
          <div className="table-scroll">
            <table role="table">
              <thead role="rowgroup">
                <tr role="row">
                  <th role="columnheader" scope="col">
                    Artículo
                  </th>
                  <th role="columnheader" scope="col">
                    Cantidad
                  </th>
                  <th role="columnheader" scope="col">
                    Venta unitaria
                  </th>
                  <th role="columnheader" scope="col">
                    Costo unitario
                  </th>
                  <th role="columnheader" scope="col">
                    Total venta
                  </th>
                  <th role="columnheader" scope="col">
                    Total costo
                  </th>
                  <th role="columnheader" scope="col">
                    Utilidad bruta
                  </th>
                </tr>
              </thead>
              <tbody role="rowgroup">
                {query.data.items.map((i) => (
                  <tr role="row" key={i.productId}>
                    <td role="cell" data-label="Artículo">
                      {i.name}
                    </td>
                    <td role="cell" data-label="Cantidad">
                      {i.quantity}
                    </td>
                    <td role="cell" data-label="Venta unitaria">
                      {money(i.priceCents)}
                    </td>
                    <td role="cell" data-label="Costo unitario">
                      {money(i.costCents)}
                    </td>
                    <td role="cell" data-label="Total venta">
                      {money(i.salesCents)}
                    </td>
                    <td role="cell" data-label="Total costo">
                      {money(i.costTotalCents)}
                    </td>
                    <td role="cell" data-label="Utilidad bruta">
                      {money(i.grossCents)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )
      )}
    </Modal>
  );
}
