import { useDeferredValue, useEffect, useRef, useState } from 'react';
import { PackageSearch, Plus, Search, X } from 'lucide-react';
import { money } from '@saas/domain';
import type { Channel, Product } from '@saas/domain';
import { useProducts } from '@/features/products/hooks/useProducts';
import { Feedback } from '@/shared/ui/Feedback';

export function CatalogInventory({
  channel,
  quantities,
  onAdd,
  active = true,
}: {
  channel: Channel;
  quantities: Map<string, number>;
  onAdd: (product: Product) => void;
  active?: boolean;
}) {
  const [search, setSearch] = useState('');
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(5);
  const root = useRef<HTMLElement>(null);
  const capacityRef = useRef(5);
  const deferredSearch = useDeferredValue(search);
  const hasSearch = search.trim().length > 0;
  useEffect(() => {
    if (!active) return;
    const viewport = root.current?.querySelector<HTMLElement>('.inventory-results');
    if (!viewport) return;
    let frame = 0;
    const measure = () => {
      const height = viewport.getBoundingClientRect().height;
      if (height <= 0) return;
      const rowHeight =
        Number.parseFloat(getComputedStyle(viewport).getPropertyValue('--inventory-row-height')) ||
        72;
      // The viewport is sized by flex, independently of its rows; paginator space is always reserved.
      const shortViewport = (window.visualViewport?.height ?? window.innerHeight) <= 550;
      const capacity = shortViewport
        ? 1
        : Math.max(1, Math.min(20, Math.floor(height / rowHeight)));
      if (capacity !== capacityRef.current) {
        capacityRef.current = capacity;
        setPageSize(capacity);
        setPage(1);
      }
    };
    const schedule = () => {
      cancelAnimationFrame(frame);
      frame = requestAnimationFrame(measure);
    };
    measure();
    const observer = typeof ResizeObserver !== 'undefined' ? new ResizeObserver(schedule) : null;
    observer?.observe(viewport);
    window.addEventListener('resize', schedule);
    window.visualViewport?.addEventListener('resize', schedule);
    return () => {
      cancelAnimationFrame(frame);
      observer?.disconnect();
      window.removeEventListener('resize', schedule);
      window.visualViewport?.removeEventListener('resize', schedule);
    };
  }, [active]);
  const stockSort = channel === 'retail' ? 'retail-desc' : 'orders-desc';
  const products = useProducts(deferredSearch, page, true, pageSize, active, {
    sort: stockSort,
    ...(channel === 'retail' ? { stock: 'retail-positive' as const } : {}),
  });
  const displayResults = deferredSearch === search && !products.isPlaceholderData;
  const pages = Math.max(1, Math.ceil((products.data?.total ?? 0) / pageSize));
  return (
    <section ref={root} className="catalog-inventory" aria-label="Búsqueda de productos">
      <div className="inventory-search field">
        <label htmlFor="sale-product-search">Buscar por nombre o código</label>
        <div>
          <Search size={18} aria-hidden="true" />
          <input
            id="sale-product-search"
            placeholder="Ej. guantes, Calzado, Small o PRD-000028"
            value={search}
            onChange={(event) => {
              setSearch(event.target.value);
              setPage(1);
            }}
            onKeyDown={(event) => {
              if (event.key === 'Enter') event.preventDefault();
            }}
          />
          {search && (
            <button
              type="button"
              aria-label="Limpiar búsqueda"
              onClick={() => {
                setSearch('');
                setPage(1);
              }}
            >
              <X size={17} />
            </button>
          )}
        </div>
      </div>
      <Feedback error={products.error} />
      <p className="inventory-search-hint">
        {hasSearch
          ? 'Resultados ordenados por existencias disponibles.'
          : `Productos con más stock de ${channel === 'retail' ? 'menudeo' : 'pedidos'}. Busca para encontrar otro artículo.`}
      </p>
      <div className="inventory-columns" aria-hidden="true">
        <span>Artículo</span>
        <span>Precio / Stock</span>
        <span>Agregar</span>
      </div>
      <div className="inventory-results" aria-busy={products.isFetching}>
        {(!displayResults || (!products.data && products.isPending)) && (
          <p className="empty-state">Consultando inventario…</p>
        )}
        <ul className="inventory-list" aria-label="Artículos del inventario">
          {displayResults &&
            products.data?.items
              .filter((product) => hasSearch || channel !== 'retail' || product.retailStock > 0)
              .sort((a, b) => {
                const stockA = channel === 'retail' ? a.retailStock : a.ordersStock;
                const stockB = channel === 'retail' ? b.retailStock : b.ordersStock;
                return stockB - stockA;
              })
              .map((product) => {
                const stock = channel === 'retail' ? product.retailStock : product.ordersStock;
                const quantity = quantities.get(product.id) ?? 0;
                const blocked =
                  quantity >= 100000 ||
                  (channel === 'retail' && quantity >= stock) ||
                  (!quantities.has(product.id) && quantities.size >= 100);
                return (
                  <li key={product.id} className={quantity > 0 ? 'is-selected' : ''}>
                    <div className="inventory-identity">
                      {(product.category || product.subcategory) && (
                        <div className="product-tags">
                          {product.category && (
                            <span className="product-category-badge">{product.category}</span>
                          )}
                          {product.subcategory && (
                            <span className="product-subcategory-badge">{product.subcategory}</span>
                          )}
                        </div>
                      )}
                      <strong title={product.name}>{product.name}</strong>
                      <small>
                        {product.sku}
                        {product.color && ` · Color: ${product.color}`}
                        {product.size && ` · Talla ${product.size}`}
                        {quantity > 0 && (
                          <span className="inventory-selected"> · {quantity} agregados</span>
                        )}
                      </small>
                    </div>
                    <div className="inventory-values">
                      <strong>{money(product.priceCents)}</strong>
                      <span className={stock === 0 ? 'inventory-no-stock' : ''}>
                        {stock === 0 ? 'Sin stock' : `${stock.toLocaleString('es-PE')} disponibles`}
                      </span>
                    </div>
                    <button
                      className="inventory-add"
                      type="button"
                      aria-label={`Agregar ${product.name}`}
                      disabled={blocked}
                      title={
                        blocked
                          ? 'Sin unidades disponibles o límite de operación alcanzado'
                          : 'Agregar una unidad'
                      }
                      onClick={() => onAdd(product)}
                    >
                      <Plus size={18} />
                      <span className="sr-only">Agregar</span>
                    </button>
                  </li>
                );
              })}
        </ul>
        {displayResults && products.data && !products.data.items.length && (
          <div className="empty-state">
            <PackageSearch size={30} />
            <p>
              {hasSearch
                ? 'No hay coincidencias. Prueba otro nombre o código.'
                : channel === 'retail'
                  ? 'No hay productos con stock de menudeo. Ajusta existencias en Productos.'
                  : 'No hay productos activos. Regístralos en Productos.'}
            </p>
          </div>
        )}
      </div>
      <div className="inventory-pagination">
        <span>
          {displayResults && products.data
            ? `${products.data.total} artículos · ${page}/${pages}`
            : 'Buscando…'}
        </span>
        <div>
          <button
            type="button"
            className="button secondary"
            disabled={!displayResults || !products.data || page <= 1 || products.isFetching}
            onClick={() => setPage(page - 1)}
          >
            Anterior
          </button>
          <button
            type="button"
            className="button secondary"
            disabled={!displayResults || !products.data || page >= pages || products.isFetching}
            onClick={() => setPage(page + 1)}
          >
            Siguiente
          </button>
        </div>
      </div>
      <p className="inventory-note">
        {channel === 'retail'
          ? 'El stock corresponde a menudeo. Los artículos sin existencias no se pueden agregar.'
          : 'El stock corresponde a pedidos. Puedes programar sin existencias; se validarán al entregar.'}
      </p>
    </section>
  );
}
