import { SalesWorkspace } from '@/features/transactions/components/SalesWorkspace';
export function Component() {
  return <SalesWorkspace channel="retail" />;
}
