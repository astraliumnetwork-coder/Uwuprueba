import { z } from 'zod';
import { supabase } from '@/shared/supabase/client';
import { throwSupabaseError } from '@/shared/supabase/errors';
const pendingOrderSchema = z.object({
  id: z.string().uuid(),
  customer: z.string(),
  scheduled_for: z.string().nullable(),
  created_at: z.string(),
});
export const dashboardApi = {
  async pendingOrders(signal: AbortSignal) {
    const { data, error, count } = await supabase
      .from('sales')
      .select('id,customer,scheduled_for,created_at', { count: 'exact' })
      .eq('channel', 'orders')
      .eq('status', 'pending')
      .order('scheduled_for', { ascending: true, nullsFirst: false })
      .order('created_at', { ascending: true })
      .order('id')
      .limit(5)
      .abortSignal(signal);
    if (error) throwSupabaseError(error);
    return { items: z.array(pendingOrderSchema).parse(data ?? []), total: count ?? 0 };
  },
};
