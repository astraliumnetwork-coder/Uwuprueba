import { cleanup, fireEvent, render, screen, within } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { Component } from './DashboardPage';
const { state } = vi.hoisted(() => ({ state: { empty: false, negative: false, failed: false } }));
vi.mock('@/features/finance/hooks/useFinance', () => ({
  useReport: (from: string, to: string) => ({
    isPending: false,
    error: state.failed ? new Error('Sin conexión') : null,
    data: state.failed
      ? undefined
      : {
          salesCents: state.empty ? 0 : from === to ? 10000 : 25000,
          costTotalCents: state.empty ? 0 : from === to ? 6000 : 11000,
          grossCents: state.empty ? 0 : from === to ? 4000 : 14000,
          expensesCents: state.empty ? 0 : from === to ? 500 : 800,
          netCents: state.empty ? 0 : state.negative ? -1000 : from === to ? 3500 : 13200,
          transactions: state.empty ? 0 : 2,
          daily: state.empty
            ? []
            : [
                {
                  date: '2026-10-19',
                  salesCents: 6000,
                  costTotalCents: 2000,
                  expensesCents: 100,
                  netCents: 3900,
                },
                {
                  date: '2026-10-20',
                  salesCents: 9000,
                  costTotalCents: 3000,
                  expensesCents: 200,
                  netCents: 5800,
                },
                {
                  date: '2026-10-21',
                  salesCents: 10000,
                  costTotalCents: 6000,
                  expensesCents: 500,
                  netCents: 3500,
                },
              ],
          byPayment: state.empty
            ? []
            : [
                { payment: 'cash', salesCents: 7000 },
                { payment: 'yape', salesCents: 3000 },
              ],
        },
  }),
}));
beforeEach(() => {
  vi.useFakeTimers();
  vi.setSystemTime(new Date('2026-10-21T16:00:00Z'));
  state.empty = false;
  state.negative = false;
  state.failed = false;
});
afterEach(() => {
  cleanup();
  vi.useRealTimers();
});
vi.mock('../hooks/usePendingOrders', () => ({
  usePendingOrders: () => ({
    isFetching: false,
    error: null,
    data: state.failed
      ? undefined
      : {
          total: state.empty ? 0 : 8,
          items: state.empty
            ? []
            : [
                {
                  id: 'a',
                  customer: 'Cliente de prueba',
                  scheduled_for: '2026-10-20',
                  created_at: '2026-10-19T12:00:00Z',
                },
              ],
        },
  }),
}));
vi.mock('@/features/transactions/components/SaleDetail', () => ({
  SaleDetail: ({ id, onClose }: { id: string; onClose: () => void }) => (
    <div role="dialog" aria-label="Detalle del pedido">
      {id}
      <button onClick={onClose}>Cerrar detalle</button>
    </div>
  ),
}));
function renderDashboard() {
  return render(
    <MemoryRouter>
      <Component />
    </MemoryRouter>,
  );
}
describe('Operations center', () => {
  it('shows real daily metrics, weekly ticket/margin and selectable daily sales', () => {
    renderDashboard();
    const daily = within(screen.getByRole('region', { name: 'Resultados de hoy' }));
    expect(daily.getByText('S/ 100.00')).toBeVisible();
    expect(daily.getByText('S/ 35.00')).toBeVisible();
    const trend = within(screen.getByRole('region', { name: 'Ventas de la semana' }));
    expect(trend.getByText('S/ 125.00')).toBeVisible();
    expect(trend.getByText('56%')).toBeVisible();
    fireEvent.click(trend.getByRole('button', { name: /19.*60.00/ }));
    expect(trend.getByText('S/ 60.00')).toBeVisible();
    expect(trend.getByRole('button', { name: /19.*60.00/ })).toHaveAttribute(
      'aria-pressed',
      'true',
    );
    expect(screen.getByText('Yape')).toBeVisible();
    expect(screen.getByText('S/ 70.00')).toBeVisible();
    expect(screen.getByRole('link', { name: 'Registrar venta' })).toHaveAttribute(
      'href',
      '/menudeo?nueva=1',
    );
    expect(screen.getByRole('link', { name: /Nuevo pedido/ })).toHaveAttribute(
      'href',
      '/pedidos?nueva=1',
    );
  });
  it('replaces empty charts with compact actionable states and avoids undefined ratios', () => {
    state.empty = true;
    renderDashboard();
    expect(screen.getByText('Aún no hay ventas esta semana')).toBeVisible();
    expect(screen.queryByRole('button', { name: /19.*0.00/ })).not.toBeInTheDocument();
    const trend = within(screen.getByRole('region', { name: 'Ventas de la semana' }));
    expect(trend.getAllByText('—')).toHaveLength(2);
    expect(screen.getByText('Sin ventas registradas hoy')).toBeVisible();
    expect(screen.getByText('No tienes pedidos pendientes')).toBeVisible();
  });
  it('distinguishes losses from positive results', () => {
    state.negative = true;
    renderDashboard();
    const daily = within(screen.getByRole('region', { name: 'Resultados de hoy' }));
    expect(daily.getByText('-S/ 10.00')).toHaveClass('negative');
    expect(screen.getByText(/Faltan.*10.00.*para cubrir/)).toBeVisible();
  });
  it('shows the total pending count and opens a specific order without changing its status', () => {
    renderDashboard();
    const pending = within(screen.getByRole('region', { name: /Pedidos por atender/ }));
    expect(pending.getByText('8')).toBeVisible();
    expect(pending.getByText('Atrasado')).toBeVisible();
    fireEvent.click(pending.getByRole('button', { name: 'Ver pedido de Cliente de prueba' }));
    expect(screen.getByRole('dialog', { name: 'Detalle del pedido' })).toBeVisible();
    fireEvent.click(screen.getByRole('button', { name: 'Cerrar detalle' }));
    expect(screen.queryByRole('dialog')).not.toBeInTheDocument();
  });
  it('does not present unloaded data as zero sales or no pending orders', () => {
    state.failed = true;
    renderDashboard();
    expect(screen.queryByText('Aún no hay ventas esta semana')).not.toBeInTheDocument();
    expect(screen.queryByText('No tienes pedidos pendientes')).not.toBeInTheDocument();
    expect(screen.getByText('No se pudo cargar el resumen semanal.')).toBeVisible();
  });
});
