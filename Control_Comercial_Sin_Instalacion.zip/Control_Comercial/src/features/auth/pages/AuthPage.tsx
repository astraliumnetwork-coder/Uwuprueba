import { useState } from 'react';
import type { FormEvent } from 'react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { Navigate } from 'react-router-dom';
import { credentialsSchema } from '@saas/domain';
import { authApi } from '../api/auth.api';
import { useSession } from '../hooks/useSession';
export function Component() {
  const session = useSession();
  const client = useQueryClient();
  const [error, setError] = useState('');
  const action = useMutation({
    mutationFn: authApi.login,
    onSuccess: async (data) => {
      await client.cancelQueries();
      client.clear();
      client.setQueryData(['session'], data);
    },
  });
  if (session.data) return <Navigate to="/" replace />;
  function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    const result = credentialsSchema.safeParse({
      email: form.get('email'),
      password: form.get('password'),
    });
    if (!result.success) {
      setError(result.error.issues[0]?.message ?? 'Revisa los datos.');
      return;
    }
    setError('');
    action.mutate(result.data);
  }
  return (
    <main className="auth-shell">
      <section className="auth-card">
        <p className="eyebrow">CONTROL COMERCIAL</p>
        <h1>Iniciar sesión</h1>
        <p className="muted">Accede a tu empresa y continúa trabajando.</p>
        <form onSubmit={submit} className="settings-form">
          <fieldset disabled={action.isPending}>
            <div className="field">
              <label htmlFor="email">Correo</label>
              <input
                id="email"
                name="email"
                type="email"
                autoComplete="username"
                defaultValue="admin@sistema.com"
                required
              />
            </div>
            <div className="field">
              <label htmlFor="password">Contraseña</label>
              <input
                id="password"
                name="password"
                type="password"
                autoComplete="current-password"
                required
                maxLength={128}
              />
            </div>
            <button className="button primary" type="submit">
              {action.isPending ? 'Ingresando…' : 'Entrar'}
            </button>
          </fieldset>
          {(error || action.isError) && (
            <p role="alert" className="field-error">
              {error ||
                (action.error?.message === 'Invalid login credentials'
                  ? 'Correo o contraseña incorrectos. Verifica que la cuenta esté creada en Supabase.'
                  : action.error?.message)}
            </p>
          )}
        </form>
      </section>
    </main>
  );
}
