import { sessionSchema } from '@saas/domain';
import { supabase } from '@/shared/supabase/client';
import { throwSupabaseError } from '@/shared/supabase/errors';

async function currentSession() {
  const { data, error } = await supabase.auth.getSession();
  if (error) throw error;
  const authUser = data.session?.user;
  if (!authUser || authUser.is_anonymous) return null;

  const profile = await supabase.from('users').select('tenant_id').eq('id', authUser.id).single();
  if (profile.error) throwSupabaseError(profile.error);
  const tenant = await supabase
    .from('tenants')
    .select('name')
    .eq('id', profile.data.tenant_id)
    .single();
  if (tenant.error) throwSupabaseError(tenant.error);

  return sessionSchema.parse({
    userId: authUser.id,
    tenantId: profile.data.tenant_id,
    email: authUser.email?.trim() || 'Acceso temporal',
    organizationName: tenant.data.name,
  });
}

export const authApi = {
  session: currentSession,
  async login(input: { email: string; password: string }) {
    const { error } = await supabase.auth.signInWithPassword(input);
    if (error) throw error;
    return currentSession();
  },
  async register(input: { email: string; password: string; organizationName: string }) {
    const { data, error } = await supabase.auth.signUp({
      email: input.email,
      password: input.password,
      options: {
        data: { organization_name: input.organizationName },
        emailRedirectTo: window.location.origin,
      },
    });
    if (error) throw error;
    return data.session ? currentSession() : null;
  },
  async logout() {
    const { error } = await supabase.auth.signOut();
    if (error) throw error;
  },
};
