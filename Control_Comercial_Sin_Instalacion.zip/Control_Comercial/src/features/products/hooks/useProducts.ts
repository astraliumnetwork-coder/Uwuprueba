import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { useTenantId } from '@/features/auth/hooks/useSession';
import { type ProductFilters, productsApi } from '../api/products.api';
export function useProducts(
  search = '',
  page = 1,
  activeOnly = false,
  pageSize = 25,
  enabled = true,
  filters: ProductFilters = {},
) {
  const tenant = useTenantId();
  return useQuery<Awaited<ReturnType<typeof productsApi.list>>>({
    enabled,
    queryKey: [tenant, 'products', search, page, activeOnly, pageSize, filters],
    placeholderData: (previous, previousQuery) =>
      previousQuery?.queryKey[0] === tenant ? previous : undefined,
    queryFn: ({ signal }) => productsApi.list(search, page, signal, activeOnly, pageSize, filters),
  });
}
export function useProductAction() {
  const client = useQueryClient();
  const tenant = useTenantId();
  return useMutation({
    mutationFn: async (v: {
      kind: 'create' | 'update' | 'stock';
      id?: string;
      body: unknown;
      key?: string;
    }) =>
      v.kind === 'create'
        ? productsApi.create(v.body)
        : v.kind === 'update'
          ? productsApi.update(v.id!, v.body, v.key)
          : productsApi.stock(v.id!, v.body, v.key!),
    onSuccess: () => client.invalidateQueries({ queryKey: [tenant, 'products'] }),
  });
}

export function useDeleteProduct() {
  const client = useQueryClient();
  const tenant = useTenantId();
  return useMutation({
    mutationFn: productsApi.remove,
    onSuccess: () => client.invalidateQueries({ queryKey: [tenant] }),
  });
}
