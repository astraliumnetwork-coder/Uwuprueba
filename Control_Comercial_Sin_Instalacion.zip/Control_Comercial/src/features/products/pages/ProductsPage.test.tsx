import { cleanup, fireEvent, render, screen } from '@testing-library/react';
import { afterEach, expect, it, vi } from 'vitest';
import { Component } from './ProductsPage';
const { query } = vi.hoisted(() => ({ query: vi.fn() }));
vi.mock('../hooks/useProducts', () => ({
  useProducts: (...args: unknown[]) => {
    query(...args);
    return {
      data: {
        items: [
          {
            id: 'product-1',
            category: 'Protección de manos',
            subcategory: 'Steelpro',
            name: 'Guantes anticorte',
            size: 'S',
            sku: 'PRD-000001',
            priceCents: 1500,
            costCents: 1000,
            retailStock: 4,
            ordersStock: 0,
            active: true,
          },
        ],
        total: 70,
        page: args[1],
        pageSize: args[3],
      },
      isPending: false,
      isFetching: false,
      error: null,
    };
  },
}));
vi.mock('../components/ProductEditor', () => ({
  ProductEditor: ({
    onSaved,
    onDone,
  }: {
    onSaved: (saved: { id: string; name: string }) => void;
    onDone: () => void;
  }) => (
    <div>
      <button
        onClick={() => {
          onSaved({ id: 'product-1', name: 'Zapatos' });
          onDone();
        }}
      >
        Guardar prueba
      </button>
      <button onClick={onDone}>Cancelar prueba</button>
    </div>
  ),
}));
afterEach(() => {
  cleanup();
  vi.clearAllMocks();
});
it('keeps the full list and current filters after editing and shows a transient notice', () => {
  render(<Component />);
  expect(screen.getAllByText('S').length).toBeGreaterThan(0);
  expect(screen.getAllByText('Protección de manos').length).toBeGreaterThan(0);
  expect(screen.getAllByText('Steelpro').length).toBeGreaterThan(0);
  fireEvent.change(screen.getByLabelText('Existencias'), { target: { value: 'retail-positive' } });
  fireEvent.click(screen.getByRole('button', { name: 'Siguiente' }));
  fireEvent.click(screen.getByRole('button', { name: 'Acciones de Guantes anticorte' }));
  fireEvent.click(screen.getByRole('button', { name: 'Editar producto' }));
  fireEvent.click(screen.getByText('Guardar prueba'));
  expect(query.mock.lastCall).toEqual([
    '',
    2,
    false,
    25,
    true,
    { stock: 'retail-positive', sort: 'sku-desc' },
  ]);
  expect(screen.getByText('Ítem editado correctamente')).toBeInTheDocument();
  expect(screen.queryByText('Ver todo el inventario')).not.toBeInTheDocument();
});
it('filters by category and subcategory and resets page on filter changes', () => {
  render(<Component />);
  fireEvent.change(screen.getByLabelText('Categoría'), { target: { value: 'Calzado industrial' } });
  expect(query.mock.lastCall?.[5]).toEqual({ category: 'Calzado industrial', sort: 'sku-desc' });
  fireEvent.change(screen.getByLabelText('Subcategoría'), {
    target: { value: 'Botines dieléctricos' },
  });
  expect(query.mock.lastCall?.[5]).toEqual({
    category: 'Calzado industrial',
    subcategory: 'Botines dieléctricos',
    sort: 'sku-desc',
  });
  fireEvent.change(screen.getByLabelText('Existencias'), { target: { value: 'orders-zero' } });
  fireEvent.click(screen.getByRole('button', { name: 'Siguiente' }));
  fireEvent.click(screen.getByRole('button', { name: 'Acciones de Guantes anticorte' }));
  fireEvent.click(screen.getByRole('button', { name: 'Editar producto' }));
  fireEvent.click(screen.getByText('Cancelar prueba'));
  expect(query.mock.lastCall?.[1]).toBe(2);
  expect(query.mock.lastCall?.[5]).toEqual({
    category: 'Calzado industrial',
    subcategory: 'Botines dieléctricos',
    stock: 'orders-zero',
    sort: 'sku-desc',
  });
  fireEvent.click(screen.getAllByRole('button', { name: 'Ordenar por Menudeo' })[0]!);
  expect(query.mock.lastCall?.[1]).toBe(1);
});
