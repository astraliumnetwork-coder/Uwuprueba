import { useDeferredValue, useEffect, useState } from 'react';
import { ArrowDown, ArrowUp, ArrowUpDown, Package, Plus, Search } from 'lucide-react';
import {
  getSubcategoriesForCategory,
  money,
  productCategories,
  productCategoryGroups,
} from '@saas/domain';
import type { Product } from '@saas/domain';
import type { ProductFilters } from '../api/products.api';
import { useProducts } from '../hooks/useProducts';
import { ProductEditor } from '../components/ProductEditor';
import { DeleteProduct } from '../components/DeleteProduct';
import { ProductActions } from '../components/ProductActions';
import { StockEditor } from '../components/StockEditor';
import { Pagination } from '@/shared/ui/Pagination';
import { Feedback } from '@/shared/ui/Feedback';

export function Component() {
  const [search, setSearch] = useState('');
  const [page, setPage] = useState(1);
  const [editor, setEditor] = useState<Product | 'new' | null>(null);
  const [stock, setStock] = useState<Product | null>(null);
  const [filters, setFilters] = useState<ProductFilters>({ sort: 'sku-desc' });
  const [pageSize, setPageSize] = useState(25);
  const [notice, setNotice] = useState<{ text: string } | null>(null);
  const [deleting, setDeleting] = useState<Product | null>(null);
  useEffect(() => {
    if (!notice) return;
    const timer = window.setTimeout(() => setNotice(null), 4000);
    return () => window.clearTimeout(timer);
  }, [notice]);
  const query = useProducts(useDeferredValue(search), page, false, pageSize, true, filters);
  const hasActiveFilters = Boolean(
    search.trim() ||
    (filters.stock && filters.stock !== 'all') ||
    (filters.category && filters.category !== 'all') ||
    (filters.subcategory && filters.subcategory !== 'all'),
  );
  const activeSubcategories = getSubcategoriesForCategory(filters.category);

  function changeFilters(next: ProductFilters) {
    setFilters(next);
    setPage(1);
  }
  function selectCategoryFilter(categoryValue: string) {
    const next: ProductFilters = { ...filters };
    delete next.subcategory;
    if (!categoryValue || categoryValue === 'all') {
      delete next.category;
    } else {
      next.category = categoryValue;
    }
    changeFilters(next);
  }
  function selectSubcategoryFilter(subcategoryValue: string, parentCategory?: string) {
    const next: ProductFilters = { ...filters };
    if (parentCategory && parentCategory !== 'all') {
      next.category = parentCategory;
    }
    if (!subcategoryValue || subcategoryValue === 'all') {
      delete next.subcategory;
    } else {
      next.subcategory = subcategoryValue;
    }
    changeFilters(next);
  }
  function clearFilters() {
    setSearch('');
    changeFilters({ sort: 'sku-desc' });
  }
  function toggleSort(field: 'name' | 'sku' | 'retail' | 'orders') {
    changeFilters({
      ...filters,
      sort: `${field}-${filters.sort === `${field}-asc` ? 'desc' : 'asc'}`,
    });
  }
  function sortButton(field: 'name' | 'sku' | 'retail' | 'orders', label: string) {
    const selected = filters.sort?.startsWith(`${field}-`);
    const Icon = selected ? (filters.sort?.endsWith('asc') ? ArrowUp : ArrowDown) : ArrowUpDown;
    return (
      <button
        type="button"
        className="inventory-sort"
        onClick={() => toggleSort(field)}
        aria-label={`Ordenar por ${label}`}
        title={selected ? 'Invertir orden' : `Ordenar por ${label}`}
      >
        {label}
        <Icon size={15} aria-hidden="true" />
      </button>
    );
  }
  function ariaSort(field: string): 'ascending' | 'descending' | 'none' {
    return filters.sort?.startsWith(`${field}-`)
      ? filters.sort.endsWith('asc')
        ? 'ascending'
        : 'descending'
      : 'none';
  }
  return (
    <div className="page products-page">
      <div className="page-heading">
        <div>
          <p className="eyebrow">CATÁLOGO E INVENTARIO</p>
          <h1>Productos</h1>
          <p className="muted">Precios, rentabilidad y existencias por línea de negocio.</p>
        </div>
        <button
          className="button primary"
          onClick={() => {
            setEditor('new');
            setStock(null);
          }}
        >
          <Plus size={18} />
          Nuevo producto
        </button>
      </div>
      {editor && (
        <ProductEditor
          key={typeof editor === 'string' ? editor : editor.id}
          {...(editor === 'new' ? {} : { product: editor })}
          onDone={() => setEditor(null)}
          onSaved={() => {
            setNotice({
              text: editor === 'new' ? 'Ítem creado correctamente' : 'Ítem editado correctamente',
            });
          }}
        />
      )}
      {stock && <StockEditor key={stock.id} product={stock} onDone={() => setStock(null)} />}
      {deleting && (
        <DeleteProduct
          product={deleting}
          onClose={() => setDeleting(null)}
          onDeleted={() => {
            setDeleting(null);
            setNotice({ text: 'Ítem borrado correctamente' });
            if (query.data?.items.length === 1 && page > 1) setPage(page - 1);
          }}
        />
      )}
      {notice && (
        <div className="product-toast" role="status">
          {notice.text}
          <button aria-label="Cerrar aviso" onClick={() => setNotice(null)}>
            ×
          </button>
        </div>
      )}
      <section className="panel products-panel">
        <div className="products-toolbar">
          <div>
            <h2>Catálogo de artículos</h2>
            <p className="muted" role="status">
              {query.data
                ? `${query.data.total} productos${hasActiveFilters ? ' encontrados' : ' registrados'}`
                : 'Consultando catálogo…'}
            </p>
          </div>
          <div className="field product-search">
            <label className="sr-only" htmlFor="product-search">
              Buscar por código, categoría, subcategoría, color o artículo
            </label>
            <Search size={18} aria-hidden="true" />
            <input
              id="product-search"
              placeholder="Buscar artículo, categoría, subcategoría, color, talla o código…"
              value={search}
              onChange={(e) => {
                setSearch(e.target.value);
                changeFilters({ ...filters });
              }}
            />
          </div>
        </div>

        <div className="inventory-filters">
          <label className="field">
            Categoría
            <select
              value={filters.category ?? 'all'}
              className={filters.category && filters.category !== 'all' ? 'has-value' : ''}
              onChange={(e) => selectCategoryFilter(e.target.value)}
            >
              <option value="all">Todas las categorías</option>
              {productCategories.map((category) => (
                <option key={category} value={category}>
                  {category}
                </option>
              ))}
            </select>
          </label>
          <label className="field">
            Subcategoría
            <select
              value={filters.subcategory ?? 'all'}
              className={filters.subcategory && filters.subcategory !== 'all' ? 'has-value' : ''}
              onChange={(e) => {
                const rawVal = e.target.value;
                if (rawVal === 'all') {
                  selectSubcategoryFilter('all');
                } else if (rawVal.includes('::')) {
                  const [parentCat = '', subVal = ''] = rawVal.split('::');
                  selectSubcategoryFilter(subVal, parentCat);
                } else {
                  selectSubcategoryFilter(rawVal);
                }
              }}
            >
              <option value="all">Todas las subcategorías</option>
              {activeSubcategories.length > 0
                ? activeSubcategories.map((sub) => (
                    <option key={sub} value={sub}>
                      {sub}
                    </option>
                  ))
                : productCategoryGroups.map((group) => (
                    <optgroup key={group.id} label={group.category}>
                      {group.subcategories.map((sub) => (
                        <option key={`${group.id}-${sub}`} value={`${group.category}::${sub}`}>
                          {sub}
                        </option>
                      ))}
                    </optgroup>
                  ))}
            </select>
          </label>
          <label className="field">
            Existencias
            <select
              value={filters.stock ?? 'all'}
              className={filters.stock && filters.stock !== 'all' ? 'has-value' : ''}
              onChange={(e) =>
                changeFilters({
                  ...filters,
                  stock: e.target.value as NonNullable<ProductFilters['stock']>,
                })
              }
            >
              <option value="all">Todas las existencias</option>
              <option value="retail-positive">Menudeo · Con stock</option>
              <option value="retail-zero">Menudeo · Sin stock</option>
              <option value="orders-positive">Pedidos · Con stock</option>
              <option value="orders-zero">Pedidos · Sin stock</option>
            </select>
          </label>
          <label className="field">
            Por página
            <select
              value={pageSize}
              onChange={(e) => {
                setPageSize(Number(e.target.value));
                setPage(1);
              }}
            >
              <option value={10}>10 productos</option>
              <option value={25}>25 productos</option>
              <option value={50}>50 productos</option>
            </select>
          </label>
          <button className="button secondary" onClick={clearFilters}>
            Restablecer
          </button>
        </div>
        <div className="inventory-order-controls">
          <span>
            Orden:{' '}
            {
              {
                'sku-desc': 'Últimos creados',
                'sku-asc': 'Código ascendente',
                'name-asc': 'Nombre A–Z',
                'name-desc': 'Nombre Z–A',
                'retail-asc': 'Menudeo · Menor stock primero',
                'retail-desc': 'Menudeo · Mayor stock primero',
                'orders-asc': 'Pedidos · Menor stock primero',
                'orders-desc': 'Pedidos · Mayor stock primero',
              }[filters.sort ?? 'sku-desc']
            }
          </span>
          <div className="inventory-mobile-sort">
            {sortButton('name', 'Artículo')}
            {sortButton('sku', 'Código')}
            {sortButton('retail', 'Menudeo')}
            {sortButton('orders', 'Pedidos')}
          </div>
        </div>
        {query.isFetching && (
          <p className="inventory-loading" role="status">
            Actualizando resultados…
          </p>
        )}
        <Feedback error={query.error} />
        {query.isPending ? (
          <p className="empty-state">Cargando catálogo…</p>
        ) : (
          query.data && (
            <>
              <div className="table-scroll">
                <table role="table" className="products-table products-table-v2">
                  <thead role="rowgroup">
                    <tr role="row">
                      <th scope="col" aria-sort={ariaSort('sku')}>
                        {sortButton('sku', 'Código')}
                      </th>
                      <th scope="col" aria-sort={ariaSort('name')}>
                        {sortButton('name', 'Producto')}
                      </th>
                      <th scope="col">Talla</th>
                      <th scope="col" className="numeric">
                        Venta unitaria
                      </th>
                      <th scope="col" className="numeric">
                        Costo unitario
                      </th>
                      <th role="columnheader" scope="col" className="numeric">
                        Utilidad / Margen
                      </th>
                      <th
                        role="columnheader"
                        scope="col"
                        className="numeric"
                        aria-sort={ariaSort('retail')}
                      >
                        {sortButton('retail', 'Menudeo')}
                      </th>
                      <th
                        role="columnheader"
                        scope="col"
                        className="numeric"
                        aria-sort={ariaSort('orders')}
                      >
                        {sortButton('orders', 'Pedidos')}
                      </th>
                      <th role="columnheader" scope="col" className="product-actions-heading">
                        Gestión
                      </th>
                    </tr>
                  </thead>
                  <tbody role="rowgroup">
                    {query.data.items.map((p) => {
                      const profit = p.priceCents - p.costCents;
                      return (
                        <tr role="row" key={p.id}>
                          <td role="cell" data-label="Código" className="product-code">
                            {p.sku}
                          </td>
                          <td role="cell" data-label="Producto" className="product-name">
                            <div className="product-identity">
                              <span className="product-symbol">
                                <Package size={19} />
                              </span>
                              <div>
                                <div className="product-tags">
                                  {p.category && (
                                    <span className="product-category-badge">{p.category}</span>
                                  )}
                                  {p.subcategory && (
                                    <span className="product-subcategory-badge">
                                      {p.subcategory}
                                    </span>
                                  )}
                                  {p.color && (
                                    <span className="product-color-badge">{p.color}</span>
                                  )}
                                </div>
                                <strong>{p.name}</strong>
                              </div>
                            </div>
                          </td>
                          <td role="cell" data-label="Talla" className="product-size">
                            {p.size ? (
                              <span className="product-size-badge">{p.size}</span>
                            ) : (
                              <span className="muted">—</span>
                            )}
                          </td>
                          <td
                            role="cell"
                            data-label="Venta unitaria"
                            className="numeric product-price"
                          >
                            {money(p.priceCents)}
                          </td>
                          <td
                            role="cell"
                            data-label="Costo unitario"
                            className="numeric product-cost"
                          >
                            {money(p.costCents)}
                          </td>
                          <td
                            role="cell"
                            data-label="Utilidad / Margen"
                            className={`numeric product-profit ${profit < 0 ? 'negative' : ''}`}
                          >
                            <strong>{money(profit)}</strong>
                            <small>
                              {p.priceCents > 0
                                ? `${((profit / p.priceCents) * 100).toFixed(1)} % sobre venta`
                                : 'Sin base de margen'}
                            </small>
                          </td>
                          <td role="cell" data-label="Menudeo" className="numeric product-stock">
                            <span
                              className={`stock-value ${p.retailStock === 0 ? 'is-empty' : ''}`}
                            >
                              {p.retailStock.toLocaleString('es-PE')}
                            </span>
                          </td>
                          <td role="cell" data-label="Pedidos" className="numeric product-stock">
                            <span
                              className={`stock-value ${p.ordersStock === 0 ? 'is-empty' : ''}`}
                            >
                              {p.ordersStock.toLocaleString('es-PE')}
                            </span>
                          </td>
                          <td role="cell" data-label="Gestión">
                            <ProductActions
                              name={p.name}
                              onEdit={() => {
                                setEditor(p);
                                setStock(null);
                              }}
                              onStock={() => {
                                setStock(p);
                                setEditor(null);
                              }}
                              onDelete={() => setDeleting(p)}
                            />
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
              {!query.data.items.length && (
                <div className="empty-state">
                  <Package size={28} />
                  <p>
                    {hasActiveFilters
                      ? 'No hay productos que coincidan con estos filtros. Prueba limpiarlos.'
                      : 'Registra tu primer producto para comenzar.'}
                  </p>
                </div>
              )}
              <div className="products-pagination">
                <Pagination {...query.data} onChange={setPage} />
              </div>
            </>
          )
        )}
      </section>
    </div>
  );
}
