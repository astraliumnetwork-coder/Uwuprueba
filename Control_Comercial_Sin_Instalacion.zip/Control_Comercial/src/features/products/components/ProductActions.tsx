import { useEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { MoreHorizontal, Pencil, SlidersHorizontal, Trash2 } from 'lucide-react';
export function ProductActions({
  name,
  onEdit,
  onStock,
  onDelete,
}: {
  name: string;
  onEdit: () => void;
  onStock: () => void;
  onDelete: () => void;
}) {
  const button = useRef<HTMLButtonElement>(null);
  const panel = useRef<HTMLDivElement>(null);
  const [position, setPosition] = useState<{ top: number; left: number } | null>(null);
  useEffect(() => {
    if (!position) return;
    panel.current?.querySelector('button')?.focus();
    const close = () => setPosition(null);
    const outside = (e: PointerEvent) => {
      if (
        e.target instanceof Node &&
        !panel.current?.contains(e.target) &&
        !button.current?.contains(e.target)
      )
        close();
    };
    const key = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        close();
        button.current?.focus();
      }
    };
    window.addEventListener('pointerdown', outside);
    window.addEventListener('keydown', key);
    window.addEventListener('resize', close);
    window.addEventListener('scroll', close, true);
    return () => {
      window.removeEventListener('pointerdown', outside);
      window.removeEventListener('keydown', key);
      window.removeEventListener('resize', close);
      window.removeEventListener('scroll', close, true);
    };
  }, [position]);
  function choose(action: () => void) {
    setPosition(null);
    button.current?.focus();
    action();
  }
  return (
    <>
      <button
        ref={button}
        className="button secondary product-actions-trigger"
        aria-label={`Acciones de ${name}`}
        aria-expanded={!!position}
        onClick={() => {
          const rect = button.current!.getBoundingClientRect();
          setPosition(
            position
              ? null
              : {
                  left: Math.max(8, Math.min(rect.right - 208, window.innerWidth - 216)),
                  top:
                    rect.bottom + 194 > window.innerHeight
                      ? Math.max(8, rect.top - 194)
                      : rect.bottom + 6,
                },
          );
        }}
      >
        <MoreHorizontal size={19} />
        <span>Acciones</span>
      </button>
      {position &&
        createPortal(
          <div
            ref={panel}
            className="product-action-menu"
            style={position}
            aria-label={`Acciones de ${name}`}
            onBlur={(e) => {
              if (!e.currentTarget.contains(e.relatedTarget) && e.relatedTarget !== button.current)
                setPosition(null);
            }}
          >
            <button onClick={() => choose(onEdit)}>
              <Pencil size={17} />
              Editar producto
            </button>
            <button onClick={() => choose(onStock)}>
              <SlidersHorizontal size={17} />
              Ajustar stock
            </button>
            <button className="delete-action" onClick={() => choose(onDelete)}>
              <Trash2 size={17} />
              Borrar producto
            </button>
          </div>,
          document.body,
        )}
    </>
  );
}
