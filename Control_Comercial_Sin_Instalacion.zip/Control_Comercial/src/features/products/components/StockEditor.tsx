import { useRef, useState } from 'react';
import type { FormEvent } from 'react';
import { Save, ShoppingCart, Truck } from 'lucide-react';
import type { Product } from '@saas/domain';
import { useProductAction } from '../hooks/useProducts';
import { Modal } from '@/shared/ui/Modal';
import { Feedback } from '@/shared/ui/Feedback';

export function StockEditor({ product, onDone }: { product: Product; onDone: () => void }) {
  const action = useProductAction();
  const key = useRef(crypto.randomUUID());
  const [retail, setRetail] = useState(String(product.retailStock));
  const [orders, setOrders] = useState(String(product.ordersStock));
  const [reason, setReason] = useState('');

  const retailNum = Number(retail);
  const ordersNum = Number(orders);
  const retailDiff = Number.isInteger(retailNum) ? retailNum - product.retailStock : 0;
  const ordersDiff = Number.isInteger(ordersNum) ? ordersNum - product.ordersStock : 0;

  function submit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    action.mutate(
      {
        kind: 'stock',
        id: product.id,
        key: key.current,
        body: {
          retailStock: Number(retail),
          ordersStock: Number(orders),
          currentRetailStock: product.retailStock,
          currentOrdersStock: product.ordersStock,
          reason: reason.trim() || 'Actualización directa de existencias',
        },
      },
      { onSuccess: onDone },
    );
  }
  return (
    <Modal
      title={`Ajustar stock · ${product.name}${product.size ? ` (${product.size})` : ''}`}
      onClose={onDone}
      busy={action.isPending}
    >
      <form
        className="settings-form"
        onSubmit={submit}
        onChange={() => {
          key.current = crypto.randomUUID();
        }}
      >
        <fieldset disabled={action.isPending}>
          <div className="editor-stock-grid">
            <div className="editor-stock-channel">
              <span>
                <ShoppingCart size={18} />
                Menudeo
              </span>
              <p>
                Stock actual: <strong>{product.retailStock.toLocaleString('es-PE')}</strong>{' '}
                unidades
                {retailDiff !== 0 && (
                  <span className="stock-diff-pill">
                    {retailDiff > 0 ? ` (+${retailDiff})` : ` (${retailDiff})`}
                  </span>
                )}
              </p>
              <div className="field">
                <label htmlFor="stock-retail">Nueva cantidad · Menudeo</label>
                <input
                  id="stock-retail"
                  name="retailStock"
                  type="number"
                  inputMode="numeric"
                  min="0"
                  max="1000000"
                  step="1"
                  value={retail}
                  onChange={(e) => setRetail(e.target.value)}
                  required
                />
              </div>
            </div>
            <div className="editor-stock-channel">
              <span>
                <Truck size={18} />
                Pedidos
              </span>
              <p>
                Stock actual: <strong>{product.ordersStock.toLocaleString('es-PE')}</strong>{' '}
                unidades
                {ordersDiff !== 0 && (
                  <span className="stock-diff-pill">
                    {ordersDiff > 0 ? ` (+${ordersDiff})` : ` (${ordersDiff})`}
                  </span>
                )}
              </p>
              <div className="field">
                <label htmlFor="stock-orders">Nueva cantidad · Pedidos</label>
                <input
                  id="stock-orders"
                  name="ordersStock"
                  type="number"
                  inputMode="numeric"
                  min="0"
                  max="1000000"
                  step="1"
                  value={orders}
                  onChange={(e) => setOrders(e.target.value)}
                  required
                />
              </div>
            </div>
          </div>
          <div className="field">
            <label htmlFor="reason">Nota o motivo (opcional)</label>
            <input
              id="reason"
              name="reason"
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              placeholder="Ej. Conteo físico o reposición de mercadería"
              maxLength={200}
            />
          </div>
          <div className="modal-actions">
            <button type="button" className="button secondary" onClick={onDone}>
              Cancelar
            </button>
            <button className="button primary" type="submit">
              <Save size={17} />
              {action.isPending ? 'Guardando…' : 'Guardar cantidades'}
            </button>
          </div>
        </fieldset>
        <Feedback error={action.error} />
      </form>
    </Modal>
  );
}
