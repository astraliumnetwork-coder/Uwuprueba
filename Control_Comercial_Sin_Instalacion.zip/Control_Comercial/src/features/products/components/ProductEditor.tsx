import { useEffect, useRef, useState } from 'react';
import type { FormEvent } from 'react';
import {
  BadgeDollarSign,
  Boxes,
  Check,
  ChevronDown,
  Package,
  Palette,
  Save,
  ShoppingCart,
  Truck,
  X,
} from 'lucide-react';
import {
  bootSizes,
  getSubcategoriesForCategory,
  isFootwearCategory,
  money,
  parseMoney,
  productCategoryGroups,
  productColors,
  productInput,
  productSizes,
} from '@saas/domain';
import type { Product } from '@saas/domain';
import { errorMessage } from '@/shared/lib/error-message';
import { useProductAction } from '../hooks/useProducts';
import { Modal } from '@/shared/ui/Modal';
import { Feedback } from '@/shared/ui/Feedback';

const COLOR_DOTS: Record<string, string> = {
  Negro: '#1c1c1e',
  Blanco: '#ffffff',
  Azul: '#1976d2',
  Amarillo: '#f2ce13',
  Naranja: '#f18b00',
  Rojo: '#e03131',
  Verde: '#2f9e44',
  'Verde Fosforescente': '#76ff03',
  Plomo: '#90969b',
  Gris: '#868e96',
  Marrón: '#795548',
  Beige: '#d7c4b7',
  Celeste: '#4dabf7',
};

export function ProductEditor({
  product,
  onDone,
  onSaved,
}: {
  product?: Product;
  onDone: () => void;
  onSaved?: (saved: { id: string; name: string }) => void;
}) {
  const action = useProductAction();
  const [error, setError] = useState('');
  const [category, setCategory] = useState(product?.category ?? '');
  const [subcategory, setSubcategory] = useState(product?.subcategory ?? '');

  const [color, setColor] = useState(product?.color ?? '');
  const [createColorVariants, setCreateColorVariants] = useState(false);

  const [name, setName] = useState(product?.name ?? '');
  const [size, setSize] = useState(product?.size ?? '');
  const [sizeDropdownOpen, setSizeDropdownOpen] = useState(false);
  const sizeWrapperRef = useRef<HTMLDivElement>(null);

  const [price, setPrice] = useState(product ? (product.priceCents / 100).toFixed(2) : '');
  const [cost, setCost] = useState(product ? (product.costCents / 100).toFixed(2) : '');
  const [retail, setRetail] = useState(String(product?.retailStock ?? 0));
  const [orders, setOrders] = useState(String(product?.ordersStock ?? 0));
  const stockKey = useRef(crypto.randomUUID());

  const activeSubcategories = getSubcategoriesForCategory(category);

  // Detección automática: si la categoría o subcategoría es calzado, aplica calzado (35 al 46); si no, talla normal (S a XXXL)
  const isShoe =
    isFootwearCategory(category, subcategory) ||
    isFootwearCategory(name) ||
    Boolean(size && bootSizes.some((b) => size.includes(b)));

  useEffect(() => {
    if (!sizeDropdownOpen) return;
    const handleOutside = (event: PointerEvent) => {
      if (event.target instanceof Node && !sizeWrapperRef.current?.contains(event.target)) {
        setSizeDropdownOpen(false);
      }
    };
    window.addEventListener('pointerdown', handleOutside);
    return () => window.removeEventListener('pointerdown', handleOutside);
  }, [sizeDropdownOpen]);

  function handleCategoryChange(nextCat: string) {
    setCategory(nextCat);
    const nextSubs = getSubcategoriesForCategory(nextCat);
    if (
      subcategory &&
      !nextSubs.some((s) => s.toLowerCase() === subcategory.trim().toLowerCase())
    ) {
      setSubcategory('');
    }
  }

  const selectedColors = color
    .split(',')
    .map((c) => c.trim())
    .filter(Boolean);

  function toggleColor(col: string) {
    let next: string[];
    if (selectedColors.includes(col)) {
      next = selectedColors.filter((c) => c !== col);
    } else {
      next = [...selectedColors, col];
    }
    setColor(next.join(', '));
  }

  let loss: number | null = null;
  try {
    loss = parseMoney(cost) - parseMoney(price);
  } catch {
    /* Amounts may be incomplete while typing. */
  }

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const data = new FormData(event.currentTarget);
    try {
      setError('');
      if (!product && createColorVariants && selectedColors.length > 1) {
        for (const singleColor of selectedColors) {
          const variantName = name.trim().toLowerCase().includes(singleColor.toLowerCase())
            ? name.trim()
            : `${name.trim()} - ${singleColor}`;
          const input = productInput.parse({
            sku: 'AUTO',
            category,
            subcategory,
            color: singleColor,
            name: variantName,
            size,
            priceCents: parseMoney(price),
            costCents: parseMoney(cost),
            retailStock: Number(retail),
            ordersStock: Number(orders),
          });
          await action.mutateAsync({
            kind: 'create',
            key: crypto.randomUUID(),
            body: { ...input, active: true },
          });
        }
        onSaved?.({ id: 'multiple', name });
        onDone();
        return;
      }

      const input = productInput.parse({
        sku: product?.sku ?? 'AUTO',
        category,
        subcategory,
        color,
        name,
        size,
        priceCents: parseMoney(price),
        costCents: parseMoney(cost),
        retailStock: Number(retail),
        ordersStock: Number(orders),
      });

      action.mutate(
        {
          kind: product ? 'update' : 'create',
          ...(product ? { id: product.id } : {}),
          key: stockKey.current,
          body: product
            ? {
                ...input,
                currentRetailStock: product.retailStock,
                currentOrdersStock: product.ordersStock,
                active: data.get('active') === 'on',
              }
            : { ...input, active: true },
        },
        {
          onSuccess: (result) => {
            const id = product?.id ?? (result && 'id' in result ? result.id : undefined);
            if (id) onSaved?.({ id, name: input.name });
            onDone();
          },
        },
      );
    } catch (err) {
      setError(errorMessage(err));
    }
  }

  return (
    <Modal
      title={product ? 'Editar producto' : 'Nuevo producto'}
      onClose={onDone}
      busy={action.isPending}
      fitted
      className="product-editor-modal"
    >
      <form className="product-editor-form" onSubmit={submit}>
        <fieldset disabled={action.isPending}>
          <div className="product-editor-body">
            <div className="product-editor-sections">
              <section className="product-editor-section" aria-labelledby="product-identification">
                <header>
                  <span className="editor-section-icon">
                    <Package size={21} />
                  </span>
                  <div>
                    <small>01 · IDENTIFICACIÓN</small>
                    <h2 id="product-identification">Información del artículo</h2>
                  </div>
                </header>

                {/* Categoría y Subcategoría en selectores limpios arriba del producto */}
                <div className="editor-category-grid">
                  <div className="field">
                    <label htmlFor="product-category">Categoría del producto</label>
                    <select
                      id="product-category"
                      name="category"
                      value={category}
                      className={category ? 'has-value' : ''}
                      onChange={(e) => handleCategoryChange(e.target.value)}
                    >
                      <option value="">Selecciona una categoría…</option>
                      {productCategoryGroups.map((group) => (
                        <option key={group.id} value={group.category}>
                          {group.category}
                        </option>
                      ))}
                      <option value="General">General / Otra</option>
                    </select>
                  </div>

                  <div className="field">
                    <label htmlFor="product-subcategory">Subcategoría / Marca</label>
                    <select
                      id="product-subcategory"
                      name="subcategory"
                      value={subcategory}
                      className={subcategory ? 'has-value' : ''}
                      disabled={!category && activeSubcategories.length === 0}
                      onChange={(e) => setSubcategory(e.target.value)}
                    >
                      <option value="">
                        {category
                          ? 'Todas las subcategorías / Sin subcategoría'
                          : 'Selecciona primero una categoría'}
                      </option>
                      {activeSubcategories.map((sub) => (
                        <option key={sub} value={sub}>
                          {sub}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                {/* Nombre del producto */}
                <div className="field" style={{ marginTop: 14, marginBottom: 14 }}>
                  <label htmlFor="product-name">
                    Nombre del producto <span aria-hidden="true">*</span>
                  </label>
                  <input
                    id="product-name"
                    name="name"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder={
                      isShoe
                        ? 'Ej. Botines de seguridad punta de acero / Botas de jebe'
                        : 'Ej. Abrigo y/o Capotín PVC / Cortaviento en tela drill'
                    }
                    minLength={2}
                    maxLength={120}
                    required
                    autoComplete="off"
                  />
                </div>

                {/* Selector de Colores (selección de varios colores) */}
                <div className="editor-colors-section">
                  <div className="field">
                    <div className="field-label-row">
                      <label htmlFor="product-color">
                        <Palette size={15} style={{ verticalAlign: 'middle', marginRight: 4 }} />
                        Color(es) disponibles
                      </label>
                      {selectedColors.length > 0 && (
                        <button
                          type="button"
                          className="text-button clean-btn"
                          onClick={() => setColor('')}
                          title="Limpiar colores"
                        >
                          <X size={13} /> Limpiar
                        </button>
                      )}
                    </div>
                    <input
                      id="product-color"
                      name="color"
                      value={color}
                      onChange={(e) => setColor(e.target.value)}
                      placeholder="Selecciona varios con los botones o escribe (ej. Amarillo, Azul, Naranja, Plomo)"
                      maxLength={80}
                      autoComplete="off"
                    />
                    <div
                      className="color-chips-picker"
                      role="group"
                      aria-label="Seleccionar colores disponibles"
                    >
                      {productColors.map((colName) => {
                        const isSelected = selectedColors.includes(colName);
                        const dotColor = COLOR_DOTS[colName] ?? '#999';
                        return (
                          <button
                            key={colName}
                            type="button"
                            className={`color-chip ${isSelected ? 'is-selected' : ''}`}
                            aria-pressed={isSelected}
                            onClick={() => toggleColor(colName)}
                          >
                            <span
                              className="color-dot"
                              style={{
                                backgroundColor: dotColor,
                                border: colName === 'Blanco' ? '1px solid #ccc' : 'none',
                              }}
                            />
                            <span>{colName}</span>
                            {isSelected && <Check size={12} className="color-chip-check" />}
                          </button>
                        );
                      })}
                    </div>
                    {!product && selectedColors.length > 1 && (
                      <label className="editor-variants-checkbox">
                        <input
                          type="checkbox"
                          checked={createColorVariants}
                          onChange={(e) => setCreateColorVariants(e.target.checked)}
                        />
                        <span>
                          Crear un producto independiente por cada color seleccionado (
                          {selectedColors.length} artículos: {selectedColors.join(', ')})
                        </span>
                      </label>
                    )}
                  </div>
                </div>

                {/* Selector de Talla escribible con opciones adaptadas automáticamente a la categoría */}
                <div className="editor-size-section">
                  <div className="field">
                    <div className="field-label-row">
                      <label htmlFor="product-size">
                        Talla
                        <span className="auto-detect-tag">
                          {isShoe ? '👞 Calzado (35 al 46)' : '👕 Talla normal (S a XXXL)'}
                        </span>
                      </label>
                      {size && (
                        <button
                          type="button"
                          className="text-button clean-btn"
                          onClick={() => {
                            setSize('');
                            setSizeDropdownOpen(false);
                          }}
                          title="Limpiar talla"
                        >
                          <X size={13} /> Limpiar
                        </button>
                      )}
                    </div>

                    <div className="combobox-wrapper" ref={sizeWrapperRef}>
                      <input
                        id="product-size"
                        name="size"
                        list="product-size-datalist"
                        value={size}
                        onChange={(e) => setSize(e.target.value)}
                        placeholder={
                          isShoe
                            ? 'Escribe o selecciona número (ej. 38, 39, 40, 42…)'
                            : 'Escribe o selecciona talla (ej. S, M, L, XL…)'
                        }
                        className={size ? 'has-value' : ''}
                        autoComplete="off"
                        maxLength={60}
                      />
                      <button
                        type="button"
                        className="combobox-trigger-btn"
                        aria-label="Abrir opciones de talla"
                        aria-expanded={sizeDropdownOpen}
                        onClick={() => setSizeDropdownOpen((prev) => !prev)}
                        title="Ver sugerencias de talla"
                        tabIndex={-1}
                      >
                        <ChevronDown size={17} />
                      </button>

                      {/* Datalist nativo para autocompletado instantáneo al escribir con el teclado */}
                      <datalist id="product-size-datalist">
                        {isShoe
                          ? bootSizes.map((s) => <option key={s} value={s}>{`Talla ${s}`}</option>)
                          : productSizes.map((s) => (
                              <option key={s} value={s}>{`Talla ${s}`}</option>
                            ))}
                      </datalist>

                      {/* Menú flotante desplegable por si se prefiere hacer clic rápido */}
                      {sizeDropdownOpen && (
                        <ul
                          className="combobox-dropdown-menu"
                          role="listbox"
                          aria-label="Opciones de talla"
                        >
                          <li className="dropdown-menu-header">
                            {isShoe
                              ? '👞 Tallas de Calzado (35 al 46)'
                              : '👕 Tallas normales (S a XXXL)'}
                          </li>
                          {(isShoe ? bootSizes : productSizes).map((itemSize) => {
                            const isSelected = size.trim() === itemSize;
                            return (
                              <li key={itemSize} role="option" aria-selected={isSelected}>
                                <button
                                  type="button"
                                  className={`combobox-option-btn ${isSelected ? 'is-selected' : ''}`}
                                  onClick={() => {
                                    setSize(itemSize);
                                    setSizeDropdownOpen(false);
                                  }}
                                >
                                  <span>{isShoe ? `Talla ${itemSize}` : `Talla ${itemSize}`}</span>
                                  {isSelected && <Check size={14} />}
                                </button>
                              </li>
                            );
                          })}
                        </ul>
                      )}
                    </div>
                  </div>
                </div>

                <p className="editor-field-hint">
                  Puedes escribir directamente en el campo de talla para mayor rapidez o desplegar
                  la lista de opciones (detectada automáticamente como{' '}
                  {isShoe ? 'calzado' : 'talla normal'}).
                </p>
              </section>

              <section className="product-editor-section" aria-labelledby="product-pricing">
                <header>
                  <span className="editor-section-icon">
                    <BadgeDollarSign size={21} />
                  </span>
                  <div>
                    <small>02 · PRECIOS</small>
                    <h2 id="product-pricing">Venta y costo unitario</h2>
                  </div>
                  <span className="badge">PEN · Soles</span>
                </header>
                <div className="form-grid">
                  <div className="field">
                    <label htmlFor="price">Precio de venta (S/) *</label>
                    <input
                      id="price"
                      name="price"
                      type="number"
                      inputMode="decimal"
                      min="0"
                      max="1000000"
                      step="0.01"
                      placeholder="0.00"
                      value={price}
                      onChange={(e) => setPrice(e.target.value)}
                      required
                    />
                  </div>
                  <div className="field">
                    <label htmlFor="cost">Costo de compra (S/) *</label>
                    <input
                      id="cost"
                      name="cost"
                      type="number"
                      inputMode="decimal"
                      min="0"
                      max="1000000"
                      step="0.01"
                      placeholder="0.00"
                      value={cost}
                      onChange={(e) => setCost(e.target.value)}
                      required
                    />
                  </div>
                </div>
                <p className="editor-field-hint">
                  Importes por unidad. En cada venta podrás ajustar estos valores.
                </p>
                {loss !== null && loss > 0 && (
                  <p className="editor-loss" role="status">
                    El precio está por debajo del costo: pérdida de {money(loss)} por unidad.
                  </p>
                )}
                {product && (
                  <p className="editor-field-hint">
                    Los cambios no modifican los importes de ventas anteriores.
                  </p>
                )}
              </section>

              <section className="product-editor-section" aria-labelledby="product-inventory">
                <header>
                  <span className="editor-section-icon">
                    <Boxes size={21} />
                  </span>
                  <div>
                    <small>03 · INVENTARIO</small>
                    <h2 id="product-inventory">
                      {product ? 'Existencias por canal' : 'Distribución de stock inicial'}
                    </h2>
                  </div>
                </header>
                <div className="editor-stock-grid">
                  <div className="editor-stock-channel">
                    <span>
                      <ShoppingCart size={18} />
                      Menudeo
                    </span>
                    <p>Unidades para venta de mostrador</p>
                    <div className="field">
                      <label htmlFor="retailStock">
                        {product ? 'Cantidad · Menudeo' : 'Cantidad inicial · Menudeo'}
                      </label>
                      <input
                        id="retailStock"
                        name="retailStock"
                        type="number"
                        inputMode="numeric"
                        min="0"
                        max="1000000"
                        step="1"
                        value={retail}
                        onChange={(e) => {
                          setRetail(e.target.value);
                          stockKey.current = crypto.randomUUID();
                        }}
                        required
                      />
                    </div>
                  </div>
                  <div className="editor-stock-channel">
                    <span>
                      <Truck size={18} />
                      Pedidos
                    </span>
                    <p>Unidades destinadas a despachos</p>
                    <div className="field">
                      <label htmlFor="ordersStock">
                        {product ? 'Cantidad · Pedidos' : 'Cantidad inicial · Pedidos'}
                      </label>
                      <input
                        id="ordersStock"
                        name="ordersStock"
                        type="number"
                        inputMode="numeric"
                        min="0"
                        max="1000000"
                        step="1"
                        value={orders}
                        onChange={(e) => {
                          setOrders(e.target.value);
                          stockKey.current = crypto.randomUUID();
                        }}
                        required
                      />
                    </div>
                  </div>
                </div>
                <p className="editor-field-hint">
                  {product
                    ? 'Edita directamente la cantidad actual disponible en cada canal.'
                    : 'Puedes comenzar con cero. Cada canal mantiene existencias independientes.'}
                </p>
                {product && (
                  <label className="editor-availability">
                    <input name="active" type="checkbox" defaultChecked={product.active} />
                    <span>Disponible para nuevas ventas</span>
                  </label>
                )}
              </section>
            </div>
          </div>
          <footer className="product-editor-actions">
            <div>
              <Feedback error={error || action.error} />
              <span className="editor-field-hint">Los campos con * son obligatorios.</span>
            </div>
            <div>
              <button className="button secondary" type="button" onClick={onDone}>
                Cancelar
              </button>
              <button className="button primary" type="submit">
                <Save size={17} />
                {action.isPending ? 'Guardando…' : product ? 'Guardar cambios' : 'Crear producto'}
              </button>
            </div>
          </footer>
        </fieldset>
      </form>
    </Modal>
  );
}
