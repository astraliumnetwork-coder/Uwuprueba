import { cleanup, render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import type { ReactNode } from 'react';
import { afterEach, describe, expect, it, vi } from 'vitest';
import { ProductEditor } from './ProductEditor';
const { mutate } = vi.hoisted(() => ({ mutate: vi.fn() }));
vi.mock('../hooks/useProducts', () => ({
  useProductAction: () => ({ mutate, isPending: false, error: null }),
}));
vi.mock('@/shared/ui/Modal', () => ({
  Modal: ({ children }: { children: ReactNode }) => <div>{children}</div>,
}));
afterEach(() => {
  cleanup();
  vi.clearAllMocks();
});
describe('Product editor', () => {
  it('creates a product with separate channel stock and selectable/editable size S (Small)', async () => {
    const user = userEvent.setup();
    render(<ProductEditor onDone={vi.fn()} />);
    await user.type(screen.getByLabelText(/Nombre del producto/), 'Guantes');
    await user.click(screen.getByRole('button', { name: 'Abrir opciones de talla' }));
    await user.click(screen.getByRole('button', { name: 'Talla S' }));
    expect(screen.getByLabelText(/Talla/)).toHaveValue('S');
    await user.type(screen.getByLabelText(/Precio de venta/), '15.50');
    await user.type(screen.getByLabelText(/Costo de compra/), '10');
    const stock = screen.getByLabelText('Cantidad inicial · Menudeo');
    await user.clear(stock);
    await user.type(stock, '3');
    await user.click(screen.getByRole('button', { name: 'Crear producto' }));
    expect(mutate.mock.calls[0]?.[0]).toMatchObject({
      kind: 'create',
      body: {
        sku: 'AUTO',
        name: 'Guantes',
        size: 'S',
        priceCents: 1550,
        costCents: 1000,
        retailStock: 3,
        ordersStock: 0,
        active: true,
      },
    });
  });
  it('allows selecting category, subcategory, numeric shoe sizes, and multiple colors directly', async () => {
    const user = userEvent.setup();
    render(<ProductEditor onDone={vi.fn()} />);

    // Seleccionar categoría Calzado industrial y subcategoría Botines dieléctricos
    await user.selectOptions(screen.getByLabelText(/Categoría del producto/), 'Calzado industrial');
    expect(screen.getByLabelText(/Categoría del producto/)).toHaveValue('Calzado industrial');
    await user.selectOptions(screen.getByLabelText(/Subcategoría/), 'Botines dieléctricos');
    expect(screen.getByLabelText(/Subcategoría/)).toHaveValue('Botines dieléctricos');

    // Seleccionar colores múltiples
    await user.click(screen.getByRole('button', { name: 'Negro' }));
    await user.click(screen.getByRole('button', { name: 'Amarillo' }));
    expect(screen.getByLabelText(/Color/)).toHaveValue('Negro, Amarillo');

    // Seleccionar tallas numéricas de calzado (activadas automáticamente al elegir Calzado industrial)
    await user.type(screen.getByLabelText(/Talla/), '41, 42');
    expect(screen.getByLabelText(/Talla/)).toHaveValue('41, 42');

    await user.type(screen.getByLabelText(/Nombre del producto/), 'Botín dieléctrico');
    await user.type(screen.getByLabelText(/Precio de venta/), '120');
    await user.type(screen.getByLabelText(/Costo de compra/), '80');
    await user.click(screen.getByRole('button', { name: 'Crear producto' }));

    expect(mutate.mock.calls[0]?.[0]).toMatchObject({
      kind: 'create',
      body: {
        category: 'Calzado industrial',
        subcategory: 'Botines dieléctricos',
        name: 'Botín dieléctrico',
        color: 'Negro, Amarillo',
        size: '41, 42',
        priceCents: 12000,
        costCents: 8000,
      },
    });
  });
  it('allows typing a custom size while keeping preset options inside the dropdown selector', async () => {
    const user = userEvent.setup();
    render(<ProductEditor onDone={vi.fn()} />);
    await user.type(screen.getByLabelText(/Nombre del producto/), 'Botas');
    await user.type(screen.getByLabelText(/Talla/), '42 Especial');
    await user.type(screen.getByLabelText(/Precio de venta/), '50');
    await user.type(screen.getByLabelText(/Costo de compra/), '30');
    await user.click(screen.getByRole('button', { name: 'Crear producto' }));
    expect(mutate.mock.calls[0]?.[0]).toMatchObject({
      kind: 'create',
      body: {
        name: 'Botas',
        size: '42 Especial',
      },
    });
  });
  it('allows zero price and shows a loss warning', async () => {
    const user = userEvent.setup();
    render(<ProductEditor onDone={vi.fn()} />);
    await user.type(screen.getByLabelText(/Nombre del producto/), 'Muestra');
    await user.type(screen.getByLabelText(/Precio de venta/), '0');
    await user.type(screen.getByLabelText(/Costo de compra/), '2');
    expect(screen.getByRole('status')).toHaveTextContent('pérdida');
    await user.click(screen.getByRole('button', { name: 'Crear producto' }));
    expect(mutate.mock.calls[0]?.[0].body.priceCents).toBe(0);
  });
  it('updates product fields including direct stock quantities and normalizes size siglas', async () => {
    const user = userEvent.setup();
    render(
      <ProductEditor
        onDone={vi.fn()}
        product={{
          id: '00000000-0000-4000-8000-000000000001',
          sku: 'PRD-000001',
          name: 'Lentes',
          size: 'M',
          priceCents: 1000,
          costCents: 500,
          retailStock: 9,
          ordersStock: 4,
          active: false,
        }}
      />,
    );
    expect(screen.getByLabelText(/Talla/)).toHaveValue('M');
    const retailInput = screen.getByLabelText('Cantidad · Menudeo');
    await user.clear(retailInput);
    await user.type(retailInput, '12');
    await user.click(screen.getByRole('button', { name: 'Guardar cambios' }));
    expect(mutate.mock.calls[0]?.[0]).toMatchObject({
      kind: 'update',
      id: '00000000-0000-4000-8000-000000000001',
      body: {
        sku: 'PRD-000001',
        size: 'M',
        retailStock: 12,
        ordersStock: 4,
        currentRetailStock: 9,
        currentOrdersStock: 4,
        active: false,
      },
    });
  });
});
