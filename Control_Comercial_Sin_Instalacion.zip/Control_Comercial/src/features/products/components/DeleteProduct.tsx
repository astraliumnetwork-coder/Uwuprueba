import type { Product } from '@saas/domain';
import { Trash2 } from 'lucide-react';
import { useDeleteProduct } from '../hooks/useProducts';
import { Modal } from '@/shared/ui/Modal';
import { Feedback } from '@/shared/ui/Feedback';
export function DeleteProduct({
  product,
  onClose,
  onDeleted,
}: {
  product: Product;
  onClose: () => void;
  onDeleted: () => void;
}) {
  const action = useDeleteProduct();
  const hasStock = product.retailStock > 0 || product.ordersStock > 0;
  return (
    <Modal title="Borrar producto" onClose={onClose} busy={action.isPending}>
      <div className="delete-product-body">
        <p>
          ¿Borrar <strong>{product.name}</strong> ({product.sku}) del catálogo?
        </p>
        <p className="muted">
          {hasStock
            ? `Se retirará del catálogo junto con su stock actual (${product.retailStock.toLocaleString('es-PE')} en menudeo · ${product.ordersStock.toLocaleString('es-PE')} en pedidos). Las ventas y movimientos anteriores se conservarán.`
            : 'Las ventas y movimientos anteriores se conservarán.'}
        </p>
        <Feedback error={action.error} />
        <div className="row-actions">
          <button className="button secondary" disabled={action.isPending} onClick={onClose}>
            Cancelar
          </button>
          <button
            className="button danger"
            disabled={action.isPending}
            onClick={() => action.mutate(product.id, { onSuccess: onDeleted })}
          >
            <Trash2 size={17} />
            {action.isPending ? 'Borrando…' : 'Borrar producto'}
          </button>
        </div>
      </div>
    </Modal>
  );
}
