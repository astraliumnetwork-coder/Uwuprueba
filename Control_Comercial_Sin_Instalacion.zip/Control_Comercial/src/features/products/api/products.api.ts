import { z } from 'zod';
import {
  CATEGORY_KEYWORDS,
  formatProductNameWithSize,
  normalizeProductCategory,
  normalizeProductSubcategory,
  pageSchema,
  productCategorySchema,
  productColorSchema,
  productInput,
  productSchema,
  productSizeSchema,
  productSubcategorySchema,
  splitProductMetadata,
} from '@saas/domain';
import { supabase } from '@/shared/supabase/client';
import { throwSupabaseError } from '@/shared/supabase/errors';

export type ProductFilters = {
  category?: string;
  subcategory?: string;
  stock?: 'all' | 'retail-positive' | 'retail-zero' | 'orders-positive' | 'orders-zero';
  sort?:
    | 'name-asc'
    | 'name-desc'
    | 'sku-asc'
    | 'sku-desc'
    | 'retail-asc'
    | 'retail-desc'
    | 'orders-asc'
    | 'orders-desc';
};

type ProductCatalogRow = {
  id: string;
  sku: string;
  category?: string | null;
  subcategory?: string | null;
  color?: string | null;
  name: string;
  size?: string | null;
  active: boolean;
  price_cents: number | string;
  cost_cents: number | string;
  retail_stock: number | string;
  orders_stock: number | string;
};

const SUBCATEGORY_KEYWORDS: Record<string, readonly string[]> = {
  'Botines de seguridad': ['botin', 'botín', 'zapato', 'borseg'],
  'Botines dieléctricos': ['dielectric', 'dieléctric'],
  'Botas de PVC': ['bota bla', 'bota pvc', 'botas pvc'],
  'Botas de jebe': ['bota jebe', 'botas jebe'],
  'Calzado para dama': ['dama'],
  'Corta vientos': ['corta viento', 'cortaviento'],
  Abrigos: ['capa', 'capotin', 'abrigo', 'mamelu', 'traje'],
  'Barra Retráctil': ['bara', 'barra'],
  'Tapones Auditivos': ['tapon', 'tapón'],
  'Orejeras 3M': ['orejera'],
  'Filtros 3M': ['filtro', 'prefiltro', '2097', '7093', '5n11'],
  Mascarillas: ['masca', 'kn95', 'kn ', 'cj kn'],
  Respiradores: ['respi'],
  'Protección Facial': ['careta', 'mica', 'facial', 'facil'],
};

// Selecciona '*' para incluir 'category', 'subcategory', 'color' y 'size' si la migración está aplicada y mantener compatibilidad previa.
const productSelect = '*';

function deriveSecondUuid(uuid: string): string {
  const clean = uuid.trim();
  if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(clean)) {
    return crypto.randomUUID();
  }
  const last = clean.slice(-1).toLowerCase();
  const nextLast = last === '0' ? '1' : '0';
  return clean.slice(0, -1) + nextLast;
}

const directStockSchema = z.object({
  retailStock: z.number().int().min(0).max(1_000_000),
  ordersStock: z.number().int().min(0).max(1_000_000),
  currentRetailStock: z.number().int().min(0).max(1_000_000),
  currentOrdersStock: z.number().int().min(0).max(1_000_000),
  reason: z.string().trim().max(200).optional().default('Actualización directa de existencias'),
});

const legacyDeltaStockSchema = z.object({
  channel: z.enum(['retail', 'orders']),
  delta: z
    .number()
    .int()
    .min(-1_000_000)
    .max(1_000_000)
    .refine((n) => n !== 0),
  reason: z.string().trim().min(3).max(200),
});

export const productsApi = {
  async list(
    search: string,
    page: number,
    signal: AbortSignal,
    activeOnly = false,
    pageSize = 25,
    filters: ProductFilters = {},
  ) {
    const [sortField, direction] = (filters.sort ?? 'name-asc').split('-');
    const columns: Record<string, string> = {
      name: 'name',
      sku: 'code_number',
      retail: 'retail_stock',
      orders: 'orders_stock',
    };
    let query = supabase
      .from('product_catalog')
      .select(productSelect, {
        count: 'exact',
      })
      .order(columns[sortField ?? 'name'] ?? 'name', {
        ascending: direction === 'asc',
        nullsFirst: false,
      })
      .order('id')
      .range((page - 1) * pageSize, page * pageSize - 1)
      .abortSignal(signal);
    if (activeOnly) query = query.eq('active', true);
    const stock = filters.stock ?? 'all';
    if (stock !== 'all') {
      const column = stock.startsWith('retail') ? 'retail_stock' : 'orders_stock';
      query = stock.endsWith('zero') ? query.eq(column, 0) : query.gt(column, 0);
    }
    const rawCategory = (filters.category ?? '').trim();
    if (rawCategory && rawCategory !== 'all') {
      const cleanCategory = normalizeProductCategory(rawCategory);
      const escapedCategory = cleanCategory.replace(/[\\%_,().]/g, '\\$&');
      const matched = CATEGORY_KEYWORDS.find(
        (entry) => entry.category.toLowerCase() === cleanCategory.toLowerCase(),
      );
      if (matched) {
        const kwClauses = matched.keywords
          .map((kw) => `name.ilike.%${kw.replace(/[\\%_,().]/g, '\\$&')}%`)
          .join(',');
        query = query.or(
          `name.ilike.%· Cat: ${escapedCategory}%,and(name.not.ilike.%· Cat:%,or(${kwClauses}))`,
        );
      } else {
        query = query.ilike('name', `%· Cat: ${escapedCategory}%`);
      }
    }
    const rawSubcategory = (filters.subcategory ?? '').trim();
    if (rawSubcategory && rawSubcategory !== 'all') {
      const cleanSub = normalizeProductSubcategory(rawSubcategory, rawCategory);
      const escapedSub = cleanSub.replace(/[\\%_,().]/g, '\\$&');
      const extraKws = SUBCATEGORY_KEYWORDS[cleanSub] ?? [];
      if (extraKws.length > 0) {
        const kwClauses = extraKws
          .map((kw) => `name.ilike.%${kw.replace(/[\\%_,().]/g, '\\$&')}%`)
          .join(',');
        query = query.or(
          `name.ilike.%· Sub: ${escapedSub}%,name.ilike.%${escapedSub}%,and(name.not.ilike.%· Sub:%,or(${kwClauses}))`,
        );
      } else {
        query = query.or(`name.ilike.%· Sub: ${escapedSub}%,name.ilike.%${escapedSub}%`);
      }
    }
    const normalizedSearch = search
      .trim()
      .slice(0, 100)
      .replace(/[\\%_,().]/g, '\\$&');
    if (normalizedSearch)
      query = query.or(`name.ilike.%${normalizedSearch}%,sku.ilike.%${normalizedSearch}%`);
    const { data, error, count } = await query;
    if (error) {
      if (['PGRST205', '42P01'].includes(error.code))
        throw new Error(
          'Falta actualizar el inventario. Ejecuta supabase/inventory_management.sql en el SQL Editor de Supabase.',
        );
      throwSupabaseError(error);
    }
    const rows = (data ?? []) as unknown as ProductCatalogRow[];
    return pageSchema(productSchema).parse({
      items: rows.map((row) => {
        const parsed = splitProductMetadata(
          String(row.name ?? ''),
          row.size,
          row.category,
          row.color,
          true,
          row.subcategory,
        );
        return {
          id: row.id,
          sku: row.sku,
          category: parsed.category,
          subcategory: parsed.subcategory,
          color: parsed.color,
          name: parsed.name,
          size: parsed.size,
          active: row.active,
          priceCents: Number(row.price_cents),
          costCents: Number(row.cost_cents),
          retailStock: Number(row.retail_stock),
          ordersStock: Number(row.orders_stock),
        };
      }),
      total: count ?? 0,
      page,
      pageSize,
    });
  },
  async remove(id: string) {
    const { error } = await supabase.rpc('delete_product', { p_product_id: id });
    if (error) {
      if (error.code === 'PGRST202')
        throw new Error('Ejecuta supabase/inventory_management.sql para habilitar el borrado.');
      if (
        String(error.message ?? '')
          .toLowerCase()
          .includes('con stock')
      ) {
        const pendingCheck = await supabase
          .from('sale_items')
          .select('sale_id, sales!inner(status)')
          .eq('product_id', id)
          .eq('sales.status', 'pending')
          .limit(1);
        if (pendingCheck.data && pendingCheck.data.length > 0) {
          throw new Error(
            'No se puede borrar un producto con pedidos pendientes. Entrega o anula esos pedidos primero.',
          );
        }
        const inv = await supabase
          .from('inventory')
          .select('channel, quantity')
          .eq('product_id', id);
        if (inv.error) throwSupabaseError(inv.error);
        for (const row of inv.data ?? []) {
          const qty = Number(row.quantity);
          if (qty !== 0 && (row.channel === 'retail' || row.channel === 'orders')) {
            const { error: adjError } = await supabase.rpc('adjust_stock', {
              p_product_id: id,
              p_channel: row.channel,
              p_delta: -qty,
              p_reason: 'Baja por eliminación de producto',
              p_key: crypto.randomUUID(),
            });
            if (adjError) throwSupabaseError(adjError);
          }
        }
        const retry = await supabase.rpc('delete_product', { p_product_id: id });
        if (retry.error) throwSupabaseError(retry.error);
        return;
      }
      throwSupabaseError(error);
    }
  },
  async create(input: unknown) {
    const value = productInput.parse(input);
    const persistedName = formatProductNameWithSize(
      value.name,
      value.size,
      value.category,
      value.color,
      value.subcategory,
    );
    const { data, error } = await supabase.rpc('create_product', {
      p_input: {
        ...value,
        name: persistedName,
        baseName: value.name,
        category: value.category,
        subcategory: value.subcategory,
        color: value.color,
        size: value.size,
      },
    });
    if (error) throwSupabaseError(error);
    return z.object({ id: z.string().uuid() }).parse({ id: data });
  },
  async update(id: string, input: unknown, key?: string) {
    const value = z
      .object({
        sku: z.string().trim().min(1).max(40),
        category: productCategorySchema,
        subcategory: productSubcategorySchema,
        color: productColorSchema,
        name: z.string().trim().min(2).max(120),
        size: productSizeSchema,
        priceCents: z.number().int().min(0).max(100_000_000),
        costCents: z.number().int().min(0).max(100_000_000),
        active: z.boolean(),
        retailStock: z.number().int().min(0).max(1_000_000).optional(),
        ordersStock: z.number().int().min(0).max(1_000_000).optional(),
        currentRetailStock: z.number().int().min(0).max(1_000_000).optional(),
        currentOrdersStock: z.number().int().min(0).max(1_000_000).optional(),
      })
      .parse(input);
    const persistedName = formatProductNameWithSize(
      value.name,
      value.size,
      value.category,
      value.color,
      value.subcategory,
    );
    const { error } = await supabase.rpc('update_product', {
      p_product_id: id,
      p_input: {
        sku: value.sku,
        name: persistedName,
        baseName: value.name,
        category: value.category,
        subcategory: value.subcategory,
        color: value.color,
        size: value.size,
        priceCents: value.priceCents,
        costCents: value.costCents,
        active: value.active,
      },
    });
    if (error) throwSupabaseError(error);
    if (
      value.retailStock !== undefined &&
      value.currentRetailStock !== undefined &&
      value.ordersStock !== undefined &&
      value.currentOrdersStock !== undefined
    ) {
      await this.stock(
        id,
        {
          retailStock: value.retailStock,
          ordersStock: value.ordersStock,
          currentRetailStock: value.currentRetailStock,
          currentOrdersStock: value.currentOrdersStock,
          reason: 'Actualización directa desde edición de producto',
        },
        key ?? crypto.randomUUID(),
      );
    }
  },
  async stock(id: string, input: unknown, key: string) {
    if (
      typeof input === 'object' &&
      input !== null &&
      ('retailStock' in input || 'ordersStock' in input)
    ) {
      const direct = directStockSchema.parse(input);
      const rawReason = direct.reason.trim();
      const reason = rawReason.length >= 3 ? rawReason : 'Actualización directa de existencias';
      const retailDelta = direct.retailStock - direct.currentRetailStock;
      const ordersDelta = direct.ordersStock - direct.currentOrdersStock;
      let lastQuantity = direct.retailStock;
      if (retailDelta !== 0) {
        const { data, error } = await supabase.rpc('adjust_stock', {
          p_product_id: id,
          p_channel: 'retail',
          p_delta: retailDelta,
          p_reason: reason,
          p_key: key,
        });
        if (error) throwSupabaseError(error);
        lastQuantity = Number(data);
      }
      if (ordersDelta !== 0) {
        const { data, error } = await supabase.rpc('adjust_stock', {
          p_product_id: id,
          p_channel: 'orders',
          p_delta: ordersDelta,
          p_reason: reason,
          p_key: retailDelta !== 0 ? deriveSecondUuid(key) : key,
        });
        if (error) throwSupabaseError(error);
        lastQuantity = Number(data);
      }
      return { quantity: lastQuantity };
    }
    const value = legacyDeltaStockSchema.parse(input);
    const { data, error } = await supabase.rpc('adjust_stock', {
      p_product_id: id,
      p_channel: value.channel,
      p_delta: value.delta,
      p_reason: value.reason,
      p_key: key,
    });
    if (error) throwSupabaseError(error);
    return { quantity: Number(data) };
  },
};
