import { settingsSchema } from '@saas/domain';
import type { WorkspaceSettings } from '@saas/domain';
import { supabase } from '@/shared/supabase/client';
import { throwSupabaseError } from '@/shared/supabase/errors';
export const settingsRepository = {
  async get() {
    const profile = await supabase.auth.getUser();
    if (profile.error) throw profile.error;
    if (!profile.data.user) throw new Error('Inicia sesión para continuar.');
    const membership = await supabase
      .from('users')
      .select('tenant_id')
      .eq('id', profile.data.user.id)
      .single();
    if (membership.error) throwSupabaseError(membership.error);
    const tenant = await supabase
      .from('tenants')
      .select('name')
      .eq('id', membership.data.tenant_id)
      .single();
    if (tenant.error) throwSupabaseError(tenant.error);
    return settingsSchema.parse({
      organizationName: tenant.data.name,
      currency: 'PEN',
      timezone: 'America/Lima',
    });
  },
  async save(input: WorkspaceSettings) {
    const value = settingsSchema.parse(input);
    const { data, error } = await supabase.rpc('save_tenant_settings', {
      p_name: value.organizationName,
    });
    if (error) throwSupabaseError(error);
    return settingsSchema.parse({ ...value, organizationName: data });
  },
};
