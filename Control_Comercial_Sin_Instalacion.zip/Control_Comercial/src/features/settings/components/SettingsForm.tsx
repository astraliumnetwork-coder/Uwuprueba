import { useState } from 'react';
import type { FormEvent } from 'react';
import { Save } from 'lucide-react';
import { settingsSchema } from '../model/settings';
import type { WorkspaceSettings } from '../model/settings';
import { useSaveSettings } from '../hooks/useSettings';
export function SettingsForm({ initialValues }: { initialValues: WorkspaceSettings }) {
  const [values, setValues] = useState(initialValues);
  const [errors, setErrors] = useState<Record<string, string[] | undefined>>({});
  const save = useSaveSettings();
  function change(field: keyof WorkspaceSettings, value: string) {
    setValues((previous) => ({ ...previous, [field]: value }));
    setErrors((previous) => ({ ...previous, [field]: undefined }));
    save.reset();
  }
  function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const parsed = settingsSchema.safeParse(values);
    if (!parsed.success) {
      setErrors(parsed.error.flatten().fieldErrors);
      return;
    }
    setErrors({});
    save.mutate(parsed.data);
  }
  return (
    <form className="settings-form" onSubmit={submit} noValidate>
      <div className="form-intro">
        <h2>Datos del espacio</h2>
        <p className="muted">Estos valores pertenecen a tu empresa.</p>
      </div>
      <fieldset disabled={save.isPending}>
        <div className="field">
          <label htmlFor="organizationName">Nombre de la empresa</label>
          <input
            id="organizationName"
            autoComplete="organization"
            maxLength={80}
            value={values.organizationName}
            onChange={(event) => change('organizationName', event.target.value)}
            aria-invalid={!!errors.organizationName}
            aria-describedby={errors.organizationName ? 'organizationName-error' : undefined}
          />
          {errors.organizationName && (
            <p className="field-error" id="organizationName-error">
              {errors.organizationName[0]}
            </p>
          )}
        </div>
        <div className="form-grid">
          <div className="field">
            <label htmlFor="currency">Moneda</label>
            <select
              id="currency"
              value={values.currency}
              onChange={(event) => change('currency', event.target.value)}
            >
              <option value="PEN">Soles (PEN)</option>
            </select>
          </div>
          <div className="field">
            <label htmlFor="timezone">Zona horaria</label>
            <select
              id="timezone"
              value={values.timezone}
              onChange={(event) => change('timezone', event.target.value)}
            >
              <option value="America/Lima">Perú · Lima</option>
            </select>
          </div>
        </div>
      </fieldset>
      <div className="form-actions">
        <button className="button primary" disabled={save.isPending} type="submit">
          <Save size={17} />
          {save.isPending ? 'Guardando…' : 'Guardar cambios'}
        </button>
        <span role="status">{save.isSuccess ? 'Cambios guardados.' : ''}</span>
      </div>
      {save.isError && (
        <p className="field-error" role="alert">
          No se pudo guardar. Comprueba la conexión con el servidor.
        </p>
      )}
    </form>
  );
}
