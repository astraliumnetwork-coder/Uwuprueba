import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { useTenantId } from '@/features/auth/hooks/useSession';
import { settingsRepository } from '../api/settings.repository';
export function useSettings() {
  const tenant = useTenantId();
  return useQuery({
    queryKey: [tenant, 'settings'],
    queryFn: settingsRepository.get,
    retry: false,
  });
}
export function useSaveSettings() {
  const client = useQueryClient();
  const tenant = useTenantId();
  return useMutation({
    mutationFn: settingsRepository.save,
    onSuccess: async (data) => {
      client.setQueryData([tenant, 'settings'], data);
      await client.invalidateQueries({ queryKey: ['session'] });
    },
  });
}
