export { settingsSchema } from '@saas/domain';
export type { WorkspaceSettings } from '@saas/domain';
export const defaultSettings = {
  organizationName: 'Mi empresa',
  currency: 'PEN' as const,
  timezone: 'America/Lima' as const,
};
