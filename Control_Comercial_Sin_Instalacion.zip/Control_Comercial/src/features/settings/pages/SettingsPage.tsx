import { useSettings } from '../hooks/useSettings';
import { SettingsForm } from '../components/SettingsForm';
import { PageState } from '@/shared/ui/PageState';
export function Component() {
  const settings = useSettings();
  if (settings.isPending) return <PageState title="Cargando configuración…" />;
  if (settings.isError)
    return (
      <PageState
        title="No se pudo leer la configuración"
        action={
          <button className="button primary" onClick={() => void settings.refetch()}>
            Reintentar
          </button>
        }
      />
    );
  return (
    <div className="page">
      <div className="page-heading">
        <div>
          <p className="eyebrow">EMPRESA</p>
          <h1>Configuración</h1>
          <p className="muted">Moneda y zona horaria contable: soles peruanos y Lima.</p>
        </div>
        <span className="badge">Datos de tu empresa</span>
      </div>
      <section className="panel settings-panel">
        <SettingsForm initialValues={settings.data} />
      </section>
    </div>
  );
}
