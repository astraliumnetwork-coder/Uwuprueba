import { describe, expect, it } from 'vitest';
import { quoteTotals, quoteInputSchema } from './model';
import { parseQuoteText } from './lib/import';
const line = {
  id: '00000000-0000-4000-8000-000000000001',
  productId: null,
  name: 'Guantes',
  quantity: 3,
  priceCents: 1000,
  costCents: 600,
};
describe('Cotizaciones', () => {
  it('keeps original tax-included rounding per unit and balances cents', () => {
    expect(quoteTotals([line], true)).toEqual({
      totalCents: 3000,
      subtotalCents: 2541,
      taxCents: 459,
    });
    expect(quoteTotals([line], false)).toEqual({
      totalCents: 3000,
      subtotalCents: 3000,
      taxCents: 0,
    });
  });
  it('rejects fractional quantities and invalid RUC and permits free samples', () => {
    const input = {
      brand: 'reypro',
      customer: 'Cliente',
      ruc: '',
      address: '',
      date: '2026-10-29',
      taxIncluded: true,
      items: [{ ...line, priceCents: 0 }],
    };
    expect(quoteInputSchema.safeParse(input).success).toBe(true);
    expect(quoteInputSchema.safeParse({ ...input, ruc: '123' }).success).toBe(false);
    expect(
      quoteInputSchema.safeParse({ ...input, items: [{ ...line, quantity: 1.5 }] }).success,
    ).toBe(false);
  });
  it('imports tab-separated rows with explicit price and internal cost', () => {
    const items = parseQuoteText('Producto\tCantidad\tPrecio\tCosto\nGuantes\t2\t10.50\t6.20');
    expect(items).toHaveLength(1);
    expect(items[0]).toMatchObject({
      name: 'Guantes',
      quantity: 2,
      priceCents: 1050,
      costCents: 620,
      productId: null,
    });
  });
});
