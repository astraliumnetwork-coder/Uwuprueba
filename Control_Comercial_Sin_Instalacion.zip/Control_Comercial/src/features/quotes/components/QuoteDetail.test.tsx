import { cleanup, render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import type { ReactNode } from 'react';
import { afterEach, beforeEach, expect, it, vi } from 'vitest';
import type { Quote } from '../model';
import { QuoteDetail } from './QuoteDetail';
const exports = vi.hoisted(() => ({
  createQuotePdf: vi.fn(),
  exportQuote: vi.fn(),
  downloadQuotePdf: vi.fn(),
}));
vi.mock('../lib/export', () => exports);
vi.mock('./PdfPreview', () => ({
  PdfPreview: ({ url, title }: { url: string; title: string }) => (
    <iframe src={url} title={title} />
  ),
}));
vi.mock('@/shared/ui/Modal', () => ({
  Modal: ({ children }: { children: ReactNode }) => <div>{children}</div>,
}));
const quote: Quote = {
  id: '00000000-0000-4000-8000-000000000001',
  number: 15,
  version: 1,
  brand: 'reypro',
  customer: 'Cliente de prueba',
  ruc: '20123456789',
  address: 'Av. Lima 150',
  date: '2026-10-30',
  taxIncluded: false,
  items: [
    {
      id: '00000000-0000-4000-8000-000000000002',
      productId: null,
      name: 'Guantes industriales',
      quantity: 2,
      priceCents: 7500,
      costCents: 5000,
    },
  ],
  subtotalCents: 15000,
  taxCents: 0,
  totalCents: 15000,
  saleId: null,
  createdAt: '2026-10-30T15:00:00Z',
};
beforeEach(() => {
  vi.clearAllMocks();
  exports.createQuotePdf.mockResolvedValue(new Blob(['pdf'], { type: 'application/pdf' }));
  exports.exportQuote.mockResolvedValue(undefined);
  vi.stubGlobal('URL', {
    createObjectURL: vi.fn(() => 'blob:document-test'),
    revokeObjectURL: vi.fn(),
  });
});
afterEach(() => {
  cleanup();
  vi.unstubAllGlobals();
});
it('shows client and sale prices and duplicates only when requested inside the detail', async () => {
  const user = userEvent.setup();
  const duplicate = vi.fn();
  render(<QuoteDetail quote={quote} onClose={vi.fn()} onDuplicate={duplicate} />);
  expect(screen.getByText('20123456789')).toBeVisible();
  expect(screen.getByText('Av. Lima 150')).toBeVisible();
  expect(screen.getByText('Guantes industriales')).toBeVisible();
  expect(screen.getByText('S/ 75.00')).toBeVisible();
  expect(screen.queryByText('S/ 50.00')).not.toBeInTheDocument();
  expect(screen.queryByTitle(/Vista previa/)).not.toBeInTheDocument();
  await user.click(screen.getByRole('button', { name: 'Duplicar' }));
  expect(duplicate).toHaveBeenCalledTimes(1);
});
it('asks for a template, previews the selected PDF and revokes it when switching or closing', async () => {
  const user = userEvent.setup();
  const view = render(<QuoteDetail quote={quote} onClose={vi.fn()} onDuplicate={vi.fn()} />);
  await user.click(screen.getByRole('button', { name: 'Exportar PDF' }));
  expect(screen.getByRole('radio', { name: 'REYPRO' })).toBeChecked();
  await user.click(screen.getByRole('radio', { name: 'JUFLEX' }));
  expect(exports.createQuotePdf).not.toHaveBeenCalled();
  await user.click(screen.getByRole('button', { name: 'Mostrar PDF' }));
  await waitFor(() =>
    expect(screen.getByTitle('Vista previa PDF JUFLEX')).toHaveAttribute(
      'src',
      'blob:document-test',
    ),
  );
  expect(exports.createQuotePdf).toHaveBeenCalledWith(quote, {
    brand: 'juflex',
    title: 'COTIZACION',
    number: '00015',
  });
  await user.click(screen.getByRole('button', { name: 'Descargar PDF' }));
  await waitFor(() =>
    expect(exports.downloadQuotePdf).toHaveBeenCalledWith(quote, 'blob:document-test', {
      brand: 'juflex',
      title: 'COTIZACION',
      number: '00015',
    }),
  );
  await user.click(screen.getByRole('radio', { name: 'BETMIN' }));
  expect(screen.queryByTitle('Vista previa PDF JUFLEX')).not.toBeInTheDocument();
  expect(URL.revokeObjectURL).toHaveBeenCalledWith('blob:document-test');
  await user.click(screen.getByRole('button', { name: 'Mostrar PDF' }));
  await screen.findByTitle('Vista previa PDF BETMIN');
  view.unmount();
  expect(URL.revokeObjectURL).toHaveBeenCalledTimes(2);
});
it('exports Excel with the selected template and displays document generation errors', async () => {
  const user = userEvent.setup();
  render(<QuoteDetail quote={quote} onClose={vi.fn()} onDuplicate={vi.fn()} />);
  await user.click(screen.getByRole('button', { name: 'Exportar PDF' }));
  await user.click(screen.getByRole('radio', { name: 'BETMIN' }));
  await user.click(screen.getByRole('button', { name: 'Excel' }));
  await waitFor(() =>
    expect(exports.exportQuote).toHaveBeenCalledWith(quote, 'excel', {
      brand: 'premium',
      title: 'COTIZACION',
      number: '00015',
    }),
  );
  exports.createQuotePdf.mockRejectedValueOnce(new Error('No se pudo generar el documento'));
  await waitFor(() => expect(screen.getByRole('button', { name: 'Mostrar PDF' })).toBeEnabled());
  await user.click(screen.getByRole('button', { name: 'Mostrar PDF' }));
  expect(await screen.findByText('No se pudo generar el documento')).toBeVisible();
});
it('exports an order using its real code and shows delivery and payment metadata', async () => {
  const user = userEvent.setup();
  const sale = {
    id: '00000000-0000-4000-8000-000000000005',
    orderCode: 'PED-000032',
    channel: 'orders' as const,
    payment: 'yape' as const,
    customer: quote.customer,
    scheduledFor: '2026-11-02',
    createdAt: '2026-10-30T15:00:00Z',
    recognizedAt: null,
    status: 'pending' as const,
    salesCents: 15000,
    costTotalCents: 10000,
    grossCents: 5000,
  };
  render(
    <QuoteDetail
      quote={{ ...quote, saleId: sale.id }}
      sale={sale}
      onClose={vi.fn()}
      onDuplicate={vi.fn()}
    />,
  );
  expect(screen.getByText('Yape')).toBeVisible();
  expect(screen.getByText('02/11/2026')).toBeVisible();
  expect(screen.getByText('Pendiente')).toBeVisible();
  await user.click(screen.getByRole('button', { name: 'Exportar PDF' }));
  await user.click(screen.getByRole('button', { name: 'Mostrar PDF' }));
  await screen.findByTitle('Vista previa PDF REYPRO');
  expect(exports.createQuotePdf).toHaveBeenCalledWith(
    expect.objectContaining({ saleId: sale.id }),
    { brand: 'reypro', title: 'PEDIDO', number: 'PED-000032' },
  );
});
