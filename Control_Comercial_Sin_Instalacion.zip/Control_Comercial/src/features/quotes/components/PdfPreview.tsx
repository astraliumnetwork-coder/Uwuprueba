import { useEffect, useRef, useState } from 'react';
import type { PDFDocumentProxy, RenderTask } from 'pdfjs-dist';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { Feedback } from '@/shared/ui/Feedback';
import { errorMessage } from '@/shared/lib/error-message';

export function PdfPreview({ url, title }: { url: string; title: string }) {
  const container = useRef<HTMLDivElement>(null);
  const canvas = useRef<HTMLCanvasElement>(null);
  const [document, setDocument] = useState<PDFDocumentProxy | null>(null);
  const [page, setPage] = useState(1);
  const [width, setWidth] = useState(300);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  useEffect(() => {
    const node = container.current;
    if (!node) return;
    const measure = () => setWidth(Math.max(200, node.clientWidth - 24));
    measure();
    const observer = new ResizeObserver(measure);
    observer.observe(node);
    return () => observer.disconnect();
  }, []);
  useEffect(() => {
    let stopped = false;
    let destroy: (() => void) | undefined;
    void (async () => {
      try {
        const pdfjs = await import('pdfjs-dist');
        if (stopped) return;
        pdfjs.GlobalWorkerOptions.workerSrc = new URL(
          'pdfjs-dist/build/pdf.worker.min.mjs',
          import.meta.url,
        ).toString();
        const task = pdfjs.getDocument({
          url,
          useSystemFonts: false,
          standardFontDataUrl: new URL(
            '/quote-assets/pdf-fonts/',
            window.location.origin,
          ).toString(),
        });
        destroy = () => {
          void task.destroy().catch(() => {});
        };
        const pdf = await task.promise;
        if (!stopped) setDocument(pdf);
      } catch (err) {
        if (!stopped) {
          setError(errorMessage(err));
          setLoading(false);
        }
      }
    })();
    return () => {
      stopped = true;
      destroy?.();
    };
  }, [url]);
  useEffect(() => {
    if (!document || !canvas.current) return;
    let stopped = false;
    let render: RenderTask | undefined;
    setLoading(true);
    void (async () => {
      try {
        const pdfPage = await document.getPage(page);
        if (stopped || !canvas.current) return;
        const base = pdfPage.getViewport({ scale: 1 });
        const viewport = pdfPage.getViewport({ scale: width / base.width });
        const ratio = Math.min(window.devicePixelRatio || 1, 2);
        canvas.current.width = Math.round(viewport.width * ratio);
        canvas.current.height = Math.round(viewport.height * ratio);
        canvas.current.style.width = `${viewport.width}px`;
        canvas.current.style.height = `${viewport.height}px`;
        render = pdfPage.render({
          canvas: canvas.current,
          viewport,
          transform: [ratio, 0, 0, ratio, 0, 0],
        });
        await render.promise;
        if (!stopped) setLoading(false);
      } catch (err) {
        if (!stopped) {
          setError(errorMessage(err));
          setLoading(false);
        }
      }
    })();
    return () => {
      stopped = true;
      render?.cancel();
    };
  }, [document, page, width]);
  return (
    <div className="document-pdf-preview" ref={container} aria-busy={loading}>
      <Feedback error={error} />
      {loading && !error && <p role="status">Preparando vista previa…</p>}
      <canvas ref={canvas} role="img" title={title} aria-label={`${title}, página ${page}`} />
      {document && document.numPages > 1 && (
        <nav className="document-preview-pages" aria-label="Páginas del PDF">
          <button
            className="button secondary"
            disabled={page <= 1 || loading}
            onClick={() => setPage(page - 1)}
          >
            <ChevronLeft size={18} />
            Anterior
          </button>
          <span>
            {page} / {document.numPages}
          </span>
          <button
            className="button secondary"
            disabled={page >= document.numPages || loading}
            onClick={() => setPage(page + 1)}
          >
            Siguiente
            <ChevronRight size={18} />
          </button>
        </nav>
      )}
    </div>
  );
}
