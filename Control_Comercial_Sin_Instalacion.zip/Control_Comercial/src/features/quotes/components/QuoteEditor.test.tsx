import { render, screen, waitFor, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import type { ReactNode } from 'react';
import { beforeEach, expect, it, vi } from 'vitest';
import { QuoteEditor } from './QuoteEditor';
import { quoteTotals } from '../model';
import type { QuoteInput } from '../model';
const mocks = vi.hoisted(() => ({ save: vi.fn(), convert: vi.fn() }));
vi.mock('@/features/auth/hooks/useSession', () => ({ useTenantId: () => 'tenant-test' }));
vi.mock('@/shared/ui/Modal', () => ({
  Modal: ({ children }: { children: ReactNode }) => <div>{children}</div>,
}));
vi.mock('../hooks', () => ({
  useQuoteActions: () => ({
    save: { mutateAsync: mocks.save, isPending: false, error: null },
    convert: { mutateAsync: mocks.convert, isPending: false, error: null },
  }),
}));
vi.mock('@/features/products/hooks/useProducts', () => ({
  useProducts: () => ({
    data: {
      items: [
        {
          id: '00000000-0000-4000-8000-000000000010',
          name: 'Guantes',
          sku: 'PRD-000001',
          priceCents: 1180,
          costCents: 600,
          ordersStock: 5,
          retailStock: 0,
          active: true,
        },
      ],
      total: 1,
      page: 1,
      pageSize: 6,
    },
    isFetching: false,
    error: null,
  }),
}));
beforeEach(() => {
  vi.clearAllMocks();
  mocks.save.mockImplementation(async ({ input }: { input: QuoteInput }) => ({
    ...input,
    id: '00000000-0000-4000-8000-000000000020',
    number: 1,
    version: 1,
    saleId: null,
    createdAt: '2026-10-29T12:00:00Z',
    ...quoteTotals(input.items, input.taxIncluded),
  }));
  mocks.convert.mockResolvedValue('00000000-0000-4000-8000-000000000030');
});
it('saves a catalogue proposal and generates a pending order only after confirmation', async () => {
  const user = userEvent.setup();
  const onOrder = vi.fn();
  render(<QuoteEditor initial={null} copy={false} onClose={vi.fn()} onOrder={onOrder} />);
  await user.type(screen.getByLabelText('Cliente / Razón social'), 'Cliente prueba');
  await user.type(screen.getByLabelText('Buscar en inventario'), 'Guantes');
  await user.click(screen.getByRole('button', { name: 'Agregar Guantes' }));
  await user.click(screen.getByRole('button', { name: 'Guardar cotización' }));
  await waitFor(() => expect(mocks.save).toHaveBeenCalledTimes(1));
  expect(mocks.save.mock.calls[0]?.[0].input.items[0]).toMatchObject({
    productId: '00000000-0000-4000-8000-000000000010',
    priceCents: 1180,
    costCents: 600,
  });
  expect(mocks.convert).not.toHaveBeenCalled();
  await user.click(screen.getByRole('button', { name: 'Generar pedido' }));
  await screen.findByRole('button', { name: 'Confirmar pedido' });
  expect(mocks.save).toHaveBeenCalledTimes(1);
  await user.click(screen.getByRole('button', { name: 'Confirmar pedido' }));
  await waitFor(() => expect(onOrder).toHaveBeenCalledWith('00000000-0000-4000-8000-000000000030'));
});
it('duplicates a proposal into a new company without updating the original identity', async () => {
  const user = userEvent.setup();
  const input: QuoteInput = {
    brand: 'reypro',
    customer: 'Cliente',
    ruc: '',
    address: 'Lima',
    date: '2026-10-29',
    taxIncluded: true,
    items: [
      {
        id: crypto.randomUUID(),
        productId: null,
        name: 'Artículo manual',
        quantity: 1,
        priceCents: 100,
        costCents: 50,
      },
    ],
  };
  render(
    <QuoteEditor
      initial={{
        ...input,
        id: crypto.randomUUID(),
        number: 3,
        version: 1,
        saleId: null,
        createdAt: '2026-10-29T12:00:00Z',
        ...quoteTotals(input.items, true),
      }}
      copy
      onClose={vi.fn()}
      onOrder={vi.fn()}
    />,
  );
  await user.selectOptions(screen.getByLabelText('Empresa'), 'premium');
  await user.click(screen.getByRole('button', { name: 'Guardar cotización' }));
  await waitFor(() => expect(mocks.save).toHaveBeenCalled());
  expect(mocks.save.mock.calls[0]?.[0]).toMatchObject({
    current: null,
    input: { brand: 'premium', customer: 'Cliente' },
  });
});

it('paginates detail without submitting or saving the form', async () => {
  const user = userEvent.setup();
  const items = Array.from({ length: 5 }, (_, i) => ({
    id: crypto.randomUUID(),
    productId: null,
    name: `Artículo ${i + 1}`,
    quantity: 1,
    priceCents: 100,
    costCents: 50,
  }));
  const input: QuoteInput = {
    brand: 'reypro',
    customer: 'Cliente',
    ruc: '',
    address: '',
    date: '2026-10-30',
    taxIncluded: true,
    items,
  };
  const { container } = render(
    <QuoteEditor
      initial={{
        ...input,
        id: crypto.randomUUID(),
        number: 1,
        version: 1,
        saleId: null,
        createdAt: '2026-10-30T12:00:00Z',
        ...quoteTotals(items, true),
      }}
      copy
      onClose={vi.fn()}
      onOrder={vi.fn()}
    />,
  );
  const pager = container.querySelector('.quote-detail-pagination') as HTMLElement;
  await user.click(within(pager).getByRole('button', { name: 'Siguiente' }));
  expect(screen.getByDisplayValue('Artículo 3')).toBeInTheDocument();
  expect(mocks.save).not.toHaveBeenCalled();
  expect(mocks.convert).not.toHaveBeenCalled();
});
