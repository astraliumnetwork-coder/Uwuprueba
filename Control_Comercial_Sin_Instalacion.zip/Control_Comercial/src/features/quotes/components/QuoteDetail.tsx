import { useEffect, useRef, useState } from 'react';
import { money, paymentLabels } from '@saas/domain';
import type { Sale } from '@saas/domain';
import {
  Copy,
  Download,
  Eye,
  FileSpreadsheet,
  FileText,
  Pencil,
  Truck,
  UserRound,
} from 'lucide-react';
import { Modal } from '@/shared/ui/Modal';
import { Feedback } from '@/shared/ui/Feedback';
import { errorMessage } from '@/shared/lib/error-message';
import { brands, quoteNumber } from '../model';
import type { Quote } from '../model';
import '../quotes.css';
import { PdfPreview } from './PdfPreview';

const statuses = { pending: 'Pendiente', posted: 'Entregado', cancelled: 'Anulado' };
export function QuoteDetail({
  quote,
  sale,
  onClose,
  onDuplicate,
  onEdit,
  onOrder,
}: {
  quote: Quote;
  sale?: Sale;
  onClose: () => void;
  onDuplicate: () => void;
  onEdit?: () => void;
  onOrder?: () => void;
}) {
  const exportPanel = useRef<HTMLElement>(null);
  const [template, setTemplate] = useState<Quote['brand']>(quote.brand);
  const [pdfPanel, setPdfPanel] = useState(false);
  const [preview, setPreview] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const mounted = useRef(true);
  useEffect(() => {
    mounted.current = true;
    return () => {
      mounted.current = false;
    };
  }, []);
  useEffect(
    () => () => {
      if (preview) URL.revokeObjectURL(preview);
    },
    [preview],
  );
  useEffect(() => {
    if (pdfPanel) exportPanel.current?.scrollIntoView?.({ block: 'start' });
  }, [pdfPanel]);
  const reference = sale ? (sale.orderCode ?? sale.id) : `#${quoteNumber(quote.number)}`;
  const options = {
    brand: template,
    title: sale ? ('PEDIDO' as const) : ('COTIZACION' as const),
    number: sale ? reference : quoteNumber(quote.number),
  };
  async function documentAction(format: 'pdf' | 'excel') {
    setBusy(true);
    setError('');
    try {
      const exports = await import('../lib/export');
      if (format === 'excel') await exports.exportQuote(quote, 'excel', options);
      else {
        const blob = await exports.createQuotePdf(quote, options);
        if (mounted.current) setPreview(URL.createObjectURL(blob));
      }
    } catch (err) {
      if (mounted.current) setError(errorMessage(err));
    } finally {
      if (mounted.current) setBusy(false);
    }
  }
  async function download() {
    if (!preview) return;
    try {
      const exports = await import('../lib/export');
      exports.downloadQuotePdf(quote, preview, options);
    } catch (err) {
      setError(errorMessage(err));
    }
  }
  return (
    <Modal
      title={`${sale ? 'Pedido' : 'Cotización'} ${reference}`}
      onClose={onClose}
      busy={busy}
      wide
      className="quote-detail-modal"
    >
      <div className="quote-detail-layout">
        <div className="document-detail-content">
          <section className="document-client">
            <div className="document-client-title">
              <UserRound size={23} aria-hidden="true" />
              <div>
                <span className="eyebrow">CLIENTE</span>
                <h3>{quote.customer || 'Venta de mostrador'}</h3>
              </div>
              <span className={`badge ${sale ? `status-${sale.status}` : ''}`}>
                {sale ? statuses[sale.status] : quote.saleId ? 'Pedido generado' : 'Cotización'}
              </span>
            </div>
            <dl className="document-metadata">
              <div>
                <dt>Empresa emisora</dt>
                <dd>{sale && quote.version === 0 ? 'Sin asignar' : brands[quote.brand]}</dd>
              </div>
              <div>
                <dt>Fecha</dt>
                <dd>{quote.date.split('-').reverse().join('/')}</dd>
              </div>
              <div>
                <dt>RUC del cliente</dt>
                <dd>{quote.ruc || 'No registrado'}</dd>
              </div>
              <div>
                <dt>Dirección</dt>
                <dd>{quote.address || 'No registrada'}</dd>
              </div>
              {sale && (
                <>
                  <div>
                    <dt>Pago</dt>
                    <dd>{paymentLabels[sale.payment]}</dd>
                  </div>
                  <div>
                    <dt>Entrega prevista</dt>
                    <dd>{sale.scheduledFor?.split('-').reverse().join('/') || 'Sin programar'}</dd>
                  </div>
                  <div>
                    <dt>Creado</dt>
                    <dd>
                      {new Intl.DateTimeFormat('es-PE', {
                        timeZone: 'America/Lima',
                        dateStyle: 'short',
                        timeStyle: 'short',
                      }).format(new Date(sale.createdAt))}
                    </dd>
                  </div>
                  <div>
                    <dt>Contabilizado</dt>
                    <dd>
                      {sale.recognizedAt
                        ? new Intl.DateTimeFormat('es-PE', {
                            timeZone: 'America/Lima',
                            dateStyle: 'short',
                            timeStyle: 'short',
                          }).format(new Date(sale.recognizedAt))
                        : 'Sin contabilizar'}
                    </dd>
                  </div>
                </>
              )}
            </dl>
          </section>
          <section className="document-items" aria-label="Productos del documento">
            <div className="document-items-heading">
              <h3>Detalle de productos</h3>
              <span>
                {quote.items.length} artículos ·{' '}
                {quote.items.reduce((sum, item) => sum + item.quantity, 0)} unidades
              </span>
            </div>
            <div className="document-item-labels" aria-hidden="true">
              <span>Producto</span>
              <span>Cantidad</span>
              <span>Venta unitaria</span>
              <span>Importe</span>
            </div>
            {quote.items.map((item, index) => (
              <article className="document-item" key={item.id}>
                <div>
                  <span className="document-item-index">{String(index + 1).padStart(2, '0')}</span>
                  <strong>{item.name}</strong>
                </div>
                <span>
                  <small>Cantidad</small>
                  {item.quantity}
                </span>
                <span>
                  <small>Venta unitaria</small>
                  {money(item.priceCents)}
                </span>
                <strong>
                  <small>Importe</small>
                  {money(item.quantity * item.priceCents)}
                </strong>
              </article>
            ))}
          </section>
          <div className="document-summary">
            <span>{quote.taxIncluded ? 'IGV incluido en los precios' : 'Sin desglose de IGV'}</span>
            <dl>
              <div>
                <dt>Subtotal</dt>
                <dd>{money(quote.subtotalCents)}</dd>
              </div>
              {quote.taxIncluded && (
                <div>
                  <dt>IGV</dt>
                  <dd>{money(quote.taxCents)}</dd>
                </div>
              )}
              <div className="document-grand-total">
                <dt>Total</dt>
                <dd>{money(quote.totalCents)}</dd>
              </div>
            </dl>
          </div>
          {sale && (
            <div className="document-internal">
              <span>Control interno · no se exporta</span>
              <span>
                Costo: <strong>{money(sale.costTotalCents)}</strong>
              </span>
              <span>
                Utilidad bruta: <strong>{money(sale.grossCents)}</strong>
              </span>
            </div>
          )}
        </div>
        {pdfPanel && (
          <section
            ref={exportPanel}
            className="document-preview-panel"
            aria-label="Exportar documento"
          >
            <div className="document-export-title">
              <FileText size={23} />
              <div>
                <h3>Elige la plantilla</h3>
                <p>La plantilla define la empresa emisora del archivo.</p>
              </div>
            </div>
            <div className="document-template-options">
              {Object.entries(brands).map(([key, label]) => (
                <label className={template === key ? 'selected' : ''} key={key}>
                  <input
                    type="radio"
                    name="document-template"
                    value={key}
                    checked={template === key}
                    disabled={busy}
                    onChange={() => {
                      setTemplate(key as Quote['brand']);
                      setPreview(null);
                      setError('');
                    }}
                  />
                  <span>{label}</span>
                </label>
              ))}
            </div>
            <div className="document-preview-actions">
              <button
                className="button primary"
                disabled={busy}
                onClick={() => void documentAction('pdf')}
              >
                <Eye size={18} />
                {busy ? 'Generando…' : 'Mostrar PDF'}
              </button>
              {preview && (
                <button className="button secondary" onClick={() => void download()}>
                  <Download size={18} />
                  Descargar PDF
                </button>
              )}
            </div>
            {preview ? (
              <>
                <PdfPreview
                  key={preview}
                  url={preview}
                  title={`Vista previa PDF ${brands[template]}`}
                />
                <a href={preview} target="_blank" rel="noreferrer">
                  Abrir PDF en otra pestaña
                </a>
              </>
            ) : (
              <div className="document-preview-empty">
                <FileText size={38} />
                <p>Selecciona una plantilla y pulsa Mostrar PDF.</p>
              </div>
            )}
          </section>
        )}
        <Feedback error={error} />
        <footer className="document-detail-footer">
          <div>
            <button className="button secondary" disabled={busy} onClick={onDuplicate}>
              <Copy size={18} />
              Duplicar
            </button>
            {onEdit && !quote.saleId && (
              <button className="button secondary" disabled={busy} onClick={onEdit}>
                <Pencil size={18} />
                Editar
              </button>
            )}
            {onOrder && (
              <button className="button secondary" disabled={busy} onClick={onOrder}>
                <Truck size={18} />
                Ver pedido
              </button>
            )}
          </div>
          <div>
            <button
              className="button secondary"
              disabled={busy}
              onClick={() => void documentAction('excel')}
            >
              <FileSpreadsheet size={18} />
              Excel
            </button>
            <button
              className="button primary"
              disabled={busy}
              aria-expanded={pdfPanel}
              onClick={() => setPdfPanel(!pdfPanel)}
            >
              <FileText size={18} />
              {pdfPanel ? 'Ocultar PDF' : 'Exportar PDF'}
            </button>
          </div>
        </footer>
      </div>
    </Modal>
  );
}
