import { useDeferredValue, useState } from 'react';
import { money } from '@saas/domain';
import { Search, X, FileText } from 'lucide-react';
import { Modal } from '@/shared/ui/Modal';
import { Pagination } from '@/shared/ui/Pagination';
import { Feedback } from '@/shared/ui/Feedback';
import { useQuotes, useQuoteActions } from '../hooks';
import { brands, quoteNumber } from '../model';
import type { Quote } from '../model';
import { QuoteEditor } from './QuoteEditor';
import { QuoteDetail } from './QuoteDetail';
import '../quotes.css';
export function QuoteWorkspace({ onOrder }: { onOrder: (id: string) => void }) {
  const [search, setSearch] = useState('');
  const [brand, setBrand] = useState('');
  const [page, setPage] = useState(1);
  const [editor, setEditor] = useState<{ quote: Quote | null; copy: boolean } | null>(null);
  const [detail, setDetail] = useState<Quote | null>(null);
  const [remove, setRemove] = useState<Quote | null>(null);
  const query = useQuotes(useDeferredValue(search), brand, page);
  const { archive } = useQuoteActions();
  return (
    <section className="panel quote-workspace">
      <div className="quote-history-toolbar">
        <div className="quote-history-search">
          <Search size={19} aria-hidden="true" />
          <input
            aria-label="Buscar cotizaciones por cliente"
            placeholder="Buscar por cliente…"
            value={search}
            onChange={(e) => {
              setSearch(e.target.value);
              setPage(1);
            }}
          />
          {search && (
            <button
              type="button"
              aria-label="Limpiar búsqueda"
              onClick={() => {
                setSearch('');
                setPage(1);
              }}
            >
              <X size={17} />
            </button>
          )}
        </div>
        <select
          aria-label="Filtrar por empresa emisora"
          value={brand}
          onChange={(e) => {
            setBrand(e.target.value);
            setPage(1);
          }}
        >
          <option value="">Todas las empresas</option>
          {Object.entries(brands).map(([k, v]) => (
            <option key={k} value={k}>
              {v}
            </option>
          ))}
        </select>
        {query.data && (
          <span className="quote-history-count">
            {query.data.total} {query.data.total === 1 ? 'cotización' : 'cotizaciones'}
          </span>
        )}
      </div>
      <Feedback error={query.error} />
      {query.isPending ? (
        <p>Cargando propuestas…</p>
      ) : (
        <div className="quote-history">
          {query.data?.items.map((q) => (
            <article key={q.id} className="quote-history-card">
              <div>
                <span className="badge">{brands[q.brand]}</span>
                <strong>
                  #{quoteNumber(q.number)} · {q.customer}
                </strong>
                <small>
                  {q.date.split('-').reverse().join('/')} · {q.items.length} artículos ·{' '}
                  {q.saleId ? 'Pedido generado' : 'Cotización'}
                </small>
              </div>
              <strong>{money(q.totalCents)}</strong>
              <div className="quote-tools">
                <button
                  className="button secondary"
                  onClick={() => (q.saleId ? onOrder(q.saleId) : setDetail(q))}
                >
                  <FileText size={16} aria-hidden="true" /> Detalles
                </button>
                {!q.saleId && (
                  <button
                    className="text-button danger"
                    onClick={() => {
                      archive.reset();
                      setRemove(q);
                    }}
                  >
                    Borrar
                  </button>
                )}
              </div>
            </article>
          ))}
          {query.data?.items.length === 0 && (
            <p className="empty-state">No hay cotizaciones con estos filtros.</p>
          )}
        </div>
      )}
      {query.data && <Pagination {...query.data} onChange={setPage} />}
      {detail && (
        <QuoteDetail
          quote={detail}
          onClose={() => setDetail(null)}
          onDuplicate={() => {
            setEditor({ quote: detail, copy: true });
            setDetail(null);
          }}
          onEdit={() => {
            setEditor({ quote: detail, copy: false });
            setDetail(null);
          }}
        />
      )}
      {editor && (
        <QuoteEditor
          initial={editor.quote}
          copy={editor.copy}
          onClose={() => setEditor(null)}
          onOrder={(id) => {
            setEditor(null);
            onOrder(id);
          }}
        />
      )}
      {remove && (
        <Modal title="Borrar cotización" onClose={() => setRemove(null)} busy={archive.isPending}>
          <p>
            ¿Retirar la cotización {brands[remove.brand]} #{quoteNumber(remove.number)} del
            historial?
          </p>
          <Feedback error={archive.error} />
          <div className="modal-actions">
            <button
              className="button secondary"
              disabled={archive.isPending}
              onClick={() => setRemove(null)}
            >
              Cancelar
            </button>
            <button
              className="button danger"
              disabled={archive.isPending}
              onClick={() =>
                archive.mutate(remove.id, {
                  onSuccess: () => {
                    setRemove(null);
                    if (query.data?.items.length === 1 && page > 1) setPage(page - 1);
                  },
                })
              }
            >
              Borrar
            </button>
          </div>
        </Modal>
      )}
    </section>
  );
}
