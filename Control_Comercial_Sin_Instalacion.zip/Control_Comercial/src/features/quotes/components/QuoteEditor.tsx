import { useDeferredValue, useEffect, useRef, useState } from 'react';
import {
  ArrowRight,
  CheckCircle2,
  ClipboardPaste,
  FileDown,
  FilePlus2,
  Plus,
  Search,
  ShoppingCart,
  Trash2,
  Truck,
  WalletCards,
  CalendarDays,
  UserRound,
  PackageSearch,
  Receipt,
  FileText,
} from 'lucide-react';
import { localDate, money, parseMoney, paymentLabels } from '@saas/domain';
import { useMediaQuery } from '@/shared/hooks/useMediaQuery';
import type { Product } from '@saas/domain';
import { errorMessage } from '@/shared/lib/error-message';
import { useProducts } from '@/features/products/hooks/useProducts';
import { useTenantId } from '@/features/auth/hooks/useSession';
import { Modal } from '@/shared/ui/Modal';
import { Feedback } from '@/shared/ui/Feedback';
import { useQuoteActions } from '../hooks';
import { brands, quoteInputSchema, quoteNumber, quoteTotals } from '../model';
import type { Quote, QuoteInput, QuoteItem } from '../model';
import { importQuoteFile, parseQuoteText } from '../lib/import';

const blank = (): QuoteInput => ({
  brand: 'reypro',
  customer: '',
  ruc: '',
  address: '',
  date: localDate(new Date()),
  taxIncluded: true,
  items: [],
});

const draftSchema = quoteInputSchema.extend({
  customer: quoteInputSchema.shape.customer.min(0),
  items: quoteInputSchema.shape.items.element
    .extend({
      name: quoteInputSchema.shape.items.element.shape.name.min(0),
      quantity: quoteInputSchema.shape.items.element.shape.quantity.min(0),
    })
    .array()
    .max(100),
});

function useRowCapacity(desktop: boolean) {
  const [element, setElement] = useState<HTMLDivElement | null>(null);
  const [capacity, setCapacity] = useState(4);
  useEffect(() => {
    if (!desktop || !element) return;
    const target = element;
    const update = () => {
      const height = target.getBoundingClientRect().height;
      if (height > 0) setCapacity(Math.max(1, Math.min(20, Math.floor((height + 8) / 84))));
    };
    update();
    const observer = typeof ResizeObserver === 'function' ? new ResizeObserver(update) : null;
    observer?.observe(target);
    window.addEventListener('resize', update);
    return () => {
      observer?.disconnect();
      window.removeEventListener('resize', update);
    };
  }, [desktop, element]);
  return [setElement, capacity] as const;
}

function QuotePagination({
  page,
  total,
  pageSize,
  onChange,
}: {
  page: number;
  total: number;
  pageSize: number;
  onChange: (page: number) => void;
}) {
  const pages = Math.max(1, Math.ceil(total / pageSize));
  return (
    <nav className="pagination" aria-label="Paginación de artículos">
      <span>
        {total} artículos · Página {page} de {pages}
      </span>
      <div>
        <button
          type="button"
          className="button secondary"
          disabled={page <= 1}
          onClick={() => onChange(page - 1)}
        >
          Anterior
        </button>
        <button
          type="button"
          className="button secondary"
          disabled={page >= pages}
          onClick={() => onChange(page + 1)}
        >
          Siguiente
        </button>
      </div>
    </nav>
  );
}

function Amount({
  value,
  onChange,
  label,
  icon,
}: {
  value: number;
  onChange: (cents: number) => void;
  label: string;
  icon?: React.ReactNode;
}) {
  const [text, setText] = useState((value / 100).toFixed(2));
  return (
    <div className="input-with-icon">
      {icon && <span className="input-icon">{icon}</span>}
      <input
        aria-label={label}
        type="number"
        inputMode="decimal"
        min="0"
        max="1000000"
        step="0.01"
        required
        placeholder="0.00"
        value={text}
        className={icon ? 'has-icon' : ''}
        onChange={(e) => {
          setText(e.target.value);
          try {
            const n = parseMoney(e.target.value);
            e.target.setCustomValidity('');
            onChange(n);
          } catch {
            e.target.setCustomValidity('Ingresa un importe válido con hasta dos decimales.');
          }
        }}
      />
    </div>
  );
}

export function QuoteEditor({
  initial,
  copy,
  onClose,
  onOrder,
}: {
  initial: Quote | null;
  copy: boolean;
  onClose: () => void;
  onOrder: (id: string) => void;
}) {
  const tenant = useTenantId();
  const storageKey = `quote-draft:${tenant}`;
  const [form, setForm] = useState<QuoteInput>(() => {
    if (initial)
      return { ...initial, items: initial.items.map((i) => ({ ...i, id: crypto.randomUUID() })) };
    try {
      const raw = localStorage.getItem(storageKey);
      if (raw) {
        const parsed = draftSchema.safeParse(JSON.parse(raw));
        if (parsed.success) return parsed.data;
      }
    } catch {
      /* Ignorado */
    }
    return blank();
  });
  const [current, setCurrent] = useState<Quote | null>(copy ? null : initial);
  const [search, setSearch] = useState('');
  const [page, setPage] = useState(1);
  const desktop = useMediaQuery('(min-width: 1000px) and (min-height: 540px)');
  const [inventoryRef, inventoryCapacity] = useRowCapacity(desktop);
  const [detailRef, detailCapacity] = useRowCapacity(desktop);
  const [detailPage, setDetailPage] = useState(1);
  const detailPageSize = desktop ? detailCapacity : 2;
  const visibleDetailPage = Math.min(
    detailPage,
    Math.max(1, Math.ceil(form.items.length / detailPageSize)),
  );
  const detailOffset = (visibleDetailPage - 1) * detailPageSize;
  const products = useProducts(
    useDeferredValue(search),
    page,
    true,
    desktop ? inventoryCapacity : 5,
    !!search.trim(),
  );
  const { save, convert } = useQuoteActions();
  const key = useRef(crypto.randomUUID());
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');
  const [working, setWorking] = useState(false);
  const [paste, setPaste] = useState<string | null>(null);
  const [confirm, setConfirm] = useState(false);
  const [payment, setPayment] = useState('cash');
  const [delivery, setDelivery] = useState('');
  const formRef = useRef<HTMLFormElement>(null);
  const lock = useRef(false);
  const busy = working || save.isPending || convert.isPending;
  const readonly = !!current?.saleId;
  const totals = quoteTotals(form.items, form.taxIncluded);

  useEffect(() => {
    if (current) return;
    try {
      localStorage.setItem(storageKey, JSON.stringify(form));
    } catch {
      /* Browser storage is optional. */
    }
  }, [form, current, storageKey]);

  function change(next: QuoteInput) {
    setForm(next);
    key.current = crypto.randomUUID();
    setNotice('');
  }

  function item(id: string, update: Partial<QuoteItem>) {
    change({ ...form, items: form.items.map((i) => (i.id === id ? { ...i, ...update } : i)) });
  }

  function add(product?: Product) {
    setDetailPage(Math.floor(form.items.length / detailPageSize) + 1);
    if (form.items.length >= 100) {
      setError('Máximo 100 artículos.');
      return;
    }
    const existing = product ? form.items.find((i) => i.productId === product.id) : undefined;
    if (existing) {
      item(existing.id, { quantity: existing.quantity + 1 });
      return;
    }
    change({
      ...form,
      items: [
        ...form.items,
        {
          id: crypto.randomUUID(),
          productId: product?.id ?? null,
          name: product
            ? [product.name, product.size && `Talla ${product.size}`, product.color]
                .filter(Boolean)
                .join(' | ')
                .slice(0, 120)
            : '',
          quantity: 1,
          priceCents: product?.priceCents ?? 0,
          costCents: product?.costCents ?? 0,
        },
      ],
    });
  }

  async function persist() {
    if (!formRef.current?.reportValidity()) throw new Error('Revisa los campos del formulario.');
    const input = quoteInputSchema.parse(form);
    if (current && JSON.stringify(input) === JSON.stringify(quoteInputSchema.parse(current)))
      return current;
    const saved = await save.mutateAsync({ input, current, key: key.current });
    setCurrent(saved);
    key.current = crypto.randomUUID();
    setNotice('Cotización guardada');
    try {
      localStorage.removeItem(storageKey);
    } catch {
      /* Browser storage is optional. */
    }
    return saved;
  }

  async function execute(task: () => Promise<void>) {
    if (lock.current) return;
    lock.current = true;
    setWorking(true);
    setError('');
    try {
      await task();
    } catch (e) {
      setError(errorMessage(e));
    } finally {
      lock.current = false;
      setWorking(false);
    }
  }

  function append(items: QuoteItem[]) {
    if (!items.length) throw new Error('No se detectaron artículos válidos al importar.');
    if (form.items.length + items.length > 100)
      throw new Error('Máximo 100 artículos por cotización.');
    change({ ...form, items: [...form.items, ...items] });
    setDetailPage(Math.floor(form.items.length / detailPageSize) + 1);
    setPaste(null);
  }

  return (
    <Modal
      title={`${copy ? 'Duplicar' : current ? `Cotización ${quoteNumber(current.number)}` : 'Nueva cotización'} | ${brands[form.brand]}`}
      onClose={onClose}
      busy={busy}
      wide
      className="quote-editor"
    >
      <form
        ref={formRef}
        className="quote-editor-form"
        onSubmit={(e) => {
          e.preventDefault();
          void execute(async () => {
            await persist();
          });
        }}
      >
        <fieldset disabled={busy || readonly} className="quote-workspace-fieldset">
          {/* Los datos permanecen visibles; las listas se paginan según la altura disponible. */}
          <section
            className="quote-client-panel compact-panel"
            aria-labelledby="quote-client-title"
          >
            <header className="quote-section-heading">
              <UserRound size={26} className="heading-icon text-blue" />
              <h3 id="quote-client-title">Datos del Cliente</h3>
            </header>
            <div className="quote-client-grid">
              <label className="field">
                Empresa
                <select
                  value={form.brand}
                  onChange={(e) => {
                    if (current) setCurrent(null);
                    change({ ...form, brand: e.target.value as QuoteInput['brand'] });
                  }}
                >
                  {Object.entries(brands).map(([k, v]) => (
                    <option value={k} key={k}>
                      {v}
                    </option>
                  ))}
                </select>
              </label>
              <label className="field">
                Cliente / Razón social
                <input
                  required
                  maxLength={120}
                  autoComplete="organization"
                  placeholder="Ej. Constructora San Martín S.A.C."
                  value={form.customer}
                  onChange={(e) => change({ ...form, customer: e.target.value })}
                />
              </label>
              <label className="field">
                RUC
                <input
                  inputMode="numeric"
                  pattern="[0-9]{11}"
                  maxLength={11}
                  placeholder="Ej. 20123456789"
                  value={form.ruc}
                  onChange={(e) => change({ ...form, ruc: e.target.value })}
                />
              </label>
              <label className="field quote-address">
                Dirección
                <input
                  maxLength={250}
                  autoComplete="street-address"
                  placeholder="Ej. Av. Industrial 450"
                  value={form.address}
                  onChange={(e) => change({ ...form, address: e.target.value })}
                />
              </label>
              <label className="field">
                Fecha
                <input
                  required
                  type="date"
                  value={form.date}
                  onChange={(e) => change({ ...form, date: e.target.value })}
                />
              </label>
            </div>
          </section>

          {/* Grilla Principal */}
          <div className="quote-body-grid">
            {/* Inventario */}
            <section className="quote-inventory compact-panel split-pane-section">
              <header className="quote-section-heading">
                <PackageSearch size={26} className="heading-icon text-violet" />
                <h3>Inventario</h3>
              </header>
              <div className="field search-field-wrapper">
                <Search size={20} className="input-icon-left" />
                <input
                  className="search-input"
                  aria-label="Buscar en inventario"
                  placeholder="Ej. guantes, botines o PRD-000123"
                  autoComplete="off"
                  value={search}
                  onChange={(e) => {
                    setSearch(e.target.value);
                    setPage(1);
                  }}
                />
              </div>
              <Feedback error={products.error} />

              <div className="quote-inventory-scroll" ref={inventoryRef}>
                {!search.trim() ? (
                  <div className="quote-search-empty">
                    <div className="empty-icon-wrapper">
                      <Search size={30} />
                    </div>
                    <p>Escribe para buscar o importa artículos</p>
                  </div>
                ) : products.isFetching ? (
                  <div className="quote-search-empty">
                    <p className="quote-search-loading">Consultando...</p>
                  </div>
                ) : (
                  <div className="quote-results">
                    {products.data?.items.map((p) => (
                      <button
                        type="button"
                        className="quote-product"
                        aria-label={`Agregar ${p.name}`}
                        title={p.name}
                        key={p.id}
                        onClick={() => add(p)}
                      >
                        <div className="quote-result-top">
                          <strong>{p.name}</strong>
                          <span className="add-icon-btn">
                            <Plus size={20} />
                          </span>
                        </div>
                        <span className="quote-result-meta">
                          {p.sku} {p.size && `| ${p.size}`}
                        </span>
                        <div className="quote-result-bottom">
                          <b>{money(p.priceCents)}</b>
                          <span
                            className={`quote-stock-tag ${p.ordersStock ? 'has-stock' : 'no-stock'}`}
                          >
                            {p.ordersStock ? `${p.ordersStock} ud.` : '0 ud.'}
                          </span>
                        </div>
                      </button>
                    ))}
                    {products.data?.items.length === 0 && (
                      <p className="quote-search-empty text-sm">No se encontraron resultados.</p>
                    )}
                  </div>
                )}
              </div>
              <div className="quote-inventory-pagination">
                {!!search.trim() && products.data && (
                  <QuotePagination {...products.data} onChange={setPage} />
                )}
              </div>

              <div className="quote-add-alternatives">
                <div className="quote-tools">
                  <button type="button" className="button secondary tool-btn" onClick={() => add()}>
                    <FilePlus2 size={20} /> Manual
                  </button>
                  <button
                    type="button"
                    className="button secondary tool-btn"
                    onClick={() => setPaste('')}
                  >
                    <ClipboardPaste size={20} /> Pegar
                  </button>
                  <label className="button secondary tool-btn quote-import-button">
                    <FileDown size={20} /> Importar
                    <input
                      className="sr-only"
                      type="file"
                      accept=".pdf,.xlsx"
                      onChange={(e) => {
                        const file = e.target.files?.[0];
                        if (file) void execute(async () => append(await importQuoteFile(file)));
                        e.target.value = '';
                      }}
                    />
                  </label>
                </div>
              </div>
            </section>

            {/* Detalle del Pedido */}
            <section className="quote-lines compact-panel split-pane-section">
              <header className="quote-section-heading quote-heading-flex">
                <div className="heading-left">
                  <ShoppingCart size={26} className="heading-icon text-teal" />
                  <h3>
                    Detalle del pedido <span className="count-badge">{form.items.length}</span>
                  </h3>
                </div>
                <label className="quote-tax-toggle">
                  <input
                    type="checkbox"
                    checked={form.taxIncluded}
                    onChange={(e) => change({ ...form, taxIncluded: e.target.checked })}
                  />
                  <span>IGV incluido</span>
                </label>
              </header>

              <div className="quote-lines-scrollable" ref={detailRef}>
                {!form.items.length && (
                  <div className="quote-detail-empty">
                    <div className="empty-icon-wrapper">
                      <Receipt size={38} />
                    </div>
                    <h4>Propuesta vacía</h4>
                    <p>Agrega productos desde el buscador de inventario para armar el detalle.</p>
                  </div>
                )}
                {form.items.slice(detailOffset, detailOffset + detailPageSize).map((i, index) => (
                  <div className="quote-line" key={i.id}>
                    <div className="quote-line-header">
                      <span className="quote-item-number">{detailOffset + index + 1}</span>
                      <button
                        type="button"
                        className="quote-remove"
                        title="Quitar artículo"
                        aria-label={`Quitar artículo ${detailOffset + index + 1}`}
                        onClick={() =>
                          change({ ...form, items: form.items.filter((x) => x.id !== i.id) })
                        }
                      >
                        <Trash2 size={20} />
                      </button>
                    </div>
                    <div className="quote-line-grid">
                      <label className="field quote-line-name">
                        Artículo
                        <div className="input-with-icon">
                          <span className="input-icon">
                            <FileText size={20} />
                          </span>
                          <input
                            required
                            minLength={2}
                            maxLength={120}
                            className="has-icon"
                            placeholder="Descripción del artículo..."
                            value={i.name}
                            onChange={(e) => item(i.id, { name: e.target.value })}
                          />
                        </div>
                      </label>
                      <label className="field quote-line-qty">
                        Cantidad
                        <input
                          type="number"
                          min="1"
                          max="100000"
                          step="1"
                          required
                          value={i.quantity || ''}
                          onChange={(e) => item(i.id, { quantity: Number(e.target.value) })}
                        />
                      </label>
                      <label className="field">
                        Venta (S/)
                        <Amount
                          value={i.priceCents}
                          label={`Precio de venta del artículo ${detailOffset + index + 1}`}
                          onChange={(priceCents) => item(i.id, { priceCents })}
                        />
                      </label>
                      <div className="quote-line-total">
                        <small>Total Venta</small>
                        <strong>{money(i.quantity * i.priceCents)}</strong>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
              <div className="quote-detail-pagination">
                <QuotePagination
                  page={visibleDetailPage}
                  total={form.items.length}
                  pageSize={detailPageSize}
                  onChange={setDetailPage}
                />
              </div>
            </section>
          </div>
        </fieldset>

        {/* Footer Condensado */}
        <div className="quote-editor-footer">
          <div className="quote-summary-compact">
            <span className="quote-summary-meta">
              {form.items.length} artículos |{' '}
              {form.taxIncluded ? 'Precios con IGV incluido' : 'Sin desglose de IGV'}
            </span>
            <div className="quote-totals-compact">
              <span>
                Subtotal: <strong>{money(totals.subtotalCents)}</strong>
              </span>
              <span>
                IGV (18%): <strong>{money(totals.taxCents)}</strong>
              </span>
              <span className="total-highlight">
                Total Propuesta: <strong>{money(totals.totalCents)}</strong>
              </span>
            </div>
          </div>
          <Feedback error={error || save.error || convert.error} />
          {notice && (
            <p className="quote-success" role="status">
              <CheckCircle2 size={20} /> {notice}
            </p>
          )}

          <div className="quote-footer-actions">
            <button type="button" className="button secondary" disabled={busy} onClick={onClose}>
              Cerrar
            </button>
            <div className="quote-main-actions">
              {!readonly ? (
                <>
                  <button type="submit" className="button secondary" disabled={busy}>
                    Guardar cotización
                  </button>
                  <button
                    type="button"
                    className="button primary"
                    disabled={busy || !form.items.length}
                    onClick={() =>
                      void execute(async () => {
                        await persist();
                        setConfirm(true);
                      })
                    }
                  >
                    Generar pedido <ArrowRight size={20} />
                  </button>
                </>
              ) : (
                <button
                  type="button"
                  className="button primary"
                  onClick={() => onOrder(current!.saleId!)}
                >
                  <Truck size={20} /> Ver pedido
                </button>
              )}
            </div>
          </div>
        </div>
      </form>

      {/* Helper Modals (Pagar y Confirmar Pedido) */}
      {paste !== null && (
        <Modal
          title="Pegar artículos"
          onClose={() => setPaste(null)}
          className="quote-helper-modal"
        >
          <textarea
            aria-label="Artículos a importar"
            rows={6}
            className="modern-textarea"
            value={paste}
            onChange={(e) => setPaste(e.target.value)}
            placeholder={'Producto\tCantidad\tPrecio\nGuantes anticorte\t10\t25.50'}
          />
          <Feedback error={error} />
          <div className="modal-actions">
            <button
              className="button primary"
              onClick={() => {
                try {
                  append(parseQuoteText(paste));
                } catch (e) {
                  setError(errorMessage(e));
                }
              }}
            >
              Agregar al detalle
            </button>
          </div>
        </Modal>
      )}

      {confirm && current && (
        <Modal
          title="Confirmar pedido"
          onClose={() => setConfirm(false)}
          busy={busy}
          className="quote-helper-modal"
        >
          <div className="field">
            <label htmlFor="quote-payment">
              <WalletCards size={20} className="inline-icon" /> Método de pago
            </label>
            <select id="quote-payment" value={payment} onChange={(e) => setPayment(e.target.value)}>
              {Object.entries(paymentLabels).map(([k, v]) => (
                <option key={k} value={k}>
                  {v}
                </option>
              ))}
            </select>
          </div>
          <div className="field">
            <label htmlFor="quote-delivery">
              <CalendarDays size={20} className="inline-icon" /> Entrega (opcional)
            </label>
            <input
              id="quote-delivery"
              type="date"
              value={delivery}
              onChange={(e) => setDelivery(e.target.value)}
            />
          </div>
          <Feedback error={error || convert.error} />
          <div className="modal-actions">
            <button className="button secondary" disabled={busy} onClick={() => setConfirm(false)}>
              Volver
            </button>
            <button
              className="button primary"
              disabled={busy}
              onClick={() =>
                void execute(async () => {
                  const id = await convert.mutateAsync({ quote: current, payment, delivery });
                  setConfirm(false);
                  onOrder(id);
                })
              }
            >
              Confirmar pedido
            </button>
          </div>
        </Modal>
      )}
    </Modal>
  );
}
