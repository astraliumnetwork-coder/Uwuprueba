import { parseMoney } from '@saas/domain';
import type { QuoteItem } from '../model';
export function parseQuoteText(text: string): QuoteItem[] {
  const items: QuoteItem[] = [];
  for (const line of text.split(/\r?\n/)) {
    const columns = line.split(/\t|;/).map((s) => s.trim());
    if (columns.length >= 3) {
      const name = columns[0] ?? '';
      const quantity = Number(columns[1]);
      try {
        if (name.length >= 2 && Number.isInteger(quantity) && quantity > 0)
          items.push({
            id: crypto.randomUUID(),
            productId: null,
            name,
            quantity,
            priceCents: parseMoney(columns[2] ?? ''),
            costCents: columns[3] ? parseMoney(columns[3]) : 0,
          });
      } catch {
        /* Header or invalid row; reviewed before saving. */
      }
    }
  }
  if (items.length) return items;
  const regex =
    /(?:\b|^)(\d+)\s+([A-Za-z0-9\s\-"ÁÉÍÓÚÑáéíóúñ”]+?)\s+(\d+)\s+(\d+(?:\.\d+)?)\s+(\d+(?:\.\d+)?)(?=\s+\d+\s|$)/g;
  for (const m of text.matchAll(regex))
    items.push({
      id: crypto.randomUUID(),
      productId: null,
      name: m[2]!.trim(),
      quantity: Number(m[3]),
      priceCents: parseMoney(m[4]!),
      costCents: 0,
    });
  return items;
}
export async function importQuoteFile(file: File): Promise<QuoteItem[]> {
  if (file.size > 15 * 1024 * 1024) throw new Error('El archivo debe pesar menos de 15 MB.');
  if (file.name.toLowerCase().endsWith('.pdf')) {
    const pdfjs = await import('pdfjs-dist');
    pdfjs.GlobalWorkerOptions.workerSrc = new URL(
      'pdfjs-dist/build/pdf.worker.min.mjs',
      import.meta.url,
    ).toString();
    const document = await pdfjs.getDocument({ data: await file.arrayBuffer() }).promise;
    try {
      if (document.numPages > 50) throw new Error('Máximo 50 páginas.');
      let text = '';
      for (let n = 1; n <= document.numPages; n++) {
        const page = await document.getPage(n);
        const content = await page.getTextContent();
        text += content.items.map((i) => ('str' in i ? i.str : '')).join(' ') + '\n';
      }
      return parseQuoteText(text);
    } finally {
      await document.destroy();
    }
  }
  if (!file.name.toLowerCase().endsWith('.xlsx'))
    throw new Error('Selecciona un PDF o Excel .xlsx.');
  const { default: ExcelJS } = await import('exceljs');
  const workbook = new ExcelJS.Workbook();
  await workbook.xlsx.load(await file.arrayBuffer());
  const lines: string[] = [];
  workbook.worksheets[0]?.eachRow((row) => {
    const values: string[] = [];
    row.eachCell({ includeEmpty: true }, (cell) =>
      values.push(cell.value === null ? '' : cell.text),
    );
    // Plantillas originales: ítem, descripción, cantidad, precio y total.
    if (/^\d+$/.test(values[0] ?? '') && values.length >= 4) values.shift();
    lines.push(values.slice(0, 3).join('\t'));
  });
  return parseQuoteText(lines.join('\n'));
}
