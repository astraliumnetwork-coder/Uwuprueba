import { Buffer } from 'buffer';
import type { DocumentProps } from '../documents/types';
import type { Quote } from '../model';
import { quoteNumber } from '../model';
export type ExportOptions = {
  brand?: Quote['brand'];
  title?: 'COTIZACION' | 'PEDIDO';
  number?: string;
};
function documentProps(q: Quote, options: ExportOptions = {}): DocumentProps {
  return {
    numero: options.number ?? quoteNumber(q.number),
    titulo: options.title ?? 'COTIZACION',
    cliente: q.customer,
    empresa: q.ruc,
    direccion: q.address,
    fecha: q.date,
    cotizacion: q.items.map((i) => ({
      id: i.id,
      nombre: i.name,
      cantidad: i.quantity,
      precio: i.priceCents / 100,
    })),
    subtotal: q.subtotalCents / 100,
    igv: q.taxCents / 100,
    total: q.totalCents / 100,
    aplicarIgv: q.taxIncluded,
    plantilla: options.brand ?? q.brand,
  };
}
export async function createQuotePdf(q: Quote, options: ExportOptions = {}) {
  // El decodificador PNG usado por react-pdf necesita Buffer también en navegador.
  if (!('Buffer' in globalThis))
    Object.defineProperty(globalThis, 'Buffer', {
      value: Buffer,
      configurable: true,
      writable: true,
    });
  const props = documentProps(q, options);
  const [{ pdf }, { CotizacionPDFReypro }, { CotizacionPDFJuflex }, { CotizacionPDFPremium }] =
    await Promise.all([
      import('@react-pdf/renderer'),
      import('../documents/CotizacionPDFReypro'),
      import('../documents/CotizacionPDFJuflex'),
      import('../documents/CotizacionPDFPremium'),
    ]);
  const Template =
    props.plantilla === 'reypro'
      ? CotizacionPDFReypro
      : props.plantilla === 'juflex'
        ? CotizacionPDFJuflex
        : CotizacionPDFPremium;
  return pdf(<Template {...props} />).toBlob();
}
export function downloadQuotePdf(q: Quote, url: string, options: ExportOptions = {}) {
  const a = document.createElement('a');
  a.href = url;
  a.download = `${options.title ?? 'COTIZACION'}-${options.brand ?? q.brand}-${options.number ?? quoteNumber(q.number)}-${q.customer.replace(/[^\p{L}\p{N} -]/gu, '').slice(0, 60)}.pdf`;
  a.click();
}
export async function exportQuote(q: Quote, format: 'pdf' | 'excel', options: ExportOptions = {}) {
  if (format === 'excel') {
    const { generarExcelPro } = await import('../documents/CotizacionExcel');
    await generarExcelPro(documentProps(q, options));
    return;
  }
  const blob = await createQuotePdf(q, options);
  const url = URL.createObjectURL(blob);
  downloadQuotePdf(q, url, options);
  window.setTimeout(() => URL.revokeObjectURL(url), 10000);
}
