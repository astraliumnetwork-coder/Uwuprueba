import { z } from 'zod';
export const brands = { reypro: 'REYPRO', juflex: 'JUFLEX', premium: 'BETMIN' };
export const quoteItemSchema = z.object({
  id: z.string().uuid(),
  productId: z.string().uuid().nullable(),
  name: z.string().trim().min(2).max(120),
  quantity: z.number().int().min(1).max(100000),
  priceCents: z.number().int().min(0).max(100000000),
  costCents: z.number().int().min(0).max(100000000),
});
export const quoteInputSchema = z.object({
  brand: z.enum(['reypro', 'juflex', 'premium']),
  customer: z.string().trim().min(1).max(120),
  ruc: z
    .string()
    .trim()
    .regex(/^(?:\d{11})?$/, 'El RUC debe tener 11 dígitos o estar vacío.'),
  address: z.string().trim().max(250),
  date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  taxIncluded: z.boolean(),
  items: z.array(quoteItemSchema).min(1).max(100),
});
export const quoteSchema = quoteInputSchema.extend({
  id: z.string().uuid(),
  number: z.number().int(),
  version: z.number().int(),
  totalCents: z.number().int(),
  subtotalCents: z.number().int(),
  taxCents: z.number().int(),
  saleId: z.string().uuid().nullable(),
  createdAt: z.string(),
});
export type QuoteItem = z.infer<typeof quoteItemSchema>;
export type QuoteInput = z.infer<typeof quoteInputSchema>;
export type Quote = z.infer<typeof quoteSchema>;
export function quoteTotals(items: QuoteItem[], taxIncluded: boolean) {
  const totalCents = items.reduce((sum, i) => sum + i.quantity * i.priceCents, 0);
  const subtotalCents = items.reduce(
    (sum, i) =>
      sum + i.quantity * (taxIncluded ? Math.round((i.priceCents * 100) / 118) : i.priceCents),
    0,
  );
  return { totalCents, subtotalCents, taxCents: totalCents - subtotalCents };
}
export const quoteNumber = (n: number) => String(n).padStart(5, '0');
