import type { DocumentProps, DocumentItem } from './types';
import { Document, Page, Text, View, StyleSheet, Image, Link } from '@react-pdf/renderer';

const BORDER_COLOR = '#000000';
const BORDER_WIDTH = 1;

const styles = StyleSheet.create({
  page: { padding: 40, fontSize: 10, fontFamily: 'Helvetica' },
  table: {
    width: '100%',
    borderWidth: BORDER_WIDTH,
    borderColor: BORDER_COLOR,
    borderBottomWidth: 0,
    borderRightWidth: 0,
  },
  tableRow: { flexDirection: 'row' },
  colItem: { width: '8%' },
  colEpps: { width: '47%' },
  colCant: { width: '15%' },
  colPrecio: { width: '15%' },
  colTotal: { width: '15%' },
  colFooterLabel: { width: '85%' },
  cellHeader: {
    backgroundColor: '#95B3D7',
    borderBottomWidth: BORDER_WIDTH,
    borderRightWidth: BORDER_WIDTH,
    borderColor: BORDER_COLOR,
    paddingVertical: 4,
    textAlign: 'center',
    fontWeight: 'bold',
    fontSize: 9,
    justifyContent: 'center',
  },
  cellCenter: {
    borderBottomWidth: BORDER_WIDTH,
    borderRightWidth: BORDER_WIDTH,
    borderColor: BORDER_COLOR,
    paddingVertical: 4,
    textAlign: 'center',
    fontSize: 9,
    justifyContent: 'center',
  },
  cellLeft: {
    borderBottomWidth: BORDER_WIDTH,
    borderRightWidth: BORDER_WIDTH,
    borderColor: BORDER_COLOR,
    paddingVertical: 4,
    paddingHorizontal: 4,
    textAlign: 'left',
    fontSize: 9,
    justifyContent: 'center',
  },
  cellFooterLabel: {
    borderBottomWidth: BORDER_WIDTH,
    borderRightWidth: BORDER_WIDTH,
    borderColor: BORDER_COLOR,
    paddingVertical: 4,
    textAlign: 'right',
    paddingRight: 10,
    fontWeight: 'bold',
    fontSize: 9,
    justifyContent: 'center',
  },
  cellFooterValue: {
    borderBottomWidth: BORDER_WIDTH,
    borderRightWidth: BORDER_WIDTH,
    borderColor: BORDER_COLOR,
    paddingVertical: 4,
    textAlign: 'center',
    fontWeight: 'bold',
    fontSize: 9,
    justifyContent: 'center',
  },
  logoImageReypro: { width: 220, height: 'auto', alignSelf: 'center', marginBottom: 5 },
  yellowHighlight: {
    backgroundColor: '#FFFF00',
    paddingVertical: 3,
    width: '100%',
    textAlign: 'center',
    marginBottom: 5,
    border: '0.5pt solid #000',
  },
  yellowHighlightText: { fontWeight: 'bold', fontSize: 9 },
  headerText: { textAlign: 'center', marginBottom: 1, fontSize: 9 },
  link: {
    color: '#0563C1',
    textDecoration: 'underline',
    textAlign: 'center',
    marginBottom: 1,
    fontSize: 9,
  },
  title: {
    textAlign: 'center',
    fontWeight: 'bold',
    fontSize: 11,
    marginTop: 10,
    marginBottom: 10,
    textDecoration: 'underline',
  },
  clientInfoContainer: { marginBottom: 15 },
  clientRow: { flexDirection: 'row', marginBottom: 2 },
  clientLabel: { width: '130px', fontWeight: 'bold' },
  clientValue: { flex: 1 },
  bankTable: {
    marginTop: 20,
    width: '50%',
    alignSelf: 'center',
    borderWidth: BORDER_WIDTH,
    borderColor: BORDER_COLOR,
    borderBottomWidth: 0,
    borderRightWidth: 0,
  },
  bankHeader: {
    backgroundColor: '#D9D9D9',
    borderBottomWidth: BORDER_WIDTH,
    borderRightWidth: BORDER_WIDTH,
    borderColor: BORDER_COLOR,
    padding: 3,
    fontWeight: 'bold',
    fontSize: 9,
  },
  bankCell: {
    borderBottomWidth: BORDER_WIDTH,
    borderRightWidth: BORDER_WIDTH,
    borderColor: BORDER_COLOR,
    padding: 3,
    fontSize: 8.5,
  },
  bankCellBold: {
    borderBottomWidth: BORDER_WIDTH,
    borderRightWidth: BORDER_WIDTH,
    borderColor: BORDER_COLOR,
    padding: 3,
    fontSize: 9,
    fontWeight: 'bold',
  },
  noteContainer: { marginTop: 20, flexDirection: 'row', alignItems: 'flex-start' },
  noteLabel: { fontWeight: 'bold', fontSize: 9, width: 40 },
  noteText: { fontSize: 8, flex: 1, color: '#333' },
});

export const CotizacionPDFReypro = ({
  cliente,
  empresa,
  direccion,
  fecha,
  cotizacion,
  subtotal,
  aplicarIgv,
  igv,
  total,
  numero,
  titulo = 'COTIZACION',
}: DocumentProps) => {
  let fechaFormateada = fecha;
  if (fecha) {
    const partes = fecha.split('-');
    if (partes.length === 3) fechaFormateada = `${partes[2]}/${partes[1]}/${partes[0]}`;
  } else {
    const date = new Date();
    fechaFormateada = `${date.getDate().toString().padStart(2, '0')}/${(date.getMonth() + 1).toString().padStart(2, '0')}/${date.getFullYear()}`;
  }

  return (
    <Document>
      <Page size="A4" style={styles.page}>
        <Image src="/quote-assets/logo.png" style={styles.logoImageReypro} />
        <View style={styles.yellowHighlight}>
          <Text style={styles.yellowHighlightText}>
            MAYORISTA EN ARTICULOS DE SEGURIDAD INDUSTRIAL
          </Text>
        </View>
        <Text style={styles.headerText}>RUC: 10455108549</Text>
        <Text style={styles.headerText}>
          AV. GRAU CDRA 1 CRUCE CON JIRON SANDIA 498 - CERCADO DE LIMA
        </Text>
        <Link src="mailto:reyproperu@gmail.com" style={styles.link}>
          reyproperu@gmail.com
        </Link>
        <Text style={styles.headerText}>Celular: 933825114</Text>

        <Text style={styles.title}>
          {titulo} {numero || '00000'}
        </Text>

        <View style={styles.clientInfoContainer}>
          <View style={styles.clientRow}>
            <Text style={styles.clientLabel}>NOMBRE/ RAZON SOCIAL:</Text>
            <Text style={styles.clientValue}>{cliente || ''}</Text>
          </View>
          <View style={styles.clientRow}>
            <Text style={styles.clientLabel}>RUC:</Text>
            <Text style={styles.clientValue}>{empresa || ''}</Text>
          </View>
          <View style={styles.clientRow}>
            <Text style={styles.clientLabel}>DIRECCION:</Text>
            <Text style={styles.clientValue}>{direccion || ''}</Text>
          </View>
          <View style={styles.clientRow}>
            <Text style={styles.clientLabel}>FECHA:</Text>
            <Text style={styles.clientValue}>{fechaFormateada}</Text>
          </View>
        </View>

        <View style={styles.table}>
          <View style={styles.tableRow} wrap={false}>
            <View style={[styles.colItem, styles.cellHeader]}>
              <Text>ITEM</Text>
            </View>
            <View style={[styles.colEpps, styles.cellHeader]}>
              <Text>EPPS</Text>
            </View>
            <View style={[styles.colCant, styles.cellHeader]}>
              <Text>CANT</Text>
            </View>
            <View style={[styles.colPrecio, styles.cellHeader]}>
              <Text>PRECIO</Text>
            </View>
            <View style={[styles.colTotal, styles.cellHeader]}>
              <Text>TOTAL</Text>
            </View>
          </View>

          {cotizacion.map((item: DocumentItem, index: number) => {
            const cantidad = Number(item.cantidad) || 0;
            const precioFinal = Number(Number(item.precio).toFixed(2)) || 0;
            const unitBase = aplicarIgv ? Number((precioFinal / 1.18).toFixed(2)) : precioFinal;
            const rowTotalBase = Number((unitBase * cantidad).toFixed(2));

            return (
              <View style={styles.tableRow} key={item.id} wrap={false}>
                <View style={[styles.colItem, styles.cellCenter]}>
                  <Text>{index + 1}</Text>
                </View>
                <View style={[styles.colEpps, styles.cellLeft]}>
                  <Text>{item.nombre}</Text>
                </View>
                <View style={[styles.colCant, styles.cellCenter]}>
                  <Text>{cantidad}</Text>
                </View>
                <View style={[styles.colPrecio, styles.cellCenter]}>
                  <Text>{unitBase.toFixed(2)}</Text>
                </View>
                <View style={[styles.colTotal, styles.cellCenter]}>
                  <Text>{rowTotalBase.toFixed(2)}</Text>
                </View>
              </View>
            );
          })}

          {aplicarIgv && (
            <>
              <View style={styles.tableRow} wrap={false}>
                <View style={[styles.colFooterLabel, styles.cellFooterLabel]}>
                  <Text>SUB TOTAL</Text>
                </View>
                <View style={[styles.colTotal, styles.cellFooterValue]}>
                  <Text>{subtotal.toFixed(2)}</Text>
                </View>
              </View>
              <View style={styles.tableRow} wrap={false}>
                <View style={[styles.colFooterLabel, styles.cellFooterLabel]}>
                  <Text>IGV</Text>
                </View>
                <View style={[styles.colTotal, styles.cellFooterValue]}>
                  <Text>{igv.toFixed(2)}</Text>
                </View>
              </View>
            </>
          )}
          <View style={styles.tableRow} wrap={false}>
            <View style={[styles.colFooterLabel, styles.cellFooterLabel]}>
              <Text>TOTAL</Text>
            </View>
            <View style={[styles.colTotal, styles.cellFooterValue]}>
              <Text>{total.toFixed(2)}</Text>
            </View>
          </View>
        </View>

        <View style={styles.bankTable} wrap={false}>
          <View style={styles.tableRow}>
            <View style={[styles.bankHeader, { width: '100%' }]}>
              <Text>RAY ESTIBEN MAMANI GARAMENDI - CUENTA AHORROS:</Text>
            </View>
          </View>
          <View style={styles.tableRow}>
            <View style={[styles.bankCell, { width: '40%' }]}>
              <Text>BCP:</Text>
            </View>
            <View style={[styles.bankCell, { width: '60%' }]}>
              <Text>191 93638596 0 37</Text>
            </View>
          </View>
          <View style={styles.tableRow}>
            <View style={[styles.bankCell, { width: '40%' }]}>
              <Text>BBVA:</Text>
            </View>
            <View style={[styles.bankCell, { width: '60%' }]}>
              <Text>0011 0115 0200569178</Text>
            </View>
          </View>
          <View style={styles.tableRow}>
            <View style={[styles.bankCell, { width: '40%' }]}>
              <Text>INTERBANK:</Text>
            </View>
            <View style={[styles.bankCell, { width: '60%' }]}>
              <Text>200 3085137340</Text>
            </View>
          </View>
          <View style={styles.tableRow}>
            <View style={[styles.bankCell, { width: '40%' }]}>
              <Text>SCOTIABANK:</Text>
            </View>
            <View style={[styles.bankCell, { width: '60%' }]}>
              <Text>009 7437164</Text>
            </View>
          </View>
        </View>

        <View style={styles.noteContainer} wrap={false}>
          <Text style={styles.noteLabel}>NOTA:</Text>
          <Text style={styles.noteText}>
            Mientras el pedido no este cancelado, la Empresa REYPRO, no se compromete con la entrega
            de los productos solicitados.
          </Text>
        </View>
      </Page>
    </Document>
  );
};
