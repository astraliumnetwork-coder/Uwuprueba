import type { DocumentProps, DocumentItem } from './types';
import { Document, Page, Text, View, StyleSheet, Image } from '@react-pdf/renderer';

const JUFLEX_LIGHT_BLUE = '#97c1e9';
const JUFLEX_BG_COLOR = '#ffc000';
const BORDER_COLOR = '#000000';
const BORDER_WIDTH = 1;

const styles = StyleSheet.create({
  page: { padding: 40, fontSize: 10, fontFamily: 'Helvetica' },

  headerCenter: { alignItems: 'center', marginBottom: 20 },
  logoImage: { width: 220, height: 'auto' },
  sloganBold: {
    fontSize: 11,
    color: JUFLEX_LIGHT_BLUE,
    fontFamily: 'Helvetica-Bold',
    fontWeight: 'bold',
    marginTop: 8,
    textAlign: 'center',
    letterSpacing: 0.5,
  },

  topInfoSection: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 20,
  },
  clientSection: { width: '60%' },

  quoteDateBox: { width: 150, borderWidth: BORDER_WIDTH, borderColor: BORDER_COLOR },
  quoteDateRow: {
    flexDirection: 'row',
    borderBottomWidth: BORDER_WIDTH,
    borderColor: BORDER_COLOR,
  },
  quoteDateRowLast: { flexDirection: 'row' },
  quoteDateLabelCell: {
    width: '45%',
    backgroundColor: '#e5e7eb',
    padding: 4,
    borderRightWidth: BORDER_WIDTH,
    borderColor: BORDER_COLOR,
    textAlign: 'center',
    fontFamily: 'Helvetica-Bold',
    fontWeight: 'bold',
    fontSize: 9,
  },
  quoteDateValueCell: { flex: 1, padding: 4, textAlign: 'center', fontSize: 9 },

  row: { flexDirection: 'row', marginBottom: 3 },
  label: { width: 65, fontFamily: 'Helvetica-Bold', fontWeight: 'bold' },
  value: { flex: 1 },
  normalText: { marginBottom: 3 },

  centeredContactInfo: { alignItems: 'center', marginBottom: 15 },
  centeredBoldText: {
    fontFamily: 'Helvetica-Bold',
    fontWeight: 'bold',
    fontSize: 10,
    marginBottom: 3,
  },

  greetingSection: { marginBottom: 15 },
  greetingParagraph: { lineHeight: 1.4, textAlign: 'center' },

  table: {
    width: '100%',
    borderWidth: BORDER_WIDTH,
    borderColor: BORDER_COLOR,
    borderBottomWidth: 0,
    borderRightWidth: 0,
  },
  tableRow: { flexDirection: 'row' },
  colItem: { width: '8%' },
  colEpps: { width: '47%' },
  colCant: { width: '15%' },
  colPrecio: { width: '15%' },
  colTotal: { width: '15%' },
  colFooterLabel: { width: '85%' },

  cellHeader: {
    backgroundColor: JUFLEX_BG_COLOR,
    borderBottomWidth: BORDER_WIDTH,
    borderRightWidth: BORDER_WIDTH,
    borderColor: BORDER_COLOR,
    paddingVertical: 4,
    textAlign: 'center',
    fontFamily: 'Helvetica-Bold',
    fontWeight: 'bold',
    fontSize: 9,
    justifyContent: 'center',
  },
  cellCenter: {
    borderBottomWidth: BORDER_WIDTH,
    borderRightWidth: BORDER_WIDTH,
    borderColor: BORDER_COLOR,
    paddingVertical: 4,
    textAlign: 'center',
    fontSize: 9,
    justifyContent: 'center',
  },
  cellLeft: {
    borderBottomWidth: BORDER_WIDTH,
    borderRightWidth: BORDER_WIDTH,
    borderColor: BORDER_COLOR,
    paddingVertical: 4,
    paddingHorizontal: 4,
    textAlign: 'left',
    fontSize: 9,
    justifyContent: 'center',
  },
  cellFooterLabel: {
    borderBottomWidth: BORDER_WIDTH,
    borderRightWidth: BORDER_WIDTH,
    borderColor: BORDER_COLOR,
    paddingVertical: 4,
    textAlign: 'right',
    paddingRight: 10,
    fontFamily: 'Helvetica-Bold',
    fontWeight: 'bold',
    fontSize: 9,
    justifyContent: 'center',
  },
  cellFooterValue: {
    borderBottomWidth: BORDER_WIDTH,
    borderRightWidth: BORDER_WIDTH,
    borderColor: BORDER_COLOR,
    paddingVertical: 4,
    textAlign: 'center',
    fontFamily: 'Helvetica-Bold',
    fontWeight: 'bold',
    fontSize: 9,
    justifyContent: 'center',
  },

  centeredFooter: { marginTop: 25, alignItems: 'center' },
  boldText: { fontFamily: 'Helvetica-Bold', fontWeight: 'bold' },
});

export const CotizacionPDFJuflex = ({
  cliente,
  empresa,
  direccion,
  fecha,
  cotizacion,
  subtotal,
  aplicarIgv,
  igv,
  total,
  numero,
  titulo = 'COTIZACION',
}: DocumentProps) => {
  let fechaFormateada = fecha;
  if (fecha) {
    const partes = fecha.split('-');
    if (partes.length === 3) fechaFormateada = `${partes[2]}/${partes[1]}/${partes[0]}`;
  } else {
    const date = new Date();
    fechaFormateada = `${date.getDate().toString().padStart(2, '0')}/${(date.getMonth() + 1).toString().padStart(2, '0')}/${date.getFullYear()}`;
  }

  return (
    <Document>
      <Page size="A4" style={styles.page}>
        <View style={styles.headerCenter}>
          <Image src="/quote-assets/logo-juflex.png" style={styles.logoImage} />
          <Text style={styles.sloganBold}>…Cuidamos de tu seguridad</Text>
        </View>

        <View style={styles.topInfoSection}>
          <View style={styles.clientSection}>
            <View style={styles.row}>
              <Text style={styles.label}>SEÑORES:</Text>
              <Text style={styles.value}>{cliente || '_______________________'}</Text>
            </View>
            <View style={styles.row}>
              <Text style={styles.label}>RUC:</Text>
              <Text style={styles.value}>{empresa || '_______________________'}</Text>
            </View>
            <View style={styles.row}>
              <Text style={styles.label}>DIRECCIÓN:</Text>
              <Text style={styles.value}>{direccion || '_______________________'}</Text>
            </View>
            <Text style={styles.normalText}>Presente. -</Text>
          </View>

          <View style={styles.quoteDateBox}>
            <View style={styles.quoteDateRow}>
              <Text style={styles.quoteDateLabelCell}>
                {titulo === 'PEDIDO' ? 'PEDIDO' : 'N° COTIZ'}
              </Text>
              <Text style={styles.quoteDateValueCell}>{numero || '00000'}</Text>
            </View>
            <View style={styles.quoteDateRowLast}>
              <Text style={styles.quoteDateLabelCell}>FECHA</Text>
              <Text style={styles.quoteDateValueCell}>{fechaFormateada}</Text>
            </View>
          </View>
        </View>

        <View style={styles.centeredContactInfo}>
          <Text style={styles.centeredBoldText}>Atte.: Área Logistica.</Text>
          <Text style={styles.centeredBoldText}>Asesora de venta: Judith Mirtha</Text>
          <Text style={styles.centeredBoldText}>cel. 924347528</Text>
        </View>

        <View style={styles.greetingSection}>
          <Text style={styles.greetingParagraph}>
            Por medio de la presente me dirijo a ustedes a fin de saludarles cordialmente
          </Text>
        </View>

        <View style={styles.table}>
          <View style={styles.tableRow} wrap={false}>
            <View style={[styles.colItem, styles.cellHeader]}>
              <Text>ITEM</Text>
            </View>
            <View style={[styles.colEpps, styles.cellHeader]}>
              <Text>EQUIP. PROTEC. PERS.</Text>
            </View>
            <View style={[styles.colCant, styles.cellHeader]}>
              <Text>CANT</Text>
            </View>
            <View style={[styles.colPrecio, styles.cellHeader]}>
              <Text>PRECIO</Text>
            </View>
            <View style={[styles.colTotal, styles.cellHeader]}>
              <Text>TOTAL</Text>
            </View>
          </View>

          {cotizacion.map((item: DocumentItem, index: number) => {
            const cantidad = item.cantidad || 0;
            const precioFinal = Number(item.precio) || 0;
            const unitBase = aplicarIgv ? Number((precioFinal / 1.18).toFixed(2)) : precioFinal;
            const rowTotalBase = Number((unitBase * cantidad).toFixed(2));

            return (
              <View style={styles.tableRow} key={item.id} wrap={false}>
                <View style={[styles.colItem, styles.cellCenter]}>
                  <Text>{index + 1}</Text>
                </View>
                <View style={[styles.colEpps, styles.cellLeft]}>
                  <Text>{item.nombre}</Text>
                </View>
                <View style={[styles.colCant, styles.cellCenter]}>
                  <Text>{cantidad}</Text>
                </View>
                <View style={[styles.colPrecio, styles.cellCenter]}>
                  <Text>{unitBase.toFixed(2)}</Text>
                </View>
                <View style={[styles.colTotal, styles.cellCenter]}>
                  <Text>{rowTotalBase.toFixed(2)}</Text>
                </View>
              </View>
            );
          })}

          {aplicarIgv && (
            <>
              <View style={styles.tableRow} wrap={false}>
                <View style={[styles.colFooterLabel, styles.cellFooterLabel]}>
                  <Text>SUB TOTAL</Text>
                </View>
                <View style={[styles.colTotal, styles.cellFooterValue]}>
                  <Text>{subtotal.toFixed(2)}</Text>
                </View>
              </View>
              <View style={styles.tableRow} wrap={false}>
                <View style={[styles.colFooterLabel, styles.cellFooterLabel]}>
                  <Text>IGV</Text>
                </View>
                <View style={[styles.colTotal, styles.cellFooterValue]}>
                  <Text>{igv.toFixed(2)}</Text>
                </View>
              </View>
            </>
          )}

          <View style={styles.tableRow} wrap={false}>
            <View style={[styles.colFooterLabel, styles.cellFooterLabel]}>
              <Text>TOTAL</Text>
            </View>
            <View style={[styles.colTotal, styles.cellFooterValue]}>
              <Text>{total.toFixed(2)}</Text>
            </View>
          </View>
        </View>

        <View style={styles.centeredFooter} wrap={false}>
          <Text style={{ ...styles.normalText, marginBottom: 15 }}>
            Agradeciendo la confianza depositada en nuestra Empresa,
          </Text>
          <Text style={styles.boldText}>ATENTAMENTE,</Text>
          <Text style={styles.normalText}>JUFLEX</Text>
          <Text style={styles.normalText}>RUC: 10485976260</Text>
          <Text style={styles.normalText}>AV. JOSE GALVEZ 134, La Victoria.</Text>
        </View>
      </Page>
    </Document>
  );
};
