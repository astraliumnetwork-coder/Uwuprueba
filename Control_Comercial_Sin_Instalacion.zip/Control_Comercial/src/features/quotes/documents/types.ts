export type DocumentItem = { id: string; nombre: string; cantidad: number; precio: number };
export type DocumentProps = {
  numero: string;
  titulo?: 'COTIZACION' | 'PEDIDO';
  cliente: string;
  empresa: string;
  direccion: string;
  fecha: string;
  cotizacion: DocumentItem[];
  subtotal: number;
  aplicarIgv: boolean;
  igv: number;
  total: number;
  plantilla?: string;
};
