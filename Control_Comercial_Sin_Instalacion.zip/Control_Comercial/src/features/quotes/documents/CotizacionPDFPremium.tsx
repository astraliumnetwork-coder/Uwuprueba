import type { DocumentProps, DocumentItem } from './types';
import { Document, Page, Text, View, StyleSheet, Image } from '@react-pdf/renderer';

const ACCENT_COLOR = '#1e3a8a';
const TEXT_COLOR = '#334155';
const BORDER_COLOR = '#000000';
const BORDER_WIDTH = 1;

const styles = StyleSheet.create({
  page: { padding: 40, fontSize: 10, fontFamily: 'Helvetica', color: TEXT_COLOR, lineHeight: 1.5 },

  headerContainer: { alignItems: 'center', marginBottom: 20 },
  logoImage: { width: 230, height: 'auto', marginBottom: 10 },
  headerTitle: {
    fontSize: 18,
    fontFamily: 'Helvetica-Bold',
    color: ACCENT_COLOR,
    letterSpacing: 0.5,
    marginBottom: 4,
    textAlign: 'center',
  },
  headerSubtitle: {
    fontSize: 10,
    fontFamily: 'Helvetica-Bold',
    color: '#64748b',
    textAlign: 'center',
    marginBottom: 2,
  },
  headerRuc: { fontSize: 10, color: '#64748b', textAlign: 'center' },

  separator: { borderBottomWidth: 2, borderBottomColor: ACCENT_COLOR, marginBottom: 20 },

  infoBlock: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 20 },
  clientSection: {
    width: '62%',
    backgroundColor: '#f8fafc',
    padding: 12,
    borderRadius: 6,
    borderLeftWidth: 4,
    borderLeftColor: ACCENT_COLOR,
  },
  docSection: {
    width: '34%',
    backgroundColor: '#f8fafc',
    padding: 12,
    borderRadius: 6,
    borderLeftWidth: 4,
    borderLeftColor: ACCENT_COLOR,
    justifyContent: 'center',
  },

  row: { flexDirection: 'row', marginBottom: 5 },
  label: { width: 75, fontFamily: 'Helvetica-Bold', fontSize: 9, color: ACCENT_COLOR },
  value: { flex: 1, fontSize: 9 },

  presentationText: { fontSize: 10, marginBottom: 15, textAlign: 'justify', color: '#475569' },
  boldText: { fontFamily: 'Helvetica-Bold', color: ACCENT_COLOR },
  closingBlock: { marginBottom: 30, marginTop: 15 },
  closingText: { fontSize: 10, textAlign: 'justify', color: '#475569', marginBottom: 5 },
  signature: { fontSize: 10, fontFamily: 'Helvetica-Bold', color: ACCENT_COLOR, marginTop: 15 },

  table: {
    width: '100%',
    borderWidth: BORDER_WIDTH,
    borderColor: BORDER_COLOR,
    borderBottomWidth: 0,
    borderRightWidth: 0,
  },
  tableRow: { flexDirection: 'row' },
  colItem: { width: '8%' },
  colEpps: { width: '47%' },
  colCant: { width: '15%' },
  colPrecio: { width: '15%' },
  colTotal: { width: '15%' },
  colFooterLabel: { width: '85%' },

  cellHeader: {
    backgroundColor: '#95B3D7',
    borderBottomWidth: BORDER_WIDTH,
    borderRightWidth: BORDER_WIDTH,
    borderColor: BORDER_COLOR,
    paddingVertical: 4,
    textAlign: 'center',
    fontFamily: 'Helvetica-Bold',
    fontWeight: 'bold',
    fontSize: 9,
    color: '#000',
    justifyContent: 'center',
  },
  cellCenter: {
    borderBottomWidth: BORDER_WIDTH,
    borderRightWidth: BORDER_WIDTH,
    borderColor: BORDER_COLOR,
    paddingVertical: 4,
    textAlign: 'center',
    fontSize: 9,
    color: '#000',
    justifyContent: 'center',
  },
  cellLeft: {
    borderBottomWidth: BORDER_WIDTH,
    borderRightWidth: BORDER_WIDTH,
    borderColor: BORDER_COLOR,
    paddingVertical: 4,
    paddingHorizontal: 4,
    textAlign: 'left',
    fontSize: 9,
    color: '#000',
    justifyContent: 'center',
  },
  cellFooterLabel: {
    borderBottomWidth: BORDER_WIDTH,
    borderRightWidth: BORDER_WIDTH,
    borderColor: BORDER_COLOR,
    paddingVertical: 4,
    textAlign: 'right',
    paddingRight: 10,
    fontFamily: 'Helvetica-Bold',
    fontWeight: 'bold',
    fontSize: 9,
    color: '#000',
    justifyContent: 'center',
  },
  cellFooterValue: {
    borderBottomWidth: BORDER_WIDTH,
    borderRightWidth: BORDER_WIDTH,
    borderColor: BORDER_COLOR,
    paddingVertical: 4,
    textAlign: 'center',
    fontFamily: 'Helvetica-Bold',
    fontWeight: 'bold',
    fontSize: 9,
    color: '#000',
    justifyContent: 'center',
  },

  footer: { marginTop: 'auto', paddingTop: 15, borderTopWidth: 1, borderTopColor: '#cbd5e1' },
  footerTitle: { fontFamily: 'Helvetica-Bold', fontSize: 10, color: ACCENT_COLOR, marginBottom: 8 },
  footerText: { fontSize: 9, marginBottom: 4, color: '#475569' },
  footerNote: { fontSize: 8, fontStyle: 'italic', color: '#94a3b8', marginTop: 8 },
});

export const CotizacionPDFPremium = ({
  cliente,
  empresa,
  direccion,
  fecha,
  cotizacion,
  subtotal,
  aplicarIgv,
  igv,
  total,
  numero,
  titulo = 'COTIZACION',
}: DocumentProps) => {
  let fechaFormateada = fecha;
  if (fecha) {
    const partes = fecha.split('-');
    if (partes.length === 3) fechaFormateada = `${partes[2]}/${partes[1]}/${partes[0]}`;
  } else {
    const date = new Date();
    fechaFormateada = `${date.getDate().toString().padStart(2, '0')}/${(date.getMonth() + 1).toString().padStart(2, '0')}/${date.getFullYear()}`;
  }

  return (
    <Document>
      <Page size="A4" style={styles.page}>
        <View style={styles.headerContainer}>
          <Image src="/quote-assets/logobetmin.png" style={styles.logoImage} />
          <Text style={styles.headerTitle}>PROPUESTA COMERCIAL</Text>
          <Text style={styles.headerSubtitle}>VENTAS CORPORATIVAS</Text>
          <Text style={styles.headerRuc}>RUC: 10471945078</Text>
        </View>

        <View style={styles.separator} />

        <View style={styles.infoBlock}>
          <View style={styles.clientSection}>
            <View style={styles.row}>
              <Text style={styles.label}>SEÑORES:</Text>
              <Text style={styles.value}>{cliente || '__________________________________'}</Text>
            </View>
            <View style={styles.row}>
              <Text style={styles.label}>RUC:</Text>
              <Text style={styles.value}>{empresa || '__________________________________'}</Text>
            </View>
            <View style={styles.row}>
              <Text style={styles.label}>DIRECCIÓN:</Text>
              <Text style={styles.value}>{direccion || '__________________________________'}</Text>
            </View>
          </View>

          <View style={styles.docSection}>
            <View style={styles.row}>
              <Text style={styles.label}>{titulo === 'PEDIDO' ? 'PEDIDO:' : 'N° COTIZ.:'}</Text>
              <Text style={styles.value}>{numero || '00000'}</Text>
            </View>
            <View style={styles.row}>
              <Text style={styles.label}>FECHA:</Text>
              <Text style={styles.value}>{fechaFormateada}</Text>
            </View>
          </View>
        </View>

        <Text style={styles.presentationText}>
          <Text style={styles.boldText}>De nuestra mayor consideración:</Text>
          {'\n\n'}
          Por medio de la presente, nos es grato dirigirnos a ustedes con el fin de saludarles
          cordialmente y hacerles llegar nuestra propuesta comercial de acuerdo a sus
          requerimientos. A continuación, detallamos los productos:
        </Text>

        <View style={styles.table}>
          <View style={styles.tableRow} wrap={false}>
            <View style={[styles.colItem, styles.cellHeader]}>
              <Text>ITEM</Text>
            </View>
            <View style={[styles.colEpps, styles.cellHeader]}>
              <Text>EPPS</Text>
            </View>
            <View style={[styles.colCant, styles.cellHeader]}>
              <Text>CANT</Text>
            </View>
            <View style={[styles.colPrecio, styles.cellHeader]}>
              <Text>PRECIO</Text>
            </View>
            <View style={[styles.colTotal, styles.cellHeader]}>
              <Text>TOTAL</Text>
            </View>
          </View>

          {cotizacion.map((item: DocumentItem, index: number) => {
            const cantidad = item.cantidad || 0;
            const precioFinal = Number(item.precio) || 0;
            const unitBase = aplicarIgv ? Number((precioFinal / 1.18).toFixed(2)) : precioFinal;
            const rowTotalBase = Number((unitBase * cantidad).toFixed(2));

            return (
              <View style={styles.tableRow} key={item.id} wrap={false}>
                <View style={[styles.colItem, styles.cellCenter]}>
                  <Text>{index + 1}</Text>
                </View>
                <View style={[styles.colEpps, styles.cellLeft]}>
                  <Text>{item.nombre}</Text>
                </View>
                <View style={[styles.colCant, styles.cellCenter]}>
                  <Text>{cantidad}</Text>
                </View>
                <View style={[styles.colPrecio, styles.cellCenter]}>
                  <Text>{unitBase.toFixed(2)}</Text>
                </View>
                <View style={[styles.colTotal, styles.cellCenter]}>
                  <Text>{rowTotalBase.toFixed(2)}</Text>
                </View>
              </View>
            );
          })}

          {aplicarIgv && (
            <>
              <View style={styles.tableRow} wrap={false}>
                <View style={[styles.colFooterLabel, styles.cellFooterLabel]}>
                  <Text>SUB TOTAL</Text>
                </View>
                <View style={[styles.colTotal, styles.cellFooterValue]}>
                  <Text>{subtotal.toFixed(2)}</Text>
                </View>
              </View>
              <View style={styles.tableRow} wrap={false}>
                <View style={[styles.colFooterLabel, styles.cellFooterLabel]}>
                  <Text>IGV</Text>
                </View>
                <View style={[styles.colTotal, styles.cellFooterValue]}>
                  <Text>{igv.toFixed(2)}</Text>
                </View>
              </View>
            </>
          )}

          <View style={styles.tableRow} wrap={false}>
            <View style={[styles.colFooterLabel, styles.cellFooterLabel]}>
              <Text>TOTAL</Text>
            </View>
            <View style={[styles.colTotal, styles.cellFooterValue]}>
              <Text>{total.toFixed(2)}</Text>
            </View>
          </View>
        </View>

        <View style={styles.closingBlock} wrap={false}>
          <Text style={styles.closingText}>
            Esperando que nuestra propuesta sea de su total agrado y satisfaga sus expectativas,
            quedamos a su entera disposición para cualquier consulta o aclaración adicional que
            requieran.
          </Text>
          <Text style={styles.signature}>Atentamente, el equipo de ventas.</Text>
        </View>

        <View style={styles.footer} wrap={false}>
          <Text style={styles.footerTitle}>INFORMACIÓN BANCARIA Y CONDICIONES</Text>
          <Text style={styles.footerText}>
            • <Text style={styles.boldText}>BCP SOLES:</Text> 191-12345678-0-00 (CCI:
            002191123456780000)
          </Text>
          <Text style={styles.footerText}>
            • <Text style={styles.boldText}>BBVA SOLES:</Text> 0011-0123-0100123456
          </Text>
        </View>
      </Page>
    </Document>
  );
};
