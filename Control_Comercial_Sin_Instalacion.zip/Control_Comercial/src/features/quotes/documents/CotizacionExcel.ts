import type { DocumentProps, DocumentItem } from './types';
import ExcelJS from 'exceljs';

export const generarExcelPro = async ({
  cliente,
  empresa,
  direccion,
  fecha,
  cotizacion,
  subtotal,
  aplicarIgv,
  igv,
  total,
  plantilla = 'reypro',
  numero,
  titulo = 'COTIZACION',
}: DocumentProps) => {
  const workbook = new ExcelJS.Workbook();
  const worksheet = workbook.addWorksheet('Hoja1');

  const borderStyle: Partial<ExcelJS.Borders> = {
    top: { style: 'thin' },
    left: { style: 'thin' },
    bottom: { style: 'thin' },
    right: { style: 'thin' },
  };

  let fechaFormateada = fecha;
  if (fecha && fecha.length === 10 && fecha.includes('-')) {
    const partes = fecha.split('-');
    if (partes.length === 3) fechaFormateada = `${partes[2]}/${partes[1]}/${partes[0]}`;
  } else if (fecha && fecha.length === 10 && fecha.includes('/')) {
    fechaFormateada = fecha;
  }

  // ==========================================
  // PLANTILLA 1: REYPRO (PRECISIÓN EXACTA)
  // ==========================================
  if (plantilla === 'reypro') {
    worksheet.columns = [
      { width: 6 },
      { width: 38 },
      { width: 8 },
      { width: 11 },
      { width: 11, hidden: true },
      { width: 12 },
    ];

    worksheet.mergeCells('A1:F5');
    try {
      const response = await fetch('/quote-assets/logoexcel.png');
      const imageBuffer = await response.arrayBuffer();
      const logoId = workbook.addImage({
        buffer: imageBuffer as unknown as ExcelJS.Buffer,
        extension: 'png',
      });
      worksheet.addImage(logoId, { tl: { col: 1.7, row: 0.4 }, ext: { width: 300, height: 65 } });
    } catch {
      worksheet.getCell('A1').value = 'REYPRO®';
      worksheet.getCell('A1').font = { size: 28, bold: true };
      worksheet.getCell('A1').alignment = { horizontal: 'center', vertical: 'middle' };
    }

    worksheet.mergeCells('A6:F6');
    const subtitle = worksheet.getCell('A6');
    subtitle.value = 'MAYORISTA EN ARTICULOS DE SEGURIDAD INDUSTRIAL';
    subtitle.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFFFFF00' } };
    subtitle.font = { bold: true, size: 10 };
    subtitle.alignment = { horizontal: 'center', vertical: 'middle' };

    const addCenterText = (row: number, text: string) => {
      worksheet.mergeCells(`A${row}:F${row}`);
      const cell = worksheet.getCell(`A${row}`);
      cell.value = text;
      cell.alignment = { horizontal: 'center' };
      cell.font = { size: 10 };
    };
    addCenterText(7, 'RUC: 10455108549');
    addCenterText(8, 'AV. GRAU CDRA 1 CRUCE CON JIRON SANDIA 498  - CERCADO DE LIMA');
    worksheet.mergeCells('A9:F9');
    const emailCell = worksheet.getCell('A9');
    emailCell.value = { text: 'reyproperu@gmail.com', hyperlink: 'mailto:reyproperu@gmail.com' };
    emailCell.font = { size: 10, color: { argb: 'FF0563C1' }, underline: true };
    emailCell.alignment = { horizontal: 'center' };
    addCenterText(10, 'Celular:  933825114');

    worksheet.mergeCells('A12:F12');
    const title = worksheet.getCell('A12');
    title.value = `${titulo} ${numero || '00000'}`;
    title.font = { bold: true, size: 12 };
    title.alignment = { horizontal: 'center' };

    const setClientData = (row: number, label: string, value: string) => {
      worksheet.getCell(`B${row}`).value = label;
      worksheet.getCell(`B${row}`).font = { bold: true, size: 10 };
      worksheet.mergeCells(`C${row}:F${row}`);
      worksheet.getCell(`C${row}`).value = value;
      worksheet.getCell(`C${row}`).font = { size: 10 };
    };
    setClientData(13, 'NOMBRE/ RAZON SOCIAL:  ', cliente || '');
    setClientData(14, 'RUC: ', empresa || '');
    setClientData(15, 'DIRECCION: ', direccion || '');
    setClientData(16, 'FECHA:', fechaFormateada || '');

    worksheet.getCell('E17').value = 1.18;
    worksheet.getCell('E17').alignment = { horizontal: 'right' };

    const headerRowIndex = 18;
    worksheet.getRow(headerRowIndex).values = [
      'ITEM',
      'EPPS',
      'CANT',
      'PRECIO',
      'PRECIO ',
      'TOTAL',
    ];
    ['A', 'B', 'C', 'D', 'E', 'F'].forEach((col) => {
      const cell = worksheet.getCell(`${col}${headerRowIndex}`);
      cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF95B3D7' } };
      cell.font = { bold: true, size: 10 };
      cell.alignment = { horizontal: 'center', vertical: 'middle' };
      cell.border = borderStyle;
    });

    let currentRow = 19;
    const startRow = 19;

    cotizacion.forEach((item: DocumentItem, index: number) => {
      const cantidad = item.cantidad || 0;
      const precioFinal = Number(item.precio) || 0;
      const unitBase = aplicarIgv ? Number((precioFinal / 1.18).toFixed(2)) : precioFinal;
      const rowTotalBase = Number((unitBase * cantidad).toFixed(2));

      const row = worksheet.getRow(currentRow);
      row.getCell('A').value = index + 1;
      row.getCell('B').value = item.nombre;
      row.getCell('C').value = cantidad;

      row.getCell('D').value = unitBase;
      if (aplicarIgv) {
        row.getCell('E').value = unitBase;
      } else {
        row.getCell('E').value = precioFinal;
      }

      row.getCell('F').value = {
        formula: `ROUND(C${currentRow}*D${currentRow}, 2)`,
        result: rowTotalBase,
      };

      ['A', 'B', 'C', 'D', 'E', 'F'].forEach((col) => {
        const cell = worksheet.getCell(`${col}${currentRow}`);
        cell.border = borderStyle;
        cell.font = { size: 10 };
        if (col !== 'B') cell.alignment = { horizontal: 'center' };
      });
      worksheet.getCell(`D${currentRow}`).numFmt = '0.00';
      worksheet.getCell(`E${currentRow}`).numFmt = '0.00';
      worksheet.getCell(`F${currentRow}`).numFmt = '0.00';
      currentRow++;
    });

    const endRow = currentRow - 1;

    const createTotalRow = (label: string, value: number, showIgv = false, formula?: string) => {
      worksheet.mergeCells(`A${currentRow}:E${currentRow}`);
      const labelCell = worksheet.getCell(`A${currentRow}`);
      labelCell.value = label;
      labelCell.alignment = { horizontal: 'right' };
      ['A', 'B', 'C', 'D', 'E'].forEach((col) => {
        const cell = worksheet.getCell(`${col}${currentRow}`);
        cell.border = { top: { style: 'thin' }, bottom: { style: 'thin' } };
        if (col === 'A') cell.border.left = { style: 'thin' };
        if (col === 'E') cell.border.right = { style: 'thin' };
      });

      const valCell = worksheet.getCell(`F${currentRow}`);
      if (formula) {
        valCell.value = { formula: formula, result: Number(value.toFixed(2)) };
      } else {
        valCell.value = Number(value.toFixed(2));
      }
      valCell.border = borderStyle;
      valCell.numFmt = '0.00';

      if (showIgv) worksheet.getCell(`G${currentRow}`).value = 0.18;
      currentRow++;
    };

    if (aplicarIgv) {
      const sumTotalFormula = `ROUND(SUM(F${startRow}:F${endRow}), 2)`;

      createTotalRow('SUB TOTAL', subtotal, false, sumTotalFormula);
      createTotalRow('IGV', igv, true);
      createTotalRow('TOTAL', total, false);
    } else {
      createTotalRow('TOTAL', total, false, `ROUND(SUM(F${startRow}:F${endRow}), 2)`);
    }

    currentRow += 2;
    const addBankRow = (text: string, isHeader = false) => {
      worksheet.mergeCells(`B${currentRow}:D${currentRow}`);
      const cell = worksheet.getCell(`B${currentRow}`);
      cell.value = text;
      cell.alignment = { wrapText: true, vertical: 'middle' };
      cell.font = { size: 10, bold: isHeader };

      ['B', 'C', 'D'].forEach((col) => {
        const cellBorder: Partial<ExcelJS.Borders> = {
          top: { style: 'thin' },
          bottom: { style: 'thin' },
        };
        if (col === 'B') cellBorder.left = { style: 'thin' };
        if (col === 'D') cellBorder.right = { style: 'thin' };
        worksheet.getCell(`${col}${currentRow}`).border = cellBorder;
      });

      if (isHeader) {
        cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFD9D9D9' } };
        worksheet.getRow(currentRow).height = 30;
      }
      currentRow++;
    };

    addBankRow('RAY ESTIBEN MAMANI GARAMENDI\nCUENTA AHORROS:', true);
    addBankRow('BCP: 191 93638596 0 37');
    addBankRow('BBVA: 0011 0115 0200569178');
    addBankRow('INTERBANK : 200 3085137340');
    addBankRow('SCOTIABANK: 009 7437164');

    currentRow += 2;
    worksheet.getCell(`A${currentRow}`).value = 'NOTA:';
    worksheet.getCell(`A${currentRow}`).font = { bold: true, size: 9 };
    worksheet.mergeCells(`B${currentRow}:F${currentRow}`);
    worksheet.getCell(`B${currentRow}`).value =
      'Mientras el pedido no este cancelado, la Empresa REYPRO, no se compromete con la entrega de los productos solicitados.';
    worksheet.getCell(`B${currentRow}`).font = { size: 9 };
  }

  // ==========================================
  // PLANTILLA 2: JUFLEX (PRECISIÓN EXACTA)
  // ==========================================
  else if (plantilla === 'juflex') {
    worksheet.columns = [
      { width: 6 }, // A: ITEM
      { width: 45 }, // B: EQUIP. PROTEC. PERS.
      { width: 10 }, // C: CANT
      { width: 15 }, // D: PRECIO
      { width: 15 }, // E: TOTAL
    ];

    worksheet.mergeCells('A1:E4');
    try {
      const response = await fetch('/quote-assets/logojuflexexcel.png');
      const imageBuffer = await response.arrayBuffer();
      const logoId = workbook.addImage({
        buffer: imageBuffer as unknown as ExcelJS.Buffer,
        extension: 'png',
      });
      worksheet.addImage(logoId, { tl: { col: 1.4, row: 0.2 }, ext: { width: 400, height: 65 } });
    } catch {
      worksheet.getCell('A1').value = 'JUFLEX';
      worksheet.getCell('A1').font = { size: 24, bold: true };
      worksheet.getCell('A1').alignment = { horizontal: 'center', vertical: 'middle' };
    }

    worksheet.mergeCells('A5:E5');
    worksheet.getCell('A5').value = '…Cuidamos de tu seguridad';
    worksheet.getCell('A5').font = { bold: true, size: 11, color: { argb: 'FF97C1E9' } };
    worksheet.getCell('A5').alignment = { horizontal: 'center' };

    worksheet.getCell('A7').value = 'SEÑORES:';
    worksheet.getCell('A7').font = { bold: true, size: 10 };
    worksheet.getCell('B7').value = cliente || '';

    worksheet.getCell('D7').value = titulo === 'PEDIDO' ? 'PEDIDO' : 'N° COTIZ';
    worksheet.getCell('D7').font = { bold: true, size: 9 };
    worksheet.getCell('D7').fill = {
      type: 'pattern',
      pattern: 'solid',
      fgColor: { argb: 'FFE5E7EB' },
    };
    worksheet.getCell('D7').border = borderStyle;
    worksheet.getCell('D7').alignment = { horizontal: 'center', vertical: 'middle' };

    worksheet.getCell('E7').value = numero || '00000';
    worksheet.getCell('E7').border = borderStyle;
    worksheet.getCell('E7').alignment = { horizontal: 'center', vertical: 'middle' };

    worksheet.getCell('A8').value = 'RUC:';
    worksheet.getCell('A8').font = { bold: true, size: 10 };
    worksheet.getCell('B8').value = empresa || '';

    worksheet.getCell('D8').value = 'FECHA';
    worksheet.getCell('D8').font = { bold: true, size: 9 };
    worksheet.getCell('D8').fill = {
      type: 'pattern',
      pattern: 'solid',
      fgColor: { argb: 'FFE5E7EB' },
    };
    worksheet.getCell('D8').border = borderStyle;
    worksheet.getCell('D8').alignment = { horizontal: 'center', vertical: 'middle' };

    worksheet.getCell('E8').value = fechaFormateada;
    worksheet.getCell('E8').border = borderStyle;
    worksheet.getCell('E8').alignment = { horizontal: 'center', vertical: 'middle' };

    worksheet.getCell('A9').value = 'DIRECCIÓN:';
    worksheet.getCell('A9').font = { bold: true, size: 10 };
    worksheet.getCell('B9').value = direccion || '';

    worksheet.getCell('A10').value = 'Presente. -';

    worksheet.mergeCells('A12:E12');
    worksheet.getCell('A12').value = 'Atte.: Área Logistica.';
    worksheet.getCell('A12').font = { bold: true, size: 10 };
    worksheet.getCell('A12').alignment = { horizontal: 'center' };

    worksheet.mergeCells('A13:E13');
    worksheet.getCell('A13').value = 'Asesora de venta: Judith Mirtha';
    worksheet.getCell('A13').font = { bold: true, size: 10 };
    worksheet.getCell('A13').alignment = { horizontal: 'center' };

    worksheet.mergeCells('A14:E14');
    worksheet.getCell('A14').value = 'cel. 924347528';
    worksheet.getCell('A14').font = { bold: true, size: 10 };
    worksheet.getCell('A14').alignment = { horizontal: 'center' };

    worksheet.mergeCells('A16:E16');
    worksheet.getCell('A16').value =
      'Por medio de la presente me dirijo a ustedes a fin de saludarles cordialmente';
    worksheet.getCell('A16').font = { size: 10 };
    worksheet.getCell('A16').alignment = { horizontal: 'center' };

    const headerRowIndex = 18;
    worksheet.getRow(headerRowIndex).values = [
      'ITEM',
      'EQUIP. PROTEC. PERS.',
      'CANT',
      'PRECIO',
      'TOTAL',
    ];
    ['A', 'B', 'C', 'D', 'E'].forEach((col) => {
      const cell = worksheet.getCell(`${col}${headerRowIndex}`);
      cell.font = { bold: true, size: 10 };
      cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFFFC000' } };
      cell.alignment = { horizontal: 'center', vertical: 'middle' };
      cell.border = borderStyle;
    });

    let currentRow = 19;
    const startRow = 19;

    cotizacion.forEach((item: DocumentItem, index: number) => {
      const cantidad = item.cantidad || 0;
      const precioFinal = Number(item.precio) || 0;
      const unitBase = aplicarIgv ? Number((precioFinal / 1.18).toFixed(2)) : precioFinal;
      const rowTotalBase = Number((unitBase * cantidad).toFixed(2));

      const row = worksheet.getRow(currentRow);
      row.getCell('A').value = index + 1;
      row.getCell('B').value = item.nombre;
      row.getCell('C').value = cantidad;
      row.getCell('D').value = unitBase;

      row.getCell('E').value = {
        formula: `ROUND(C${currentRow}*D${currentRow}, 2)`,
        result: rowTotalBase,
      };

      ['A', 'B', 'C', 'D', 'E'].forEach((col) => {
        const cell = worksheet.getCell(`${col}${currentRow}`);
        cell.border = borderStyle;
        cell.font = { size: 10 };
        if (col !== 'B') cell.alignment = { horizontal: 'center' };
      });
      worksheet.getCell(`D${currentRow}`).numFmt = '0.00';
      worksheet.getCell(`E${currentRow}`).numFmt = '0.00';
      currentRow++;
    });

    const endRow = currentRow - 1;

    const createTotalRow = (label: string, value: number, formula?: string) => {
      worksheet.mergeCells(`A${currentRow}:D${currentRow}`);
      const labelCell = worksheet.getCell(`A${currentRow}`);
      labelCell.value = label;
      labelCell.font = { bold: true };
      labelCell.alignment = { horizontal: 'right', vertical: 'middle' };

      ['A', 'B', 'C', 'D'].forEach((col) => {
        const cell = worksheet.getCell(`${col}${currentRow}`);
        cell.border = { top: { style: 'thin' }, bottom: { style: 'thin' } };
        if (col === 'A') cell.border.left = { style: 'thin' };
        if (col === 'D') cell.border.right = { style: 'thin' };
      });

      const valCell = worksheet.getCell(`E${currentRow}`);
      if (formula) {
        valCell.value = { formula: formula, result: Number(value.toFixed(2)) };
      } else {
        valCell.value = Number(value.toFixed(2));
      }
      valCell.font = { bold: true };
      valCell.border = borderStyle;
      valCell.numFmt = '0.00';
      valCell.alignment = { horizontal: 'center' };
      currentRow++;
    };

    if (aplicarIgv) {
      const sumTotalFormula = `ROUND(SUM(E${startRow}:E${endRow}), 2)`;
      createTotalRow('SUB TOTAL', subtotal, sumTotalFormula);
      createTotalRow('IGV', igv);
      createTotalRow('TOTAL', total);
    } else {
      createTotalRow('TOTAL', total, `ROUND(SUM(E${startRow}:E${endRow}), 2)`);
    }

    currentRow += 2;
    worksheet.mergeCells(`A${currentRow}:E${currentRow}`);
    worksheet.getCell(`A${currentRow}`).value =
      'Agradeciendo la confianza depositada en nuestra Empresa,';
    worksheet.getCell(`A${currentRow}`).font = { size: 10 };
    worksheet.getCell(`A${currentRow}`).alignment = { horizontal: 'center' };

    currentRow += 1;
    worksheet.mergeCells(`A${currentRow}:E${currentRow}`);
    worksheet.getCell(`A${currentRow}`).value = 'ATENTAMENTE,';
    worksheet.getCell(`A${currentRow}`).font = { bold: true, size: 10 };
    worksheet.getCell(`A${currentRow}`).alignment = { horizontal: 'center' };

    currentRow += 1;
    worksheet.mergeCells(`A${currentRow}:E${currentRow}`);
    worksheet.getCell(`A${currentRow}`).value = 'JUFLEX';
    worksheet.getCell(`A${currentRow}`).font = { size: 10 };
    worksheet.getCell(`A${currentRow}`).alignment = { horizontal: 'center' };

    currentRow += 1;
    worksheet.mergeCells(`A${currentRow}:E${currentRow}`);
    worksheet.getCell(`A${currentRow}`).value = 'RUC: 10485976260';
    worksheet.getCell(`A${currentRow}`).font = { size: 10 };
    worksheet.getCell(`A${currentRow}`).alignment = { horizontal: 'center' };

    currentRow += 1;
    worksheet.mergeCells(`A${currentRow}:E${currentRow}`);
    worksheet.getCell(`A${currentRow}`).value = 'AV. JOSE GALVEZ 134, La Victoria.';
    worksheet.getCell(`A${currentRow}`).font = { size: 10 };
    worksheet.getCell(`A${currentRow}`).alignment = { horizontal: 'center' };
  }

  // ==========================================
  // PLANTILLA 3: PREMIUM / BETMIN (PRECISIÓN EXACTA)
  // ==========================================
  else if (plantilla === 'premium') {
    worksheet.columns = [
      { width: 6 }, // A: ITEM
      { width: 45 }, // B: EPPS (Descripción)
      { width: 10 }, // C: CANT
      { width: 15 }, // D: PRECIO
      { width: 15 }, // E: TOTAL
    ];

    worksheet.mergeCells('A1:E4');
    for (let i = 1; i <= 4; i++) {
      worksheet.getRow(i).height = 30;
    }

    try {
      const response = await fetch('/quote-assets/betminexcel.png');
      const imageBuffer = await response.arrayBuffer();
      const logoId = workbook.addImage({
        buffer: imageBuffer as unknown as ExcelJS.Buffer,
        extension: 'png',
      });
      worksheet.addImage(logoId, { tl: { col: 1.5, row: 0.2 }, ext: { width: 385, height: 150 } });
    } catch {
      worksheet.getCell('A1').value = 'BETMIN';
      worksheet.getCell('A1').font = { size: 24, bold: true, color: { argb: 'FF1E3A8A' } };
      worksheet.getCell('A1').alignment = { horizontal: 'center', vertical: 'middle' };
    }

    worksheet.mergeCells('A5:E5');
    worksheet.getCell('A5').value = 'PROPUESTA COMERCIAL';
    worksheet.getCell('A5').font = { bold: true, size: 14, color: { argb: 'FF1E3A8A' } };
    worksheet.getCell('A5').alignment = { horizontal: 'center' };

    worksheet.mergeCells('A6:E6');
    worksheet.getCell('A6').value = 'VENTAS CORPORATIVAS';
    worksheet.getCell('A6').font = { bold: true, size: 10, color: { argb: 'FF64748B' } };
    worksheet.getCell('A6').alignment = { horizontal: 'center' };

    worksheet.mergeCells('A7:E7');
    worksheet.getCell('A7').value = 'RUC: 10471945078';
    worksheet.getCell('A7').font = { size: 10, color: { argb: 'FF64748B' } };
    worksheet.getCell('A7').alignment = { horizontal: 'center' };

    worksheet.getCell('A9').value = 'SEÑORES:';
    worksheet.getCell('A9').font = { bold: true, size: 10, color: { argb: 'FF1E3A8A' } };
    worksheet.getCell('B9').value = cliente || '';

    worksheet.getCell('D9').value = titulo === 'PEDIDO' ? 'PEDIDO' : 'N° COTIZ';
    worksheet.getCell('D9').font = { bold: true, size: 9, color: { argb: 'FF1E3A8A' } };
    worksheet.getCell('D9').fill = {
      type: 'pattern',
      pattern: 'solid',
      fgColor: { argb: 'FFF8FAFC' },
    };
    worksheet.getCell('D9').border = borderStyle;
    worksheet.getCell('D9').alignment = { horizontal: 'center', vertical: 'middle' };

    worksheet.getCell('E9').value = numero || '00000';
    worksheet.getCell('E9').border = borderStyle;
    worksheet.getCell('E9').alignment = { horizontal: 'center', vertical: 'middle' };

    worksheet.getCell('A10').value = 'RUC:';
    worksheet.getCell('A10').font = { bold: true, size: 10, color: { argb: 'FF1E3A8A' } };
    worksheet.getCell('B10').value = empresa || '';

    worksheet.getCell('D10').value = 'FECHA';
    worksheet.getCell('D10').font = { bold: true, size: 9, color: { argb: 'FF1E3A8A' } };
    worksheet.getCell('D10').fill = {
      type: 'pattern',
      pattern: 'solid',
      fgColor: { argb: 'FFF8FAFC' },
    };
    worksheet.getCell('D10').border = borderStyle;
    worksheet.getCell('D10').alignment = { horizontal: 'center', vertical: 'middle' };

    worksheet.getCell('E10').value = fechaFormateada;
    worksheet.getCell('E10').border = borderStyle;
    worksheet.getCell('E10').alignment = { horizontal: 'center', vertical: 'middle' };

    worksheet.getCell('A11').value = 'DIRECCIÓN:';
    worksheet.getCell('A11').font = { bold: true, size: 10, color: { argb: 'FF1E3A8A' } };
    worksheet.getCell('B11').value = direccion || '';

    worksheet.mergeCells('A13:E14');
    worksheet.getCell('A13').value =
      'De nuestra mayor consideración:\nPor medio de la presente, nos es grato dirigirnos a ustedes con el fin de saludarles cordialmente y hacerles llegar nuestra propuesta comercial de acuerdo a sus requerimientos. A continuación, detallamos los productos:';
    worksheet.getCell('A13').font = { size: 9, color: { argb: 'FF475569' } };
    worksheet.getCell('A13').alignment = { wrapText: true, vertical: 'top' };
    worksheet.getRow(13).height = 35;
    worksheet.getRow(14).height = 35;

    const headerRowIndex = 16;
    worksheet.getRow(headerRowIndex).values = ['ITEM', 'EPPS', 'CANT', 'PRECIO', 'TOTAL'];
    ['A', 'B', 'C', 'D', 'E'].forEach((col) => {
      const cell = worksheet.getCell(`${col}${headerRowIndex}`);
      cell.font = { bold: true, size: 10 };
      cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF95B3D7' } };
      cell.alignment = { horizontal: 'center', vertical: 'middle' };
      cell.border = borderStyle;
    });

    let currentRow = 17;
    const startRow = 17;

    cotizacion.forEach((item: DocumentItem, index: number) => {
      const cantidad = item.cantidad || 0;
      const precioFinal = Number(item.precio) || 0;
      const unitBase = aplicarIgv ? Number((precioFinal / 1.18).toFixed(2)) : precioFinal;
      const rowTotalBase = Number((unitBase * cantidad).toFixed(2));

      const row = worksheet.getRow(currentRow);
      row.getCell('A').value = index + 1;
      row.getCell('B').value = item.nombre;
      row.getCell('C').value = cantidad;
      row.getCell('D').value = unitBase;

      row.getCell('E').value = {
        formula: `ROUND(C${currentRow}*D${currentRow}, 2)`,
        result: rowTotalBase,
      };

      ['A', 'B', 'C', 'D', 'E'].forEach((col) => {
        const cell = worksheet.getCell(`${col}${currentRow}`);
        cell.border = borderStyle;
        cell.font = { size: 10 };
        if (col !== 'B') cell.alignment = { horizontal: 'center' };
      });
      worksheet.getCell(`D${currentRow}`).numFmt = '0.00';
      worksheet.getCell(`E${currentRow}`).numFmt = '0.00';
      currentRow++;
    });

    const endRow = currentRow - 1;

    const createTotalRow = (label: string, value: number, formula?: string) => {
      worksheet.mergeCells(`A${currentRow}:D${currentRow}`);
      const labelCell = worksheet.getCell(`A${currentRow}`);
      labelCell.value = label;
      labelCell.font = { bold: true };
      labelCell.alignment = { horizontal: 'right', vertical: 'middle' };

      ['A', 'B', 'C', 'D'].forEach((col) => {
        const cell = worksheet.getCell(`${col}${currentRow}`);
        cell.border = { top: { style: 'thin' }, bottom: { style: 'thin' } };
        if (col === 'A') cell.border.left = { style: 'thin' };
        if (col === 'D') cell.border.right = { style: 'thin' };
      });

      const valCell = worksheet.getCell(`E${currentRow}`);
      if (formula) {
        valCell.value = { formula: formula, result: Number(value.toFixed(2)) };
      } else {
        valCell.value = Number(value.toFixed(2));
      }
      valCell.font = { bold: true };
      valCell.border = borderStyle;
      valCell.numFmt = '0.00';
      valCell.alignment = { horizontal: 'center' };
      currentRow++;
    };

    if (aplicarIgv) {
      const sumTotalFormula = `ROUND(SUM(E${startRow}:E${endRow}), 2)`;
      createTotalRow('SUB TOTAL', subtotal, sumTotalFormula);
      createTotalRow('IGV', igv);
      createTotalRow('TOTAL', total);
    } else {
      createTotalRow('TOTAL', total, `ROUND(SUM(E${startRow}:E${endRow}), 2)`);
    }

    currentRow += 2;
    worksheet.mergeCells(`A${currentRow}:E${currentRow}`);
    worksheet.getCell(`A${currentRow}`).value =
      'Esperando que nuestra propuesta sea de su total agrado y satisfaga sus expectativas, quedamos a su entera disposición para cualquier consulta o aclaración adicional que requieran.\nAtentamente, el equipo de ventas.';
    worksheet.getCell(`A${currentRow}`).font = { size: 9, color: { argb: 'FF475569' } };
    worksheet.getCell(`A${currentRow}`).alignment = { wrapText: true, vertical: 'top' };
    worksheet.getRow(currentRow).height = 40;

    currentRow += 2;
    worksheet.mergeCells(`A${currentRow}:E${currentRow}`);
    worksheet.getCell(`A${currentRow}`).value = 'INFORMACIÓN BANCARIA Y CONDICIONES';
    worksheet.getCell(`A${currentRow}`).font = {
      bold: true,
      size: 10,
      color: { argb: 'FF1E3A8A' },
    };

    currentRow += 1;
    worksheet.mergeCells(`A${currentRow}:E${currentRow}`);
    worksheet.getCell(`A${currentRow}`).value =
      '• BCP SOLES: 191-12345678-0-00 (CCI: 002191123456780000)';
    worksheet.getCell(`A${currentRow}`).font = { size: 9 };

    currentRow += 1;
    worksheet.mergeCells(`A${currentRow}:E${currentRow}`);
    worksheet.getCell(`A${currentRow}`).value = '• BBVA SOLES: 0011-0123-0100123456';
    worksheet.getCell(`A${currentRow}`).font = { size: 9 };
  }

  // --- DESCARGA DEL ARCHIVO ---
  const buffer = await workbook.xlsx.writeBuffer();
  const blob = new Blob([new Uint8Array(buffer)], {
    type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  });
  const url = window.URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;

  const fechaSegura = fechaFormateada ? fechaFormateada.replace(/\//g, '-') : 'Venta';
  anchor.download = `${titulo}_${plantilla.toUpperCase()}_${(cliente || fechaSegura).replace(/[^\p{L}\p{N} -]/gu, '').slice(0, 60)}.xlsx`;

  anchor.click();
  window.URL.revokeObjectURL(url);
};
