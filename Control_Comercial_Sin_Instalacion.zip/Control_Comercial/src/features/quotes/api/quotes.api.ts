import { z } from 'zod';
import { supabase } from '@/shared/supabase/client';
import { throwSupabaseError } from '@/shared/supabase/errors';
import { quoteInputSchema, quoteSchema } from '../model';
import type { Quote, QuoteInput } from '../model';
function fail(error: Parameters<typeof throwSupabaseError>[0]) {
  if ('code' in error && ['42P01', 'PGRST205', 'PGRST202'].includes(String(error.code)))
    throw new Error(
      'Ejecuta supabase/quotations.sql en Supabase → SQL Editor para habilitar cotizaciones.',
    );
  throwSupabaseError(error);
}
function map(row: Record<string, unknown>): Quote {
  return quoteSchema.parse({
    ...row,
    number: Number(row.number),
    date: row.quote_date,
    taxIncluded: row.tax_included,
    totalCents: Number(row.total_cents),
    subtotalCents: Number(row.subtotal_cents),
    taxCents: Number(row.tax_cents),
    saleId: row.sale_id,
    createdAt: row.created_at,
  });
}
export const quotesApi = {
  async forSale(saleId: string, signal: AbortSignal) {
    const { data, error } = await supabase
      .from('quotations')
      .select('*')
      .eq('sale_id', saleId)
      .abortSignal(signal)
      .maybeSingle();
    if (error) fail(error);
    return data ? map(data) : null;
  },
  async list(search: string, brand: string, page: number, signal: AbortSignal) {
    let query = supabase
      .from('quotations')
      .select('*', { count: 'exact' })
      .is('archived_at', null)
      .order('created_at', { ascending: false })
      .order('id')
      .range((page - 1) * 20, page * 20 - 1)
      .abortSignal(signal);
    if (brand) query = query.eq('brand', brand);
    const term = search
      .trim()
      .slice(0, 100)
      .replace(/[\\%_,().]/g, '\\$&');
    if (term) query = query.ilike('customer', `%${term}%`);
    const { data, error, count } = await query;
    if (error) fail(error);
    return { items: (data ?? []).map(map), total: count ?? 0, page, pageSize: 20 };
  },
  async save(input: QuoteInput, current: Quote | null, key: string) {
    const { data, error } = await supabase.rpc('save_quotation', {
      p_id: current?.id ?? null,
      p_input: quoteInputSchema.parse(input),
      p_version: current?.version ?? 0,
      p_key: key,
    });
    if (error) fail(error);
    return map(data);
  },
  async convert(quote: Quote, payment: string, delivery: string) {
    const { data, error } = await supabase.rpc('convert_quotation', {
      p_id: quote.id,
      p_version: quote.version,
      p_payment: payment,
      p_delivery: delivery || null,
    });
    if (error) fail(error);
    return z.string().uuid().parse(data);
  },
  async archive(id: string) {
    const { error } = await supabase.rpc('archive_quotation', { p_id: id });
    if (error) fail(error);
  },
};
