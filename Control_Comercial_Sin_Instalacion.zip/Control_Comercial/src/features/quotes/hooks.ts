import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { useTenantId } from '@/features/auth/hooks/useSession';
import { quotesApi } from './api/quotes.api';
import type { Quote, QuoteInput } from './model';
export function useQuotes(search: string, brand: string, page: number) {
  const tenant = useTenantId();
  return useQuery({
    queryKey: [tenant, 'quotes', search, brand, page],
    queryFn: ({ signal }) => quotesApi.list(search, brand, page, signal),
  });
}
export function useQuoteActions() {
  const tenant = useTenantId();
  const client = useQueryClient();
  const refresh = () => client.invalidateQueries({ queryKey: [tenant] });
  const save = useMutation({
    mutationFn: ({
      input,
      current,
      key,
    }: {
      input: QuoteInput;
      current: Quote | null;
      key: string;
    }) => quotesApi.save(input, current, key),
    onSuccess: refresh,
  });
  const convert = useMutation({
    mutationFn: ({
      quote,
      payment,
      delivery,
    }: {
      quote: Quote;
      payment: string;
      delivery: string;
    }) => quotesApi.convert(quote, payment, delivery),
    onSuccess: refresh,
  });
  const archive = useMutation({ mutationFn: quotesApi.archive, onSuccess: refresh });
  return { save, convert, archive };
}

export function useQuoteForSale(saleId: string | null) {
  const tenant = useTenantId();
  return useQuery({
    queryKey: [tenant, 'quote-for-sale', saleId],
    enabled: !!saleId,
    queryFn: ({ signal }) => quotesApi.forSale(saleId!, signal),
  });
}
