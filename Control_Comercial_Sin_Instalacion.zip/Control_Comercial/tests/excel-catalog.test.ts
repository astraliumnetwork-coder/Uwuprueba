import { readFile } from 'node:fs/promises';
import { resolve } from 'node:path';
import { describe, expect, it } from 'vitest';
import { productInput } from '@saas/domain';
import { excelCatalog } from '../src/features/products/data/excel-catalog';

describe('Excel source reconciliation', () => {
  it('prepares distinct, valid product references without inferred stock', () => {
    expect(excelCatalog).toHaveLength(337);
    expect(new Set(excelCatalog.map((p) => p.sku)).size).toBe(excelCatalog.length);
    for (const product of excelCatalog) {
      expect(productInput.safeParse({ ...product, retailStock: 0, ordersStock: 0 }).success).toBe(
        true,
      );
    }
  });
  it('separates sale rows, closing values and the row 590 discrepancy', async () => {
    const audit = JSON.parse(
      await readFile(resolve(process.cwd(), 'docs/excel/auditoria.json'), 'utf8'),
    );
    expect(audit).toMatchObject({
      records: 630,
      namedRecords: 624,
      originalSalesCents: 3225950,
      originalCostCents: 2426740,
      originalGrossCents: 799210,
      costTotalCents: 2426340,
      grossCents: 799610,
      unknownDate: 44,
      unknownPayment: 622,
    });
    expect(audit.issues.find((r: { row: number }) => r.row === 590)).toMatchObject({
      costTotalCents: 2200,
      originalCostCents: 2600,
    });
  });
});
