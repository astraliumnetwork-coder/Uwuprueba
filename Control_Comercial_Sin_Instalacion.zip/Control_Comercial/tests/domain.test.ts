// @vitest-environment node
import { describe, expect, it } from 'vitest';
import {
  bootSizeOptions,
  bootSizes,
  calculateLine,
  dateSchema,
  formatProductNameWithSize,
  getSizeOptionsForCategory,
  getSubcategoriesForCategory,
  inferProductCategory,
  inferProductCategoryAndSubcategory,
  isFootwearCategory,
  localDate,
  normalizeProductColor,
  normalizeProductSize,
  parseMoney,
  productCategories,
  productCategoryGroups,
  productColors,
  productInput,
  productSizeOptions,
  productSizes,
  saleInput,
  sessionSchema,
  splitProductMetadata,
  splitProductNameAndSize,
} from '@saas/domain';

describe('reglas financieras', () => {
  it('evita errores binarios al convertir precios y multiplicar', () => {
    expect(parseMoney('0.10')).toBe(10);
    expect(calculateLine(3, parseMoney('0.10'), parseMoney('0.03'))).toEqual({
      salesCents: 30,
      costTotalCents: 9,
      grossCents: 21,
    });
  });
  it('permite pérdida y costo cero, rechaza fracciones de centavo y cantidades fraccionarias', () => {
    expect(calculateLine(2, 10, 20).grossCents).toBe(-20);
    expect(calculateLine(1, 10, 0).grossCents).toBe(10);
    expect(() => parseMoney('1.001')).toThrow();
    expect(() => parseMoney('1e3')).toThrow();
    expect(() => calculateLine(0.5, 10, 5)).toThrow();
  });
  it('respeta la medianoche de Lima y valida días reales', () => {
    expect(localDate(new Date('2026-10-21T04:59:59Z'))).toBe('2026-10-20');
    expect(localDate(new Date('2026-10-21T05:00:00Z'))).toBe('2026-10-21');
    expect(dateSchema.safeParse('2026-02-30').success).toBe(false);
  });
  it('rechaza un mismo producto repetido en el documento', () => {
    const item = {
      productId: 'c34a7896-9db6-458c-8bc6-2cd7ba71509d',
      quantity: 1,
      priceCents: 100,
      costCents: 50,
    };
    expect(
      saleInput.safeParse({ channel: 'retail', payment: 'cash', items: [item, item] }).success,
    ).toBe(false);
  });
  it('acepta la identidad temporal sin correo electrónico', () => {
    expect(
      sessionSchema.parse({
        userId: 'c34a7896-9db6-458c-8bc6-2cd7ba71509d',
        tenantId: 'c34a7896-9db6-458c-8bc6-2cd7ba71509d',
        email: 'Acceso temporal',
        organizationName: 'Control Comercial',
      }).email,
    ).toBe('Acceso temporal');
  });
  it('define opciones de talla con siglas a partir de S (Small) y permite tallas personalizadas o vacías', () => {
    expect(productSizes[0]).toBe('S');
    expect(productSizes).toEqual(['S', 'M', 'L', 'XL', 'XXL', 'XXXL']);
    expect(productSizeOptions[0]).toEqual({ value: 'S', label: 'S (Small)' });
    const withPreset = productInput.parse({
      sku: 'AUTO',
      name: 'Mameluco',
      size: 'Small',
      priceCents: 2500,
      costCents: 1800,
      retailStock: 5,
      ordersStock: 2,
    });
    expect(withPreset.size).toBe('S');
    const formatted = formatProductNameWithSize(withPreset.name, withPreset.size);
    expect(formatted).toBe('Mameluco · Talla: S');
    expect(splitProductNameAndSize(formatted)).toEqual({ name: 'Mameluco', size: 'S' });
  });
  it('soporta las 11 categorías oficiales con sus subcategorías, colores múltiples y tallas numéricas de calzado (35 a 46)', () => {
    expect(productCategories).toEqual([
      'Protección de cabeza',
      'Protección de manos',
      'Calzado industrial',
      'Protección en altura',
      'Protección visual',
      'Protección Facial',
      'Protección auditiva',
      'Señalización',
      'Protección Solar',
      'Protección Respiratoria',
      'Ropa de Trabajo',
    ]);
    expect(productCategoryGroups).toHaveLength(11);
    expect(getSubcategoriesForCategory('Calzado industrial')).toEqual([
      'Botines de seguridad',
      'Botines dieléctricos',
      'Botas de PVC',
      'Botas de jebe',
      'Calzado para dama',
    ]);
    expect(getSubcategoriesForCategory('Ropa de Trabajo')).toEqual(['Abrigos', 'Corta vientos']);
    expect(isFootwearCategory('Calzado industrial')).toBe(true);
    expect(isFootwearCategory('Calzado')).toBe(true);
    expect(bootSizes).toEqual([
      '35',
      '36',
      '37',
      '38',
      '39',
      '40',
      '41',
      '42',
      '43',
      '44',
      '45',
      '46',
    ]);
    expect(getSizeOptionsForCategory('Calzado industrial')).toEqual(bootSizeOptions);

    expect(productColors).toContain('Verde Fosforescente');
    expect(productColors).toContain('Plomo');
    expect(normalizeProductColor('Amarillo, Azul, Naranja')).toBe('Amarillo, Azul, Naranja');
    expect(normalizeProductSize('38, 39, 40')).toBe('38, 39, 40');

    const shoeProduct = productInput.parse({
      sku: 'AUTO',
      category: 'Calzado industrial',
      subcategory: 'Botines dieléctricos',
      color: 'Negro, Amarillo',
      name: 'Botín punta composite',
      size: '39, 40, 42',
      priceCents: 11500,
      costCents: 8000,
      retailStock: 10,
      ordersStock: 4,
    });
    expect(shoeProduct.category).toBe('Calzado industrial');
    expect(shoeProduct.subcategory).toBe('Botines dieléctricos');
    expect(shoeProduct.color).toBe('Negro, Amarillo');
    expect(shoeProduct.size).toBe('39, 40, 42');
    const formatted = formatProductNameWithSize(
      shoeProduct.name,
      shoeProduct.size,
      shoeProduct.category,
      shoeProduct.color,
      shoeProduct.subcategory,
    );
    expect(formatted).toBe(
      'Botín punta composite · Cat: Calzado industrial · Sub: Botines dieléctricos · Color: Negro, Amarillo · Talla: 39, 40, 42',
    );
    expect(splitProductMetadata(formatted)).toEqual({
      name: 'Botín punta composite',
      category: 'Calzado industrial',
      subcategory: 'Botines dieléctricos',
      color: 'Negro, Amarillo',
      size: '39, 40, 42',
    });
    expect(inferProductCategory('botas jebe')).toBe('Calzado industrial');
    expect(inferProductCategoryAndSubcategory('botas jebe')).toEqual({
      category: 'Calzado industrial',
      subcategory: 'Botas de jebe',
    });
  });
});
