import { readFile } from 'node:fs/promises';
import { resolve } from 'node:path';
import { localDate } from '@saas/domain';
import { PGlite } from '@electric-sql/pglite';
import { afterEach, beforeEach, describe, expect, it } from 'vitest';

const firstUser = '00000000-0000-4000-8000-000000000001';
const secondUser = '00000000-0000-4000-8000-000000000002';
const anonymousUser = '00000000-0000-4000-8000-000000000003';
const firstKey = '10000000-0000-4000-8000-000000000001';
const saleKey = '10000000-0000-4000-8000-000000000002';
const orderKey = '10000000-0000-4000-8000-000000000003';
const expenseKey = '10000000-0000-4000-8000-000000000004';
const sql = await readFile(resolve(process.cwd(), 'supabase/schema.sql'), 'utf8');

describe('Supabase schema and transactional operations', () => {
  let db: PGlite;

  beforeEach(async () => {
    db = new PGlite();
    await db.exec(`
      create role anon;
      create role authenticated;
      create schema auth;
      create table auth.users (id uuid primary key, email text, raw_user_meta_data jsonb not null default '{}'::jsonb);
      create function auth.uid() returns uuid language sql stable as
        $$ select nullif(current_setting('request.jwt.claim.sub', true), '')::uuid $$;
    `);
    await db.exec(sql);
    await db.query(
      `insert into auth.users(id,email,raw_user_meta_data) values
        ($1,'one@example.com','{"organization_name":"Empresa Uno"}'),
        ($2,'two@example.com','{"organization_name":"Empresa Dos"}')`,
      [firstUser, secondUser],
    );
    await asUser(firstUser);
  });

  afterEach(async () => db.close());

  async function asUser(userId: string) {
    await db.exec('reset role');
    await db.query("select set_config('request.jwt.claim.sub', $1, false)", [userId]);
    await db.exec('set role authenticated');
  }

  async function createProduct() {
    const result = await db.query<{ id: string }>(`select public.create_product($1::jsonb) as id`, [
      JSON.stringify({
        sku: 'EPP-01',
        name: 'Guantes',
        priceCents: 1000,
        costCents: 600,
        retailStock: 10,
        ordersStock: 10,
      }),
    ]);
    return result.rows[0]!.id;
  }

  it('orders stock before pagination and isolates the catalogue by tenant', async () => {
    const productId = await createProduct();
    await db.query('select public.create_product($1::jsonb)', [
      JSON.stringify({
        sku: 'AUTO',
        name: 'Sin stock',
        priceCents: 100,
        costCents: 50,
        retailStock: 0,
        ordersStock: 0,
      }),
    ]);
    const rows = await db.query<{ id: string }>(
      'select id from public.product_catalog order by retail_stock desc, id limit 1',
    );
    expect(rows.rows[0]?.id).toBe(productId);
    await asUser(secondUser);
    expect((await db.query('select * from public.product_catalog')).rows).toHaveLength(0);
    await expect(db.query('select public.delete_product($1)', [productId])).rejects.toThrow(
      'Producto no encontrado',
    );
  });

  it('removes a product even when it has stock while preserving historical sales and preventing reuse', async () => {
    const productId = await createProduct();
    await db.query('select public.create_sale($1::jsonb,$2)', [
      JSON.stringify({
        channel: 'retail',
        payment: 'cash',
        customer: '',
        scheduledFor: null,
        items: [{ productId, quantity: 4, priceCents: 1000, costCents: 600 }],
      }),
      saleKey,
    ]);
    await db.query('select public.delete_product($1)', [productId]);
    await db.query('select public.delete_product($1)', [productId]);
    expect((await db.query('select * from public.product_catalog')).rows).toHaveLength(0);
    expect(
      (await db.query('select * from public.sale_items where product_id=$1', [productId])).rows,
    ).toHaveLength(1);
    await expect(
      db.query('select public.adjust_stock($1,$2,$3,$4,$5)', [
        productId,
        'retail',
        1,
        'Intento nuevo',
        expenseKey,
      ]),
    ).rejects.toThrow('retirado');
    await expect(
      db.query('select public.update_product($1,$2::jsonb)', [
        productId,
        JSON.stringify({
          sku: 'EPP-01',
          name: 'Reactivar',
          priceCents: 1000,
          costCents: 600,
          active: true,
        }),
      ]),
    ).rejects.toThrow('retirado');
  });

  it('blocks deletion of a product referenced by a pending order', async () => {
    const result = await db.query<{ id: string }>('select public.create_product($1::jsonb) as id', [
      JSON.stringify({
        sku: 'AUTO',
        name: 'Pendiente',
        priceCents: 100,
        costCents: 50,
        retailStock: 0,
        ordersStock: 0,
      }),
    ]);
    const productId = result.rows[0]!.id;
    await db.query('select public.create_sale($1::jsonb,$2)', [
      JSON.stringify({
        channel: 'orders',
        payment: 'cash',
        customer: 'Cliente pendiente',
        scheduledFor: null,
        items: [{ productId, quantity: 1, priceCents: 100, costCents: 50 }],
      }),
      orderKey,
    ]);
    await expect(db.query('select public.delete_product($1)', [productId])).rejects.toThrow(
      'pedidos pendientes',
    );
  });

  it('isolates quotations, duplicates without replacing, converts once and keeps stock until delivery', async () => {
    const productId = await createProduct();
    const input = {
      brand: 'reypro',
      customer: 'Cliente cotizado',
      ruc: '20123456789',
      address: 'Lima',
      date: '2026-10-29',
      taxIncluded: true,
      items: [
        {
          id: firstKey,
          productId,
          name: 'Guantes cotizados',
          quantity: 2,
          priceCents: 1180,
          costCents: 600,
        },
      ],
    };
    type Saved = {
      id: string;
      version: number;
      number: number;
      total_cents: number;
      subtotal_cents: number;
    };
    const saved = (
      await db.query<{ q: Saved }>('select public.save_quotation(null,$1::jsonb,0,$2) as q', [
        JSON.stringify(input),
        firstKey,
      ])
    ).rows[0]!.q;
    const retry = (
      await db.query<{ q: Saved }>('select public.save_quotation(null,$1::jsonb,0,$2) as q', [
        JSON.stringify(input),
        firstKey,
      ])
    ).rows[0]!.q;
    expect(retry.id).toBe(saved.id);
    expect(saved.total_cents).toBe(2360);
    expect(saved.subtotal_cents).toBe(2000);
    const duplicate = (
      await db.query<{ q: Saved }>('select public.save_quotation(null,$1::jsonb,0,$2) as q', [
        JSON.stringify({ ...input, brand: 'premium' }),
        saleKey,
      ])
    ).rows[0]!.q;
    expect(duplicate.id).not.toBe(saved.id);
    expect(duplicate.number).toBe(1);
    await asUser(secondUser);
    expect((await db.query('select * from public.quotations')).rows).toHaveLength(0);
    await expect(
      db.query("select public.convert_quotation($1,1,'cash',null)", [saved.id]),
    ).rejects.toThrow('Cotización no encontrada');
    await asUser(firstUser);
    await expect(
      db.query('select public.save_quotation($1,$2::jsonb,99,$3)', [
        saved.id,
        JSON.stringify(input),
        expenseKey,
      ]),
    ).rejects.toThrow('Otra sesión');
    const sale = (
      await db.query<{ id: string }>(
        "select public.convert_quotation($1,1,'yape','2026-11-01') as id",
        [saved.id],
      )
    ).rows[0]!.id;
    expect(
      (
        await db.query<{ id: string }>(
          "select public.convert_quotation($1,1,'yape','2026-11-01') as id",
          [saved.id],
        )
      ).rows[0]?.id,
    ).toBe(sale);
    const stock = (
      await db.query<{ quantity: number }>(
        "select quantity from public.inventory where product_id=$1 and channel='orders'",
        [productId],
      )
    ).rows[0]!.quantity;
    expect(stock).toBe(10);
    expect(
      (
        await db.query<{ product_name: string }>(
          'select product_name from public.sale_items where sale_id=$1',
          [sale],
        )
      ).rows[0]?.product_name,
    ).toBe('Guantes cotizados');
    await expect(
      db.query('select public.save_quotation($1,$2::jsonb,1,$3)', [
        saved.id,
        JSON.stringify(input),
        orderKey,
      ]),
    ).rejects.toThrow('ya generó');
    await db.query('select public.complete_order($1)', [sale]);
    expect(
      (
        await db.query<{ quantity: number }>(
          "select quantity from public.inventory where product_id=$1 and channel='orders'",
          [productId],
        )
      ).rows[0]?.quantity,
    ).toBe(8);
  });
  it('creates manual quote items once with zero stock and rejects cross-tenant product references', async () => {
    const id = await createProduct();
    const input = {
      brand: 'juflex',
      customer: 'Manual',
      ruc: '',
      address: '',
      date: '2026-10-29',
      taxIncluded: false,
      items: [
        {
          id: firstKey,
          productId: null,
          name: 'Servicio especial',
          quantity: 1,
          priceCents: 500,
          costCents: 100,
        },
      ],
    };
    const q = (
      await db.query<{ q: { id: string } }>(
        'select public.save_quotation(null,$1::jsonb,0,$2) as q',
        [JSON.stringify(input), firstKey],
      )
    ).rows[0]!.q;
    await db.query("select public.convert_quotation($1,1,'cash',null)", [q.id]);
    await db.query("select public.convert_quotation($1,1,'cash',null)", [q.id]);
    const manual = await db.query<{ id: string }>(
      "select id from public.products where name='Servicio especial'",
    );
    expect(manual.rows).toHaveLength(1);
    expect(
      (
        await db.query<{ quantity: number }>(
          'select quantity from public.inventory where product_id=$1',
          [manual.rows[0]!.id],
        )
      ).rows.every((r) => r.quantity === 0),
    ).toBe(true);
    await asUser(secondUser);
    await expect(
      db.query('select public.save_quotation(null,$1::jsonb,0,$2)', [
        JSON.stringify({ ...input, items: [{ ...input.items[0], productId: id }] }),
        saleKey,
      ]),
    ).rejects.toThrow('no está disponible');
  });

  it('derives tenant from auth, isolates rows and keeps stock, sales and reports consistent', async () => {
    const productId = await createProduct();
    const adjusted = await db.query<{ quantity: number }>(
      'select public.adjust_stock($1,$2,$3,$4,$5) as quantity',
      [productId, 'retail', -1, 'Conteo físico', firstKey],
    );
    const retry = await db.query<{ quantity: number }>(
      'select public.adjust_stock($1,$2,$3,$4,$5) as quantity',
      [productId, 'retail', -1, 'Conteo físico', firstKey],
    );
    expect(adjusted.rows[0]?.quantity).toBe(9);
    expect(retry.rows[0]?.quantity).toBe(9);

    const retail = await db.query<{ result: { sale: { salesCents: number } } }>(
      'select public.create_sale($1::jsonb,$2) as result',
      [
        JSON.stringify({
          channel: 'retail',
          payment: 'cash',
          customer: '',
          scheduledFor: null,
          items: [{ productId, quantity: 2, priceCents: 1000, costCents: 600 }],
        }),
        saleKey,
      ],
    );
    expect(retail.rows[0]?.result.sale.salesCents).toBe(2000);

    await db.query('select public.create_sale($1::jsonb,$2)', [
      JSON.stringify({
        channel: 'orders',
        payment: 'yape',
        customer: 'Cliente',
        scheduledFor: null,
        items: [{ productId, quantity: 3, priceCents: 1000, costCents: 600 }],
      }),
      orderKey,
    ]);
    const pending = await db.query<{ id: string }>("select id from sales where status='pending'");
    await db.query('select public.complete_order($1)', [pending.rows[0]!.id]);

    const today = localDate();
    await db.query('select public.create_expense($1::jsonb,$2)', [
      JSON.stringify({
        channel: 'retail',
        description: 'Movilidad',
        amountCents: 500,
        spentOn: today,
      }),
      expenseKey,
    ]);
    const report = await db.query<{
      result: {
        salesCents: number;
        costTotalCents: number;
        netCents: number;
        transactions: number;
      };
    }>('select public.get_report($1::date,$2::date,null) as result', [today, today]);
    expect(report.rows[0]?.result).toMatchObject({
      salesCents: 5000,
      costTotalCents: 3000,
      netCents: 1500,
      transactions: 2,
    });

    await asUser(secondUser);
    expect((await db.query('select id from products')).rows).toHaveLength(0);
    const otherProductId = await createProduct();
    expect(otherProductId).not.toBe(productId);
    await asUser(firstUser);
    expect((await db.query('select id from products')).rows).toHaveLength(1);
  });

  it.each(['retail', 'orders'])(
    'cancels posted %s once, restores only its channel and removes report totals',
    async (channel) => {
      const productId = await createProduct();
      const sale = (
        await db.query<{ result: { sale: { id: string } } }>(
          'select public.create_sale($1::jsonb,$2) as result',
          [
            JSON.stringify({
              channel,
              payment: 'cash',
              customer: 'Cliente',
              scheduledFor: null,
              items: [{ productId, quantity: 2, priceCents: 7500, costCents: 600 }],
            }),
            saleKey,
          ],
        )
      ).rows[0]!.result.sale;
      if (channel === 'orders') await db.query('select public.complete_order($1)', [sale.id]);
      await asUser(secondUser);
      await expect(
        db.query('select public.cancel_order($1,$2)', [sale.id, 'Registro duplicado']),
      ).rejects.toThrow('Venta no encontrada');
      await asUser(firstUser);
      await expect(db.query('select public.cancel_order($1,$2)', [sale.id, ' '])).rejects.toThrow(
        'motivo',
      );
      await db.query('select public.cancel_order($1,$2)', [sale.id, 'Registro duplicado']);
      await db.query('select public.cancel_order($1,$2)', [sale.id, 'Registro duplicado']);
      expect(
        (
          await db.query<{ quantity: number }>(
            'select quantity from inventory where product_id=$1',
            [productId],
          )
        ).rows.map((r) => r.quantity),
      ).toEqual([10, 10]);
      expect(
        (
          await db.query('select * from inventory_movements where sale_id=$1 and delta>0', [
            sale.id,
          ])
        ).rows,
      ).toHaveLength(1);
      expect(
        (
          await db.query<{ status: string; cancellation_reason: string }>(
            'select status,cancellation_reason from sales where id=$1',
            [sale.id],
          )
        ).rows[0],
      ).toEqual({ status: 'cancelled', cancellation_reason: 'Registro duplicado' });
      expect(
        (
          await db.query<{ price_cents: number }>(
            'select price_cents from sale_items where sale_id=$1',
            [sale.id],
          )
        ).rows[0]?.price_cents,
      ).toBe(7500);
      expect(
        (
          await db.query<{ price_cents: number }>('select price_cents from products where id=$1', [
            productId,
          ])
        ).rows[0]?.price_cents,
      ).toBe(1000);
      const today = localDate();
      expect(
        (
          await db.query<{ result: { salesCents: number; transactions: number } }>(
            'select public.get_report($1::date,$1::date,null) as result',
            [today],
          )
        ).rows[0]?.result,
      ).toMatchObject({ salesCents: 0, transactions: 0 });
      if (channel === 'orders')
        await expect(db.query('select public.complete_order($1)', [sale.id])).rejects.toThrow(
          'anulado',
        );
    },
  );

  it('cancels a pending order without adding stock and can reapply the incremental migration', async () => {
    const productId = await createProduct();
    const sale = (
      await db.query<{ result: { sale: { id: string } } }>(
        'select public.create_sale($1::jsonb,$2) as result',
        [
          JSON.stringify({
            channel: 'orders',
            payment: 'cash',
            customer: 'Cliente',
            scheduledFor: null,
            items: [{ productId, quantity: 2, priceCents: 7500, costCents: 600 }],
          }),
          saleKey,
        ],
      )
    ).rows[0]!.result.sale;
    await db.exec('reset role');
    const migration = await readFile(resolve(process.cwd(), 'supabase/cancel_sales.sql'), 'utf8');
    await db.exec(migration);
    await db.exec(migration);
    await asUser(firstUser);
    await db.query('select public.cancel_order($1,$2)', [sale.id, 'Cliente canceló']);
    expect(
      (
        await db.query<{ quantity: number }>('select quantity from inventory where product_id=$1', [
          productId,
        ])
      ).rows.map((r) => r.quantity),
    ).toEqual([10, 10]);
    expect(
      (await db.query('select * from inventory_movements where sale_id=$1', [sale.id])).rows,
    ).toHaveLength(0);
  });

  it('rolls back a sale when any product lacks stock', async () => {
    const productId = await createProduct();
    await expect(
      db.query('update inventory set quantity = 0 where product_id = $1', [productId]),
    ).rejects.toThrow('permission denied');
    await expect(
      db.query('select public.create_sale($1::jsonb,$2)', [
        JSON.stringify({
          channel: 'retail',
          payment: 'cash',
          customer: '',
          scheduledFor: null,
          items: [{ productId, quantity: 11, priceCents: 1000, costCents: 600 }],
        }),
        '10000000-0000-4000-8000-000000000005',
      ]),
    ).rejects.toThrow('Stock insuficiente');
    expect((await db.query('select id from sales')).rows).toHaveLength(0);
    expect(
      (
        await db.query<{ quantity: number }>(
          "select quantity from inventory where product_id=$1 and channel='retail'",
          [productId],
        )
      ).rows[0]?.quantity,
    ).toBe(10);
  });

  it('imports a catalog atomically, keeps stock zero and preserves existing prices on retry', async () => {
    await db.exec(
      'reset role; grant execute on function public.import_product_catalog(jsonb) to authenticated; drop trigger assign_product_internal_code on public.products;',
    );
    await asUser(firstUser);
    const payload = [{ sku: 'EXCEL-0003', name: 'capa', priceCents: 1800, costCents: 1200 }];
    const run = (items: unknown) =>
      db.query<{ result: { created: number; skipped: number } }>(
        'select public.import_product_catalog($1::jsonb) as result',
        [JSON.stringify(items)],
      );
    expect((await run(payload)).rows[0]?.result).toEqual({ created: 1, skipped: 0 });
    expect((await run([{ ...payload[0], priceCents: 9900 }])).rows[0]?.result).toEqual({
      created: 0,
      skipped: 1,
    });
    expect(
      (await db.query<{ price_cents: number }>('select price_cents from products')).rows[0]
        ?.price_cents,
    ).toBe(1800);
    expect(
      (await db.query<{ quantity: number }>('select quantity from inventory')).rows.map(
        (r) => r.quantity,
      ),
    ).toEqual([0, 0]);
    expect((await db.query('select id from sales')).rows).toHaveLength(0);
    await expect(
      run([
        { sku: 'EXCEL-NEW', name: 'lentes', priceCents: 1000, costCents: 500 },
        { sku: 'INVALID', name: 'mal', priceCents: -1, costCents: 0 },
      ]),
    ).rejects.toThrow();
    expect((await db.query('select id from products')).rows).toHaveLength(1);
    await asUser(secondUser);
    expect((await db.query('select id from products')).rows).toHaveLength(0);
    expect((await run(payload)).rows[0]?.result).toEqual({ created: 1, skipped: 0 });
  });

  it('assigns internal codes and migrates legacy codes without changing product IDs or stock', async () => {
    const input = {
      sku: 'AUTO',
      name: 'Lentes',
      priceCents: 900,
      costCents: 400,
      retailStock: 8,
      ordersStock: 3,
    };
    const result = await db.query<{ id: string }>('select public.create_product($1::jsonb) as id', [
      JSON.stringify(input),
    ]);
    const id = result.rows[0]!.id;
    const before = await db.query<{ sku: string }>('select sku from products where id=$1', [id]);
    expect(before.rows[0]?.sku).toMatch(/^PRD-[0-9]{6,}$/);
    await db.query('select public.update_product($1,$2::jsonb)', [
      id,
      JSON.stringify({ ...input, sku: before.rows[0]!.sku, active: true, priceCents: 1000 }),
    ]);
    expect(
      (await db.query<{ sku: string }>('select sku from products where id=$1', [id])).rows[0]?.sku,
    ).toBe(before.rows[0]?.sku);
    await db.exec('reset role; drop trigger assign_product_internal_code on public.products;');
    await db.query("update products set sku='EXCEL-0003' where id=$1", [id]);
    await db.exec(await readFile(resolve(process.cwd(), 'supabase/product_codes.sql'), 'utf8'));
    await asUser(firstUser);
    const after = await db.query<{ id: string; sku: string }>('select id,sku from products');
    expect(after.rows[0]?.id).toBe(id);
    expect(after.rows[0]?.sku).toMatch(/^PRD-[0-9]{6,}$/);
    expect(
      (
        await db.query<{ quantity: number }>('select quantity from inventory order by channel')
      ).rows.map((row) => row.quantity),
    ).toEqual([3, 8]);
    await expect(
      db.query('select public.import_product_catalog($1::jsonb)', ['[]']),
    ).rejects.toThrow('permission denied');
  });

  it('assigns immutable order codes, preserves retries and backfills existing orders safely', async () => {
    const productId = await createProduct();
    const input = JSON.stringify({
      channel: 'orders',
      payment: 'cash',
      customer: 'Cliente',
      scheduledFor: null,
      items: [{ productId, quantity: 1, priceCents: 1000, costCents: 600 }],
    });
    type Result = { result: { sale: { id: string; orderCode: string } } };
    const first = (
      await db.query<Result>('select public.create_sale($1::jsonb,$2) as result', [input, orderKey])
    ).rows[0]!.result.sale;
    expect(first.orderCode).toBe('PED-000001');
    const retry = (
      await db.query<Result>('select public.create_sale($1::jsonb,$2) as result', [input, orderKey])
    ).rows[0]!.result.sale;
    expect(retry).toEqual(first);
    await db.query('select public.complete_order($1)', [first.id]);
    expect(
      (
        await db.query<{ order_code: string }>('select order_code from sales where id=$1', [
          first.id,
        ])
      ).rows[0]?.order_code,
    ).toBe(first.orderCode);
    await db.exec('reset role');
    await expect(
      db.query("update sales set order_code='PED-999999' where id=$1", [first.id]),
    ).rejects.toThrow('no se puede modificar');
    const migration = await readFile(resolve(process.cwd(), 'supabase/order_codes.sql'), 'utf8');
    await db.exec(migration);
    expect(
      (
        await db.query<{ order_code: string }>('select order_code from sales where id=$1', [
          first.id,
        ])
      ).rows[0]?.order_code,
    ).toBe(first.orderCode);
    await db.exec(
      'alter table sales drop constraint sales_order_code_valid; drop trigger assign_order_internal_code on sales;',
    );
    await db.query('update sales set order_code=null where id=$1', [first.id]);
    await db.exec(migration);
    const backfilled = (
      await db.query<{ id: string; order_code: string; status: string }>(
        'select id,order_code,status from sales where id=$1',
        [first.id],
      )
    ).rows[0]!;
    expect(backfilled.id).toBe(first.id);
    expect(backfilled.order_code).toMatch(/^PED-[0-9]{6,}$/);
    expect(backfilled.status).toBe('posted');
    expect(
      (
        await db.query<{ quantity: number }>(
          "select quantity from inventory where product_id=$1 and channel='orders'",
          [productId],
        )
      ).rows[0]?.quantity,
    ).toBe(9);
  });

  it('creates a tenant and profile for a temporary anonymous user', async () => {
    await db.exec('reset role');
    await db.query(
      `insert into auth.users(id,email,raw_user_meta_data) values ($1,null,'{"organization_name":"Control Comercial"}')`,
      [anonymousUser],
    );
    await asUser(anonymousUser);
    const profile = await db.query<{ name: string; email: string }>(
      `select tenants.name, users.email from public.users
       join public.tenants on tenants.id = users.tenant_id where users.id = $1`,
      [anonymousUser],
    );
    expect(profile.rows[0]).toEqual({
      name: 'Control Comercial',
      email: `temporal+${anonymousUser}@anonymous.invalid`,
    });
  });
});
