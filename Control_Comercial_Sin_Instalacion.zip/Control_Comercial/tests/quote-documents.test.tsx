// @vitest-environment node
import { resolve } from 'node:path';
import { readFile } from 'node:fs/promises';
import { Blob as NodeBlob } from 'node:buffer';
import { cloneElement, isValidElement } from 'react';
import type { ReactNode, ReactElement } from 'react';
import { Image, renderToBuffer } from '@react-pdf/renderer';
import ExcelJS from 'exceljs';
import { afterEach, expect, it, vi } from 'vitest';
import { CotizacionPDFReypro } from '../src/features/quotes/documents/CotizacionPDFReypro';
import { CotizacionPDFJuflex } from '../src/features/quotes/documents/CotizacionPDFJuflex';
import { CotizacionPDFPremium } from '../src/features/quotes/documents/CotizacionPDFPremium';
import { generarExcelPro } from '../src/features/quotes/documents/CotizacionExcel';
import type { DocumentProps } from '../src/features/quotes/documents/types';
const props: DocumentProps = {
  numero: '00001',
  cliente: 'Cliente prueba',
  empresa: '20123456789',
  direccion: 'Lima',
  fecha: '2026-10-29',
  cotizacion: [{ id: 'one', nombre: 'Guantes', cantidad: 2, precio: 11.8 }],
  subtotal: 20,
  aplicarIgv: true,
  igv: 3.6,
  total: 23.6,
};
function localImages(node: ReactNode): ReactNode {
  if (Array.isArray(node)) return node.map(localImages);
  if (!isValidElement<{ children?: ReactNode; src?: string }>(node)) return node;
  if (node.type === Image && typeof node.props.src === 'string')
    return cloneElement(node, { src: resolve('public', node.props.src.replace(/^\//, '')) });
  if (node.props.children) return cloneElement(node, {}, localImages(node.props.children));
  return node;
}
afterEach(() => vi.unstubAllGlobals());
it('renders all three original branded PDF templates with local logos', async () => {
  for (const Template of [CotizacionPDFReypro, CotizacionPDFJuflex, CotizacionPDFPremium]) {
    const document = localImages(<Template {...props} />) as ReactElement;
    // Resolve the template before replacing asset paths for the Node renderer.
    const resolved = localImages(Template(props)) as ReactElement<
      Parameters<typeof renderToBuffer>[0]['props']
    >;
    expect(document).toBeTruthy();
    const buffer = await renderToBuffer(resolved);
    expect(buffer.subarray(0, 4).toString()).toBe('%PDF');
    expect(buffer.length).toBeGreaterThan(5000);
  }
}, 30000);
it('generates all three original Excel templates with images and client details', async () => {
  let captured: NodeBlob | null = null;
  vi.stubGlobal('Blob', NodeBlob);
  vi.stubGlobal('fetch', async (url: string) => {
    const bytes = await readFile(resolve('public', url.replace(/^\//, '')));
    return {
      arrayBuffer: async () =>
        bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength),
    };
  });
  vi.stubGlobal('window', {
    URL: {
      createObjectURL: (blob: NodeBlob) => {
        captured = blob;
        return 'blob:test';
      },
      revokeObjectURL: vi.fn(),
    },
  });
  vi.stubGlobal('document', { createElement: () => ({ click: vi.fn() }) });
  for (const plantilla of ['reypro', 'juflex', 'premium']) {
    await generarExcelPro({ ...props, plantilla });
    expect(captured).not.toBeNull();
    const book = new ExcelJS.Workbook();
    await book.xlsx.load(await (captured as unknown as NodeBlob).arrayBuffer());
    const sheet = book.worksheets[0]!;
    expect(sheet.getImages().length).toBe(1);
    const text: string[] = [];
    sheet.eachRow((row) =>
      row.eachCell((cell) => {
        if (cell.value !== null) text.push(cell.text);
      }),
    );
    expect(text.join(' ')).toContain('Cliente prueba');
    expect(text.join(' ')).toContain('Guantes');
  }
}, 30000);
