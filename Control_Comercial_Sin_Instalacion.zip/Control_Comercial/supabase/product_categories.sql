-- Categorías, subcategorías, colores y tallas de productos
-- Ejecutar una vez en Supabase → SQL Editor. Conserva productos, stock e historial.
begin;
alter table public.products add column if not exists category varchar(60) not null default '' check (length(trim(category)) <= 60);
alter table public.products add column if not exists subcategory varchar(60) not null default '' check (length(trim(subcategory)) <= 60);
alter table public.products add column if not exists color varchar(80) not null default '' check (length(trim(color)) <= 80);
alter table public.products add column if not exists size varchar(60) not null default '' check (length(trim(size)) <= 60);

drop view if exists public.product_catalog;
create view public.product_catalog with (security_invoker = true) as
select p.id, p.tenant_id, p.sku, p.category, p.subcategory, p.color, p.name, p.size, p.price_cents, p.cost_cents, p.active,
  coalesce(r.quantity, 0) as retail_stock, coalesce(o.quantity, 0) as orders_stock,
  case when p.sku ~ '^PRD-[0-9]+$' then substring(p.sku from 5)::numeric else null end as code_number
from public.products p
left join public.inventory r on r.tenant_id = p.tenant_id and r.product_id = p.id and r.channel = 'retail'
left join public.inventory o on o.tenant_id = p.tenant_id and o.product_id = p.id and o.channel = 'orders'
where p.deleted_at is null;
revoke all on public.product_catalog from public, anon;
grant select on public.product_catalog to authenticated;

create or replace function public.create_product(p_input jsonb)
returns uuid
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_tenant uuid := public.current_tenant_id();
  v_actor uuid := auth.uid();
  v_product uuid := gen_random_uuid();
  v_category text := trim(coalesce(p_input->>'category', ''));
  v_subcategory text := trim(coalesce(p_input->>'subcategory', ''));
  v_color text := trim(coalesce(p_input->>'color', ''));
  v_name text := trim(coalesce(p_input->>'name', ''));
  v_size text := trim(coalesce(p_input->>'size', ''));
  v_channel text;
  v_quantity integer;
begin
  if v_tenant is null or v_actor is null then raise exception 'Inicia sesión para continuar.'; end if;
  if length(trim(coalesce(p_input->>'sku', ''))) not between 1 and 40
    or length(v_category) > 60
    or length(v_subcategory) > 60
    or length(v_color) > 80
    or length(v_name) not between 2 and 120
    or length(v_size) > 60
    or (p_input->>'priceCents')::bigint not between 0 and 100000000
    or (p_input->>'costCents')::bigint not between 0 and 100000000
    or (p_input->>'retailStock')::integer not between 0 and 1000000
    or (p_input->>'ordersStock')::integer not between 0 and 1000000 then
    raise exception 'Datos de producto inválidos.';
  end if;
  insert into public.products(id, tenant_id, sku, category, subcategory, color, name, size, price_cents, cost_cents)
  values (v_product, v_tenant, trim(p_input->>'sku'), v_category, v_subcategory, v_color, v_name, v_size, (p_input->>'priceCents')::bigint, (p_input->>'costCents')::bigint);
  foreach v_channel in array array['retail', 'orders'] loop
    v_quantity := case when v_channel = 'retail' then (p_input->>'retailStock')::integer else (p_input->>'ordersStock')::integer end;
    insert into public.inventory(tenant_id, product_id, channel, quantity) values (v_tenant, v_product, v_channel, v_quantity);
    if v_quantity > 0 then
      insert into public.inventory_movements(tenant_id, product_id, channel, delta, reason, created_by)
      values (v_tenant, v_product, v_channel, v_quantity, 'Stock inicial', v_actor);
    end if;
  end loop;
  return v_product;
end;
$$;

create or replace function public.update_product(p_product_id uuid, p_input jsonb)
returns uuid
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_tenant uuid := public.current_tenant_id();
  v_category text := trim(coalesce(p_input->>'category', ''));
  v_subcategory text := trim(coalesce(p_input->>'subcategory', ''));
  v_color text := trim(coalesce(p_input->>'color', ''));
  v_name text := trim(coalesce(p_input->>'name', ''));
  v_size text := trim(coalesce(p_input->>'size', ''));
  v_id uuid;
begin
  if length(trim(coalesce(p_input->>'sku', ''))) not between 1 and 40
    or length(v_category) > 60
    or length(v_subcategory) > 60
    or length(v_color) > 80
    or length(v_name) not between 2 and 120
    or length(v_size) > 60
    or (p_input->>'priceCents')::bigint not between 0 and 100000000
    or (p_input->>'costCents')::bigint not between 0 and 100000000
    or p_input->'active' is null or jsonb_typeof(p_input->'active') <> 'boolean' then
    raise exception 'Datos de producto inválidos.';
  end if;
  update public.products set sku = trim(p_input->>'sku'), category = v_category, subcategory = v_subcategory, color = v_color, name = v_name, size = v_size,
    price_cents = (p_input->>'priceCents')::bigint, cost_cents = (p_input->>'costCents')::bigint,
    active = (p_input->>'active')::boolean
  where tenant_id = v_tenant and id = p_product_id returning id into v_id;
  if v_id is null then raise exception 'Producto no encontrado.'; end if;
  return v_id;
end;
$$;

revoke all on function public.create_product(jsonb), public.update_product(uuid, jsonb) from public, anon;
grant execute on function public.create_product(jsonb), public.update_product(uuid, jsonb) to authenticated;
commit;
