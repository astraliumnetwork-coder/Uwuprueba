-- Apply this once only if schema.sql was already installed in Supabase.
-- Anonymous users get an isolated tenant and profile; RLS remains enabled.
create or replace function public.create_tenant_for_new_user()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_tenant_id uuid;
  v_name text;
begin
  v_name := trim(coalesce(new.raw_user_meta_data ->> 'organization_name', ''));
  if length(v_name) < 2 or length(v_name) > 80 then
    if new.email is null then
      v_name := 'Control Comercial';
    else
      raise exception 'El nombre de la empresa debe tener entre 2 y 80 caracteres.';
    end if;
  end if;

  insert into public.tenants(name) values (v_name) returning id into v_tenant_id;
  insert into public.users(id, tenant_id, email)
  values (
    new.id,
    v_tenant_id,
    coalesce(lower(new.email), 'temporal+' || new.id::text || '@anonymous.invalid')
  );
  return new;
end;
$$;
