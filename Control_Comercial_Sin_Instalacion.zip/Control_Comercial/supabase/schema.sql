create table public.tenants (
  id uuid primary key default gen_random_uuid(),
  name varchar(80) not null check (length(trim(name)) between 2 and 80),
  created_at timestamptz not null default now()
);

create table public.users (
  id uuid primary key references auth.users(id) on delete cascade,
  tenant_id uuid not null references public.tenants(id) on delete cascade,
  email varchar(254) not null,
  role text not null default 'owner' check (role in ('owner')),
  unique (tenant_id, id)
);

create table public.products (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references public.tenants(id) on delete cascade,
  sku varchar(40) not null check (length(trim(sku)) between 1 and 40),
  name varchar(120) not null check (length(trim(name)) between 2 and 120),
  price_cents bigint not null check (price_cents between 0 and 100000000),
  cost_cents bigint not null check (cost_cents between 0 and 100000000),
  active boolean not null default true,
  unique (tenant_id, id),
  unique (tenant_id, sku)
);
create index products_tenant_name_idx on public.products(tenant_id, lower(name));

create table public.inventory (
  tenant_id uuid not null,
  product_id uuid not null,
  channel text not null check (channel in ('retail', 'orders')),
  quantity integer not null check (quantity between 0 and 1000000000),
  primary key (tenant_id, product_id, channel),
  foreign key (tenant_id, product_id) references public.products(tenant_id, id) on delete cascade
);

create table public.sales (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references public.tenants(id) on delete cascade,
  channel text not null check (channel in ('retail', 'orders')),
  payment text not null check (payment in ('cash', 'yape', 'plin', 'transfer')),
  customer varchar(120) not null default '',
  scheduled_for date,
  status text not null check (status in ('pending', 'posted', 'cancelled')),
  created_at timestamptz not null default now(),
  recognized_at timestamptz,
  cancelled_at timestamptz,
  cancellation_reason varchar(200),
  created_by uuid not null,
  idempotency_key uuid not null,
  request_payload jsonb not null,
  unique (tenant_id, id),
  unique (tenant_id, idempotency_key),
  foreign key (tenant_id, created_by) references public.users(tenant_id, id),
  check ((status = 'pending' and recognized_at is null and channel = 'orders') or status in ('posted', 'cancelled')),
  check (channel <> 'orders' or length(trim(customer)) between 1 and 120)
);
create index sales_tenant_channel_created_idx on public.sales(tenant_id, channel, created_at desc, id);
create index sales_report_idx on public.sales(tenant_id, recognized_at, channel) where status = 'posted';

create table public.sale_items (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null,
  sale_id uuid not null,
  product_id uuid not null,
  product_name varchar(120) not null,
  quantity integer not null check (quantity between 1 and 100000),
  price_cents bigint not null check (price_cents between 0 and 100000000),
  cost_cents bigint not null check (cost_cents between 0 and 100000000),
  unique (tenant_id, sale_id, product_id),
  foreign key (tenant_id, sale_id) references public.sales(tenant_id, id),
  foreign key (tenant_id, product_id) references public.products(tenant_id, id)
);
create index sale_items_sale_idx on public.sale_items(tenant_id, sale_id);

create table public.expenses (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references public.tenants(id) on delete cascade,
  channel text not null check (channel in ('retail', 'orders')),
  description varchar(160) not null check (length(trim(description)) between 2 and 160),
  amount_cents bigint not null check (amount_cents between 1 and 100000000),
  spent_on date not null,
  created_by uuid not null,
  created_at timestamptz not null default now(),
  idempotency_key uuid not null,
  request_payload jsonb not null,
  unique (tenant_id, idempotency_key),
  foreign key (tenant_id, created_by) references public.users(tenant_id, id)
);
create index expenses_report_idx on public.expenses(tenant_id, spent_on, channel);

create table public.inventory_movements (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null,
  product_id uuid not null,
  channel text not null check (channel in ('retail', 'orders')),
  delta integer not null,
  reason varchar(200) not null check (length(trim(reason)) between 3 and 200),
  sale_id uuid,
  created_by uuid not null,
  created_at timestamptz not null default now(),
  foreign key (tenant_id, product_id) references public.products(tenant_id, id),
  foreign key (tenant_id, sale_id) references public.sales(tenant_id, id),
  foreign key (tenant_id, created_by) references public.users(tenant_id, id)
);
create index inventory_movements_history_idx on public.inventory_movements(tenant_id, product_id, created_at desc);

create table public.stock_operations (
  tenant_id uuid not null references public.tenants(id) on delete cascade,
  idempotency_key uuid not null,
  request_payload jsonb not null,
  quantity integer not null,
  primary key (tenant_id, idempotency_key)
);

create or replace function public.current_tenant_id()
returns uuid
language sql
stable
security definer
set search_path = ''
as $$
  select u.tenant_id from public.users u where u.id = auth.uid()
$$;

create or replace function public.create_tenant_for_new_user()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_tenant_id uuid;
  v_name text;
begin
  v_name := trim(coalesce(new.raw_user_meta_data ->> 'organization_name', ''));
  if length(v_name) < 2 or length(v_name) > 80 then
    if new.email is null then
      v_name := 'Control Comercial';
    else
      raise exception 'El nombre de la empresa debe tener entre 2 y 80 caracteres.';
    end if;
  end if;

  insert into public.tenants(name) values (v_name) returning id into v_tenant_id;
  insert into public.users(id, tenant_id, email)
  values (
    new.id,
    v_tenant_id,
    coalesce(lower(new.email), 'temporal+' || new.id::text || '@anonymous.invalid')
  );
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.create_tenant_for_new_user();

alter table public.tenants enable row level security;
alter table public.users enable row level security;
alter table public.products enable row level security;
alter table public.inventory enable row level security;
alter table public.sales enable row level security;
alter table public.sale_items enable row level security;
alter table public.expenses enable row level security;
alter table public.inventory_movements enable row level security;
alter table public.stock_operations enable row level security;

alter table public.tenants force row level security;
alter table public.users force row level security;
alter table public.products force row level security;
alter table public.inventory force row level security;
alter table public.sales force row level security;
alter table public.sale_items force row level security;
alter table public.expenses force row level security;
alter table public.inventory_movements force row level security;
alter table public.stock_operations force row level security;

create policy tenant_read on public.tenants for select to authenticated using (id = public.current_tenant_id());
create policy tenant_update on public.tenants for update to authenticated using (id = public.current_tenant_id()) with check (id = public.current_tenant_id());
create policy user_read_self on public.users for select to authenticated using (id = auth.uid());

do $$
declare
  v_table text;
begin
  foreach v_table in array array['products', 'inventory', 'sales', 'sale_items', 'expenses', 'inventory_movements', 'stock_operations'] loop
    execute format('create policy tenant_isolation on public.%I for all to authenticated using (tenant_id = public.current_tenant_id()) with check (tenant_id = public.current_tenant_id())', v_table);
  end loop;
end;
$$;

grant usage on schema public to authenticated;
grant usage on schema auth to authenticated;
grant select on public.tenants, public.users, public.products, public.inventory, public.sales, public.sale_items, public.expenses, public.inventory_movements to authenticated;
revoke all on function public.current_tenant_id() from public, anon;
grant execute on function public.current_tenant_id() to authenticated;

create or replace function public.create_product(p_input jsonb)
returns uuid
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_tenant uuid := public.current_tenant_id();
  v_actor uuid := auth.uid();
  v_product uuid := gen_random_uuid();
  v_channel text;
  v_quantity integer;
begin
  if v_tenant is null or v_actor is null then raise exception 'Inicia sesión para continuar.'; end if;
  if length(trim(coalesce(p_input->>'sku', ''))) not between 1 and 40
    or length(trim(coalesce(p_input->>'name', ''))) not between 2 and 120
    or (p_input->>'priceCents')::bigint not between 0 and 100000000
    or (p_input->>'costCents')::bigint not between 0 and 100000000
    or (p_input->>'retailStock')::integer not between 0 and 1000000
    or (p_input->>'ordersStock')::integer not between 0 and 1000000 then
    raise exception 'Datos de producto inválidos.';
  end if;
  insert into public.products(id, tenant_id, sku, name, price_cents, cost_cents)
  values (v_product, v_tenant, trim(p_input->>'sku'), trim(p_input->>'name'), (p_input->>'priceCents')::bigint, (p_input->>'costCents')::bigint);
  foreach v_channel in array array['retail', 'orders'] loop
    v_quantity := case when v_channel = 'retail' then (p_input->>'retailStock')::integer else (p_input->>'ordersStock')::integer end;
    insert into public.inventory(tenant_id, product_id, channel, quantity) values (v_tenant, v_product, v_channel, v_quantity);
    if v_quantity > 0 then
      insert into public.inventory_movements(tenant_id, product_id, channel, delta, reason, created_by)
      values (v_tenant, v_product, v_channel, v_quantity, 'Stock inicial', v_actor);
    end if;
  end loop;
  return v_product;
end;
$$;

create or replace function public.update_product(p_product_id uuid, p_input jsonb)
returns uuid
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_tenant uuid := public.current_tenant_id();
  v_id uuid;
begin
  if length(trim(coalesce(p_input->>'sku', ''))) not between 1 and 40
    or length(trim(coalesce(p_input->>'name', ''))) not between 2 and 120
    or (p_input->>'priceCents')::bigint not between 0 and 100000000
    or (p_input->>'costCents')::bigint not between 0 and 100000000
    or p_input->'active' is null or jsonb_typeof(p_input->'active') <> 'boolean' then
    raise exception 'Datos de producto inválidos.';
  end if;
  update public.products set sku = trim(p_input->>'sku'), name = trim(p_input->>'name'),
    price_cents = (p_input->>'priceCents')::bigint, cost_cents = (p_input->>'costCents')::bigint,
    active = (p_input->>'active')::boolean
  where tenant_id = v_tenant and id = p_product_id returning id into v_id;
  if v_id is null then raise exception 'Producto no encontrado.'; end if;
  return v_id;
end;
$$;

create or replace function public.adjust_stock(p_product_id uuid, p_channel text, p_delta integer, p_reason text, p_key uuid)
returns integer
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_tenant uuid := public.current_tenant_id();
  v_actor uuid := auth.uid();
  v_payload jsonb := jsonb_build_object('productId', p_product_id, 'channel', p_channel, 'delta', p_delta, 'reason', trim(p_reason));
  v_existing public.stock_operations%rowtype;
  v_quantity integer;
begin
  if v_tenant is null or v_actor is null then raise exception 'Inicia sesión para continuar.'; end if;
  if p_channel not in ('retail', 'orders') or p_delta not between -1000000 and 1000000 or p_delta = 0 or length(trim(p_reason)) not between 3 and 200 then raise exception 'Ajuste de stock inválido.'; end if;
  perform pg_advisory_xact_lock(hashtextextended(v_tenant::text || ':stock:' || p_key::text, 0));
  select * into v_existing from public.stock_operations where tenant_id = v_tenant and idempotency_key = p_key;
  if found then
    if v_existing.request_payload <> v_payload then raise exception 'Clave de ajuste reutilizada con otros datos.'; end if;
    return v_existing.quantity;
  end if;
  update public.inventory set quantity = quantity + p_delta
  where tenant_id = v_tenant and product_id = p_product_id and channel = p_channel and quantity + p_delta between 0 and 1000000000
  returning quantity into v_quantity;
  if not found then raise exception 'El ajuste deja stock negativo o el producto no está disponible.'; end if;
  insert into public.inventory_movements(tenant_id, product_id, channel, delta, reason, created_by)
  values (v_tenant, p_product_id, p_channel, p_delta, trim(p_reason), v_actor);
  insert into public.stock_operations(tenant_id, idempotency_key, request_payload, quantity)
  values (v_tenant, p_key, v_payload, v_quantity);
  return v_quantity;
end;
$$;

create or replace function public.sale_detail(p_sale_id uuid)
returns jsonb
language sql
stable
security invoker
set search_path = ''
as $$
  with selected_sale as (
    select s.* from public.sales s where s.id = p_sale_id and s.tenant_id = public.current_tenant_id()
  ), line_rows as (
    select i.*, (i.quantity::bigint * i.price_cents) as sales_cents,
           (i.quantity::bigint * i.cost_cents) as cost_total_cents
    from public.sale_items i join selected_sale s on s.tenant_id = i.tenant_id and s.id = i.sale_id
  ), totals as (
    select coalesce(sum(sales_cents), 0) sales_cents, coalesce(sum(cost_total_cents), 0) cost_total_cents from line_rows
  )
  select case when s.id is null then null else jsonb_build_object(
    'sale', jsonb_build_object(
      'id', s.id, 'channel', s.channel, 'payment', s.payment, 'customer', s.customer,
      'scheduledFor', s.scheduled_for, 'createdAt', s.created_at, 'recognizedAt', s.recognized_at,
      'status', s.status, 'salesCents', t.sales_cents, 'costTotalCents', t.cost_total_cents,
      'grossCents', t.sales_cents - t.cost_total_cents
    ),
    'items', coalesce((select jsonb_agg(jsonb_build_object(
      'productId', l.product_id, 'name', l.product_name, 'quantity', l.quantity,
      'priceCents', l.price_cents, 'costCents', l.cost_cents, 'salesCents', l.sales_cents,
      'costTotalCents', l.cost_total_cents, 'grossCents', l.sales_cents - l.cost_total_cents
    ) order by l.product_name) from line_rows l), '[]'::jsonb)
  ) end
  from selected_sale s cross join totals t
$$;

create or replace function public.create_sale(p_input jsonb, p_key uuid)
returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_tenant uuid := public.current_tenant_id();
  v_actor uuid := auth.uid();
  v_channel text := p_input->>'channel';
  v_id uuid;
  v_existing public.sales%rowtype;
  v_item jsonb;
  v_product public.products%rowtype;
  v_quantity integer;
begin
  if v_tenant is null or v_actor is null then raise exception 'Inicia sesión para continuar.'; end if;
  if v_channel not in ('retail', 'orders') or p_input->>'payment' not in ('cash', 'yape', 'plin', 'transfer') then raise exception 'Venta inválida.'; end if;
  if coalesce(jsonb_typeof(p_input->'items'), '') <> 'array' then raise exception 'Agrega entre 1 y 100 productos.'; end if;
  if jsonb_array_length(p_input->'items') not between 1 and 100 then raise exception 'Agrega entre 1 y 100 productos.'; end if;
  if v_channel = 'orders' and length(trim(coalesce(p_input->>'customer', ''))) = 0 then raise exception 'Indica el cliente del pedido.'; end if;
  perform pg_advisory_xact_lock(hashtextextended(v_tenant::text || ':sale:' || p_key::text, 0));
  select * into v_existing from public.sales where tenant_id = v_tenant and idempotency_key = p_key;
  if found then
    if v_existing.request_payload <> p_input then raise exception 'Clave de venta reutilizada con otros datos.'; end if;
    return public.sale_detail(v_existing.id);
  end if;
  v_id := gen_random_uuid();
  insert into public.sales(id, tenant_id, channel, payment, customer, scheduled_for, status, recognized_at, created_by, idempotency_key, request_payload)
  values (v_id, v_tenant, v_channel, p_input->>'payment', trim(coalesce(p_input->>'customer', '')),
    nullif(p_input->>'scheduledFor', '')::date,
    case when v_channel = 'retail' then 'posted' else 'pending' end,
    case when v_channel = 'retail' then now() else null end,
    v_actor, p_key, p_input);

  for v_item in select value from jsonb_array_elements(p_input->'items') order by value->>'productId' loop
    if (v_item->>'quantity')::integer not between 1 and 100000
      or (v_item->>'priceCents')::bigint not between 0 and 100000000
      or (v_item->>'costCents')::bigint not between 0 and 100000000 then
      raise exception 'Cantidad, precio o costo inválido.';
    end if;
    select * into v_product from public.products where tenant_id = v_tenant and id = (v_item->>'productId')::uuid for share;
    if not found or not v_product.active then raise exception 'Un producto ya no está disponible.'; end if;
    v_quantity := (v_item->>'quantity')::integer;
    insert into public.sale_items(tenant_id, sale_id, product_id, product_name, quantity, price_cents, cost_cents)
    values (v_tenant, v_id, v_product.id, v_product.name, v_quantity, (v_item->>'priceCents')::bigint, (v_item->>'costCents')::bigint);
    if v_channel = 'retail' then
      update public.inventory set quantity = quantity - v_quantity
      where tenant_id = v_tenant and product_id = v_product.id and channel = v_channel and quantity >= v_quantity;
      if not found then raise exception 'Stock insuficiente en esta línea de negocio. Actualiza el catálogo.'; end if;
      insert into public.inventory_movements(tenant_id, product_id, channel, delta, reason, sale_id, created_by)
      values (v_tenant, v_product.id, v_channel, -v_quantity, 'Salida por venta', v_id, v_actor);
    end if;
  end loop;
  return public.sale_detail(v_id);
end;
$$;

create or replace function public.complete_order(p_sale_id uuid)
returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_tenant uuid := public.current_tenant_id();
  v_actor uuid := auth.uid();
  v_order public.sales%rowtype;
  v_item record;
begin
  select * into v_order from public.sales where tenant_id = v_tenant and id = p_sale_id for update;
  if not found or v_order.channel <> 'orders' then raise exception 'Pedido no encontrado.'; end if;
  if v_order.status = 'posted' then return public.sale_detail(p_sale_id); end if;
  if v_order.status <> 'pending' then raise exception 'El pedido ya fue anulado.'; end if;
  for v_item in select product_id, quantity from public.sale_items where tenant_id = v_tenant and sale_id = p_sale_id order by product_id loop
    update public.inventory set quantity = quantity - v_item.quantity
    where tenant_id = v_tenant and product_id = v_item.product_id and channel = 'orders' and quantity >= v_item.quantity;
    if not found then raise exception 'Stock insuficiente en pedidos. Actualiza el catálogo.'; end if;
    insert into public.inventory_movements(tenant_id, product_id, channel, delta, reason, sale_id, created_by)
    values (v_tenant, v_item.product_id, 'orders', -v_item.quantity, 'Salida por entrega', p_sale_id, v_actor);
  end loop;
  update public.sales set status = 'posted', recognized_at = now() where tenant_id = v_tenant and id = p_sale_id;
  return public.sale_detail(p_sale_id);
end;
$$;

create or replace function public.cancel_order(p_sale_id uuid, p_reason text)
returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_tenant uuid := public.current_tenant_id();
  v_actor uuid := auth.uid();
  v_sale public.sales%rowtype;
  v_item record;
begin
  if v_tenant is null or v_actor is null then raise exception 'Sesión no válida.'; end if;
  if length(trim(coalesce(p_reason, ''))) not between 3 and 200 then raise exception 'Indica el motivo de anulación.'; end if;
  -- El bloqueo serializa entrega/anulación y los reintentos de la misma venta.
  select * into v_sale from public.sales where tenant_id = v_tenant and id = p_sale_id for update;
  if not found then raise exception 'Venta no encontrada.'; end if;
  if v_sale.status = 'cancelled' then return jsonb_build_object('id', p_sale_id); end if;
  if v_sale.status = 'posted' then
    for v_item in select product_id, quantity from public.sale_items
      where tenant_id = v_tenant and sale_id = p_sale_id order by product_id loop
      update public.inventory set quantity = quantity + v_item.quantity
      where tenant_id = v_tenant and product_id = v_item.product_id and channel = v_sale.channel
        and quantity <= 1000000000 - v_item.quantity;
      if not found then raise exception 'No se puede restituir el stock. Revisa las existencias del producto.'; end if;
      insert into public.inventory_movements(tenant_id, product_id, channel, delta, reason, sale_id, created_by)
      values (v_tenant, v_item.product_id, v_sale.channel, v_item.quantity, 'Anulación: ' || left(trim(p_reason), 189), p_sale_id, v_actor);
    end loop;
  end if;
  update public.sales set status = 'cancelled', cancelled_at = now(), cancellation_reason = trim(p_reason)
  where tenant_id = v_tenant and id = p_sale_id;
  return jsonb_build_object('id', p_sale_id);
end;
$$;

create or replace function public.create_expense(p_input jsonb, p_key uuid)
returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_tenant uuid := public.current_tenant_id();
  v_actor uuid := auth.uid();
  v_existing public.expenses%rowtype;
  v_id uuid;
begin
  if v_tenant is null or v_actor is null then raise exception 'Inicia sesión para continuar.'; end if;
  if p_input->>'channel' not in ('retail', 'orders')
    or length(trim(coalesce(p_input->>'description', ''))) not between 2 and 160
    or (p_input->>'amountCents')::bigint not between 1 and 100000000
    or nullif(p_input->>'spentOn', '') is null then
    raise exception 'Datos de gasto inválidos.';
  end if;
  perform pg_advisory_xact_lock(hashtextextended(v_tenant::text || ':expense:' || p_key::text, 0));
  select * into v_existing from public.expenses where tenant_id = v_tenant and idempotency_key = p_key;
  if found then
    if v_existing.request_payload <> p_input then raise exception 'Clave de gasto reutilizada con otros datos.'; end if;
    return jsonb_build_object('id', v_existing.id);
  end if;
  v_id := gen_random_uuid();
  insert into public.expenses(id, tenant_id, channel, description, amount_cents, spent_on, created_by, idempotency_key, request_payload)
  values (v_id, v_tenant, p_input->>'channel', trim(p_input->>'description'), (p_input->>'amountCents')::bigint, (p_input->>'spentOn')::date, v_actor, p_key, p_input);
  return jsonb_build_object('id', v_id);
end;
$$;

create or replace function public.save_tenant_settings(p_name text)
returns text
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_tenant uuid := public.current_tenant_id();
  v_name text := trim(coalesce(p_name, ''));
begin
  if length(v_name) not between 2 and 80 then raise exception 'El nombre debe tener entre 2 y 80 caracteres.'; end if;
  update public.tenants set name = v_name where id = v_tenant returning name into v_name;
  if v_name is null then raise exception 'Empresa no encontrada.'; end if;
  return v_name;
end;
$$;

create or replace function public.get_report(p_from date, p_to date, p_channel text default null)
returns jsonb
language plpgsql
stable
security invoker
set search_path = ''
as $$
declare
  v_tenant uuid := public.current_tenant_id();
  v_result jsonb;
begin
  if v_tenant is null then raise exception 'Inicia sesión para continuar.'; end if;
  if p_from > p_to or p_to - p_from > 366 then raise exception 'Selecciona un rango de hasta 367 días.'; end if;
  if p_channel is not null and p_channel not in ('retail', 'orders') then raise exception 'Línea de negocio inválida.'; end if;
  with sales_daily as (
    select (s.recognized_at at time zone 'America/Lima')::date as report_date,
      sum(i.quantity::bigint * i.price_cents) as revenue,
      sum(i.quantity::bigint * i.cost_cents) as cost
    from public.sales s join public.sale_items i on i.tenant_id = s.tenant_id and i.sale_id = s.id
    where s.tenant_id = v_tenant and s.status = 'posted'
      and (p_channel is null or s.channel = p_channel)
      and s.recognized_at >= (p_from::timestamp at time zone 'America/Lima')
      and s.recognized_at < ((p_to + 1)::timestamp at time zone 'America/Lima')
    group by 1
  ), expense_daily as (
    select e.spent_on as report_date, sum(e.amount_cents) as amount
    from public.expenses e where e.tenant_id = v_tenant and e.spent_on between p_from and p_to
      and (p_channel is null or e.channel = p_channel)
    group by e.spent_on
  ), daily as (
    select d.day::date as report_date, coalesce(s.revenue, 0) as revenue, coalesce(s.cost, 0) as cost,
      coalesce(e.amount, 0) as expenses
    from generate_series(p_from::timestamp, p_to::timestamp, interval '1 day') d(day)
    left join sales_daily s on s.report_date = d.day::date
    left join expense_daily e on e.report_date = d.day::date
  ), payments as (
    select s.payment, sum(i.quantity::bigint * i.price_cents) as revenue
    from public.sales s join public.sale_items i on i.tenant_id = s.tenant_id and i.sale_id = s.id
    where s.tenant_id = v_tenant and s.status = 'posted'
      and (p_channel is null or s.channel = p_channel)
      and s.recognized_at >= (p_from::timestamp at time zone 'America/Lima')
      and s.recognized_at < ((p_to + 1)::timestamp at time zone 'America/Lima')
    group by s.payment
  ), totals as (
    select coalesce(sum(revenue), 0) revenue, coalesce(sum(cost), 0) cost, coalesce(sum(expenses), 0) expenses from daily
  ), transaction_count as (
    select count(*) as total from public.sales s where s.tenant_id = v_tenant and s.status = 'posted'
      and (p_channel is null or s.channel = p_channel)
      and s.recognized_at >= (p_from::timestamp at time zone 'America/Lima')
      and s.recognized_at < ((p_to + 1)::timestamp at time zone 'America/Lima')
  )
  select jsonb_build_object(
    'from', p_from, 'to', p_to,
    'salesCents', t.revenue, 'costTotalCents', t.cost,
    'grossCents', t.revenue - t.cost, 'expensesCents', t.expenses,
    'netCents', t.revenue - t.cost - t.expenses, 'transactions', c.total,
    'byPayment', coalesce((select jsonb_agg(jsonb_build_object('payment', p.payment, 'salesCents', p.revenue) order by p.payment) from payments p), '[]'::jsonb),
    'daily', coalesce((select jsonb_agg(jsonb_build_object(
      'date', d.report_date, 'salesCents', d.revenue, 'costTotalCents', d.cost,
      'grossCents', d.revenue - d.cost, 'expensesCents', d.expenses,
      'netCents', d.revenue - d.cost - d.expenses
    ) order by d.report_date) from daily d), '[]'::jsonb)
  ) into v_result from totals t cross join transaction_count c;
  return v_result;
end;
$$;

revoke all on function public.create_tenant_for_new_user() from public, anon, authenticated;
revoke all on function public.create_product(jsonb), public.update_product(uuid, jsonb), public.adjust_stock(uuid, text, integer, text, uuid), public.sale_detail(uuid), public.create_sale(jsonb, uuid), public.complete_order(uuid), public.cancel_order(uuid, text), public.create_expense(jsonb, uuid), public.save_tenant_settings(text), public.get_report(date, date, text) from public, anon;
grant execute on function public.create_product(jsonb), public.update_product(uuid, jsonb), public.adjust_stock(uuid, text, integer, text, uuid), public.sale_detail(uuid), public.create_sale(jsonb, uuid), public.complete_order(uuid), public.cancel_order(uuid, text), public.create_expense(jsonb, uuid), public.save_tenant_settings(text), public.get_report(date, date, text) to authenticated;

-- Ejecutar una vez en SQL Editor para bases ya instaladas.
create or replace function public.import_product_catalog(p_items jsonb)
returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_tenant uuid := public.current_tenant_id();
  v_item jsonb;
  v_created integer := 0;
  v_skipped integer := 0;
begin
  if v_tenant is null or auth.uid() is null then raise exception 'Inicia sesión para continuar.'; end if;
  if jsonb_typeof(p_items) is distinct from 'array' then raise exception 'Catálogo inválido.'; end if;
  if jsonb_array_length(p_items) not between 1 and 500 then raise exception 'Selecciona entre 1 y 500 artículos.'; end if;
  -- Serializa reintentos y cargas concurrentes del mismo tenant.
  perform pg_advisory_xact_lock(hashtextextended(v_tenant::text, 0));
  for v_item in select value from jsonb_array_elements(p_items) loop
    if jsonb_typeof(v_item->'sku') is distinct from 'string'
      or jsonb_typeof(v_item->'name') is distinct from 'string'
      or jsonb_typeof(v_item->'priceCents') is distinct from 'number'
      or jsonb_typeof(v_item->'costCents') is distinct from 'number'
      or (v_item->>'priceCents') !~ '^[0-9]+$'
      or (v_item->>'costCents') !~ '^[0-9]+$' then
      raise exception 'Artículo inválido.';
    end if;
    if exists(select 1 from public.products where tenant_id = v_tenant and sku = trim(v_item->>'sku')) then
      v_skipped := v_skipped + 1;
    else
      perform public.create_product(jsonb_build_object(
        'sku', v_item->>'sku', 'name', v_item->>'name',
        'priceCents', v_item->'priceCents', 'costCents', v_item->'costCents',
        'retailStock', 0, 'ordersStock', 0
      ));
      v_created := v_created + 1;
    end if;
  end loop;
  return jsonb_build_object('created', v_created, 'skipped', v_skipped);
end;
$$;
revoke all on function public.import_product_catalog(jsonb) from public, anon;
grant execute on function public.import_product_catalog(jsonb) to authenticated;

-- Ejecutar una vez en una base existente. Conserva IDs, relaciones e importes.
create sequence if not exists public.product_internal_code_seq;
revoke all on sequence public.product_internal_code_seq from public, anon, authenticated;
create or replace function public.assign_product_internal_code()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare v_number text;
begin
  if new.sku = 'AUTO' or new.sku ~ '^EXCEL-[0-9]+$' then
    loop
      v_number := nextval('public.product_internal_code_seq'::regclass)::text;
      new.sku := 'PRD-' || lpad(v_number, greatest(6, length(v_number)), '0');
      exit when not exists(select 1 from public.products where tenant_id = new.tenant_id and sku = new.sku);
    end loop;
  end if;
  return new;
end;
$$;
revoke all on function public.assign_product_internal_code() from public, anon, authenticated;
drop trigger if exists assign_product_internal_code on public.products;
create trigger assign_product_internal_code before insert or update of sku on public.products
for each row execute function public.assign_product_internal_code();
update public.products set sku = sku where sku ~ '^EXCEL-[0-9]+$';

revoke execute on function public.import_product_catalog(jsonb) from authenticated;

-- Códigos estables de pedidos
-- Ejecutar una vez desde SQL Editor antes de desplegar esta versión.
-- Reejecutable: conserva códigos, IDs, importes y stock.
begin;
lock table public.sales in share row exclusive mode;
alter table public.sales add column if not exists order_code text;
create sequence if not exists public.order_internal_code_seq;
revoke all on sequence public.order_internal_code_seq from public, anon, authenticated;
create or replace function public.assign_order_internal_code()
returns trigger language plpgsql security definer set search_path = '' as $$
declare v_number text;
begin
  if tg_op = 'UPDATE' and old.order_code is not null then
    if new.order_code is distinct from old.order_code then
      raise exception 'El código de pedido no se puede modificar.';
    end if;
    return new;
  end if;
  if new.channel = 'orders' then
    v_number := nextval('public.order_internal_code_seq'::regclass)::text;
    new.order_code := 'PED-' || lpad(v_number, greatest(6, length(v_number)), '0');
  else
    new.order_code := null;
  end if;
  return new;
end;
$$;
revoke all on function public.assign_order_internal_code() from public, anon, authenticated;
drop trigger if exists assign_order_internal_code on public.sales;
create trigger assign_order_internal_code before insert or update of order_code on public.sales
for each row execute function public.assign_order_internal_code();
do $$
declare v_id uuid;
begin
  for v_id in select id from public.sales where channel = 'orders' and order_code is null order by created_at, id loop
    update public.sales set order_code = null where id = v_id;
  end loop;
end;
$$;
create unique index if not exists sales_order_code_unique on public.sales(order_code) where order_code is not null;
do $$ begin
  if not exists(select 1 from pg_constraint where conrelid='public.sales'::regclass and conname='sales_order_code_valid') then
    alter table public.sales add constraint sales_order_code_valid check (
      (channel='orders' and order_code is not null and order_code ~ '^PED-[0-9]{6,}$') or
      (channel='retail' and order_code is null)
    );
  end if;
end $$;

create or replace function public.sale_detail(p_sale_id uuid)
returns jsonb
language sql
stable
security invoker
set search_path = ''
as $$
  with selected_sale as (
    select s.* from public.sales s where s.id = p_sale_id and s.tenant_id = public.current_tenant_id()
  ), line_rows as (
    select i.*, (i.quantity::bigint * i.price_cents) as sales_cents,
           (i.quantity::bigint * i.cost_cents) as cost_total_cents
    from public.sale_items i join selected_sale s on s.tenant_id = i.tenant_id and s.id = i.sale_id
  ), totals as (
    select coalesce(sum(sales_cents), 0) sales_cents, coalesce(sum(cost_total_cents), 0) cost_total_cents from line_rows
  )
  select case when s.id is null then null else jsonb_build_object(
    'sale', jsonb_build_object(
      'id', s.id, 'orderCode', s.order_code, 'channel', s.channel, 'payment', s.payment, 'customer', s.customer,
      'scheduledFor', s.scheduled_for, 'createdAt', s.created_at, 'recognizedAt', s.recognized_at,
      'status', s.status, 'salesCents', t.sales_cents, 'costTotalCents', t.cost_total_cents,
      'grossCents', t.sales_cents - t.cost_total_cents
    ),
    'items', coalesce((select jsonb_agg(jsonb_build_object(
      'productId', l.product_id, 'name', l.product_name, 'quantity', l.quantity,
      'priceCents', l.price_cents, 'costCents', l.cost_cents, 'salesCents', l.sales_cents,
      'costTotalCents', l.cost_total_cents, 'grossCents', l.sales_cents - l.cost_total_cents
    ) order by l.product_name) from line_rows l), '[]'::jsonb)
  ) end
  from selected_sale s cross join totals t
$$;

commit;
-- Ejecutar en Supabase → SQL Editor. Conserva productos, stock e historial.
begin;
alter table public.products add column if not exists deleted_at timestamptz;
create or replace view public.product_catalog with (security_invoker = true) as
select p.id, p.tenant_id, p.sku, p.name, p.price_cents, p.cost_cents, p.active,
  coalesce(r.quantity, 0) as retail_stock, coalesce(o.quantity, 0) as orders_stock,
  case when p.sku ~ '^PRD-[0-9]+$' then substring(p.sku from 5)::numeric else null end as code_number
from public.products p
left join public.inventory r on r.tenant_id = p.tenant_id and r.product_id = p.id and r.channel = 'retail'
left join public.inventory o on o.tenant_id = p.tenant_id and o.product_id = p.id and o.channel = 'orders'
where p.deleted_at is null;
revoke all on public.product_catalog from public, anon;
grant select on public.product_catalog to authenticated;
create or replace function public.delete_product(p_product_id uuid)
returns void language plpgsql security definer set search_path = '' as $$
declare
  v_tenant uuid := public.current_tenant_id();
  v_actor uuid := auth.uid();
  v_product public.products%rowtype;
  v_inv record;
begin
  if v_tenant is null or v_actor is null then raise exception 'Inicia sesión para continuar.'; end if;
  select * into v_product from public.products where tenant_id = v_tenant and id = p_product_id for update;
  if not found then raise exception 'Producto no encontrado.'; end if;
  if v_product.deleted_at is not null then return; end if;
  perform 1 from public.inventory where tenant_id = v_tenant and product_id = p_product_id order by channel for update;
  if exists(select 1 from public.sale_items i join public.sales s on s.tenant_id = i.tenant_id and s.id = i.sale_id
    where i.tenant_id = v_tenant and i.product_id = p_product_id and s.status = 'pending') then
    raise exception 'No se puede borrar un producto con pedidos pendientes. Entrega o anula esos pedidos primero.';
  end if;
  for v_inv in select channel, quantity from public.inventory where tenant_id = v_tenant and product_id = p_product_id and quantity <> 0 order by channel loop
    update public.inventory set quantity = 0
      where tenant_id = v_tenant and product_id = p_product_id and channel = v_inv.channel;
    insert into public.inventory_movements(tenant_id, product_id, channel, delta, reason, created_by)
      values (v_tenant, p_product_id, v_inv.channel, -v_inv.quantity, 'Baja por eliminación de producto', v_actor);
  end loop;
  update public.products set deleted_at = now(), active = false where tenant_id = v_tenant and id = p_product_id;
end;
$$;
revoke all on function public.delete_product(uuid) from public, anon;
grant execute on function public.delete_product(uuid) to authenticated;
-- Impide reactivar o ajustar existencias de un producto retirado usando RPC antiguos.
create or replace function public.protect_deleted_product() returns trigger
language plpgsql security definer set search_path = '' as $$
begin
  if old.deleted_at is not null then raise exception 'Este producto fue retirado del catálogo.'; end if;
  return new;
end;
$$;
revoke all on function public.protect_deleted_product() from public, anon, authenticated;
drop trigger if exists protect_deleted_product on public.products;
create trigger protect_deleted_product before update on public.products for each row execute function public.protect_deleted_product();
create or replace function public.protect_deleted_inventory() returns trigger
language plpgsql security definer set search_path = '' as $$
begin
  if exists(select 1 from public.products where tenant_id = new.tenant_id and id = new.product_id and deleted_at is not null) then
    raise exception 'Este producto fue retirado del catálogo.';
  end if;
  return new;
end;
$$;
revoke all on function public.protect_deleted_inventory() from public, anon, authenticated;
drop trigger if exists protect_deleted_inventory on public.inventory;
create trigger protect_deleted_inventory before insert or update on public.inventory for each row execute function public.protect_deleted_inventory();
commit;

-- Categorías, subcategorías, colores y tallas de productos
-- Ejecutar una vez en Supabase → SQL Editor. Conserva productos, stock e historial.
begin;
alter table public.products add column if not exists category varchar(60) not null default '' check (length(trim(category)) <= 60);
alter table public.products add column if not exists subcategory varchar(60) not null default '' check (length(trim(subcategory)) <= 60);
alter table public.products add column if not exists color varchar(80) not null default '' check (length(trim(color)) <= 80);
alter table public.products add column if not exists size varchar(60) not null default '' check (length(trim(size)) <= 60);

drop view if exists public.product_catalog;
create view public.product_catalog with (security_invoker = true) as
select p.id, p.tenant_id, p.sku, p.category, p.subcategory, p.color, p.name, p.size, p.price_cents, p.cost_cents, p.active,
  coalesce(r.quantity, 0) as retail_stock, coalesce(o.quantity, 0) as orders_stock,
  case when p.sku ~ '^PRD-[0-9]+$' then substring(p.sku from 5)::numeric else null end as code_number
from public.products p
left join public.inventory r on r.tenant_id = p.tenant_id and r.product_id = p.id and r.channel = 'retail'
left join public.inventory o on o.tenant_id = p.tenant_id and o.product_id = p.id and o.channel = 'orders'
where p.deleted_at is null;
revoke all on public.product_catalog from public, anon;
grant select on public.product_catalog to authenticated;

create or replace function public.create_product(p_input jsonb)
returns uuid
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_tenant uuid := public.current_tenant_id();
  v_actor uuid := auth.uid();
  v_product uuid := gen_random_uuid();
  v_category text := trim(coalesce(p_input->>'category', ''));
  v_subcategory text := trim(coalesce(p_input->>'subcategory', ''));
  v_color text := trim(coalesce(p_input->>'color', ''));
  v_name text := trim(coalesce(p_input->>'name', ''));
  v_size text := trim(coalesce(p_input->>'size', ''));
  v_channel text;
  v_quantity integer;
begin
  if v_tenant is null or v_actor is null then raise exception 'Inicia sesión para continuar.'; end if;
  if length(trim(coalesce(p_input->>'sku', ''))) not between 1 and 40
    or length(v_category) > 60
    or length(v_subcategory) > 60
    or length(v_color) > 80
    or length(v_name) not between 2 and 120
    or length(v_size) > 60
    or (p_input->>'priceCents')::bigint not between 0 and 100000000
    or (p_input->>'costCents')::bigint not between 0 and 100000000
    or (p_input->>'retailStock')::integer not between 0 and 1000000
    or (p_input->>'ordersStock')::integer not between 0 and 1000000 then
    raise exception 'Datos de producto inválidos.';
  end if;
  insert into public.products(id, tenant_id, sku, category, subcategory, color, name, size, price_cents, cost_cents)
  values (v_product, v_tenant, trim(p_input->>'sku'), v_category, v_subcategory, v_color, v_name, v_size, (p_input->>'priceCents')::bigint, (p_input->>'costCents')::bigint);
  foreach v_channel in array array['retail', 'orders'] loop
    v_quantity := case when v_channel = 'retail' then (p_input->>'retailStock')::integer else (p_input->>'ordersStock')::integer end;
    insert into public.inventory(tenant_id, product_id, channel, quantity) values (v_tenant, v_product, v_channel, v_quantity);
    if v_quantity > 0 then
      insert into public.inventory_movements(tenant_id, product_id, channel, delta, reason, created_by)
      values (v_tenant, v_product, v_channel, v_quantity, 'Stock inicial', v_actor);
    end if;
  end loop;
  return v_product;
end;
$$;

create or replace function public.update_product(p_product_id uuid, p_input jsonb)
returns uuid
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_tenant uuid := public.current_tenant_id();
  v_category text := trim(coalesce(p_input->>'category', ''));
  v_subcategory text := trim(coalesce(p_input->>'subcategory', ''));
  v_color text := trim(coalesce(p_input->>'color', ''));
  v_name text := trim(coalesce(p_input->>'name', ''));
  v_size text := trim(coalesce(p_input->>'size', ''));
  v_id uuid;
begin
  if length(trim(coalesce(p_input->>'sku', ''))) not between 1 and 40
    or length(v_category) > 60
    or length(v_subcategory) > 60
    or length(v_color) > 80
    or length(v_name) not between 2 and 120
    or length(v_size) > 60
    or (p_input->>'priceCents')::bigint not between 0 and 100000000
    or (p_input->>'costCents')::bigint not between 0 and 100000000
    or p_input->'active' is null or jsonb_typeof(p_input->'active') <> 'boolean' then
    raise exception 'Datos de producto inválidos.';
  end if;
  update public.products set sku = trim(p_input->>'sku'), category = v_category, subcategory = v_subcategory, color = v_color, name = v_name, size = v_size,
    price_cents = (p_input->>'priceCents')::bigint, cost_cents = (p_input->>'costCents')::bigint,
    active = (p_input->>'active')::boolean
  where tenant_id = v_tenant and id = p_product_id returning id into v_id;
  if v_id is null then raise exception 'Producto no encontrado.'; end if;
  return v_id;
end;
$$;

revoke all on function public.create_product(jsonb), public.update_product(uuid, jsonb) from public, anon;
grant execute on function public.create_product(jsonb), public.update_product(uuid, jsonb) to authenticated;
commit;
-- Ejecutar una vez en el proyecto Supabase del ERP. No reinstalar schema.sql.
begin;
create table if not exists public.quotation_counters (
 tenant_id uuid not null references public.tenants(id), brand text not null, last_number bigint not null,
 primary key(tenant_id,brand));
create table if not exists public.quotations (
 id uuid primary key default gen_random_uuid(), tenant_id uuid not null references public.tenants(id),
 number bigint not null, brand text not null check(brand in ('reypro','juflex','premium')),
 customer varchar(120) not null, ruc varchar(11) not null default '', address varchar(250) not null default '',
 quote_date date not null, tax_included boolean not null, items jsonb not null,
 total_cents bigint not null, subtotal_cents bigint not null, tax_cents bigint not null,
 version integer not null default 1, sale_id uuid, archived_at timestamptz,
 created_at timestamptz not null default now(), created_by uuid not null,
 unique(tenant_id,id), unique(tenant_id,brand,number),
 foreign key(tenant_id,created_by) references public.users(tenant_id,id),
 foreign key(tenant_id,sale_id) references public.sales(tenant_id,id));
create index if not exists quotations_tenant_date_idx on public.quotations(tenant_id,created_at desc,id);
create table if not exists public.quotation_operations (
 tenant_id uuid not null references public.tenants(id), request_key uuid not null, payload jsonb not null,
 result jsonb not null, primary key(tenant_id,request_key));
alter table public.quotations enable row level security;
alter table public.quotations force row level security;
alter table public.quotation_counters enable row level security;
alter table public.quotation_counters force row level security;
alter table public.quotation_operations enable row level security;
alter table public.quotation_operations force row level security;
drop policy if exists quotations_read on public.quotations;
create policy quotations_read on public.quotations for select to authenticated using(tenant_id=public.current_tenant_id());
revoke all on public.quotations,public.quotation_counters,public.quotation_operations from public,anon,authenticated;
grant select on public.quotations to authenticated;
create or replace function public.save_quotation(p_id uuid,p_input jsonb,p_version integer,p_key uuid)
returns jsonb language plpgsql security definer set search_path='' as $$
declare t uuid:=public.current_tenant_id(); a uuid:=auth.uid(); q public.quotations%rowtype;
 op public.quotation_operations%rowtype; payload jsonb:=jsonb_build_object('id',p_id,'input',p_input,'version',p_version);
 it jsonb; field text; total bigint:=0; subtotal bigint:=0; n bigint; result jsonb;
begin
 if t is null or a is null then raise exception 'Inicia sesión para continuar.'; end if;
 if p_key is null then raise exception 'Falta la clave de guardado.'; end if;
 perform pg_advisory_xact_lock(hashtextextended(t::text||':quotation:'||p_key::text,0));
 select * into op from public.quotation_operations where tenant_id=t and request_key=p_key;
 if found then if op.payload<>payload then raise exception 'Clave de guardado reutilizada.'; end if; return op.result; end if;
 if coalesce(p_input->>'brand','') not in ('reypro','juflex','premium')
 or length(trim(coalesce(p_input->>'customer',''))) not between 1 and 120
 or length(coalesce(p_input->>'address',''))>250 or coalesce(p_input->>'ruc','') !~ '^(\d{11})?$'
 or jsonb_typeof(p_input->'taxIncluded') is distinct from 'boolean'
 or coalesce(p_input->>'date','') !~ '^\d{4}-\d{2}-\d{2}$' then raise exception 'Datos de cotización inválidos.'; end if;
 if jsonb_typeof(p_input->'items') is distinct from 'array' then raise exception 'Agrega productos.'; end if;
 if jsonb_array_length(p_input->'items') not between 1 and 100 then raise exception 'Agrega entre 1 y 100 artículos.'; end if;
 for it in select value from jsonb_array_elements(p_input->'items') loop
  if nullif(it->>'id','') is null then raise exception 'Identificador de artículo inválido.'; end if;
  perform (it->>'id')::uuid;
  if jsonb_typeof(it->'name') is distinct from 'string' or length(trim(coalesce(it->>'name',''))) not between 2 and 120 then raise exception 'Nombre de artículo inválido.'; end if;
  foreach field in array array['quantity','priceCents','costCents'] loop
   if jsonb_typeof(it->field) is distinct from 'number' then raise exception 'Cantidad, precio o costo inválido.'; end if;
   if coalesce(it->>field,'') !~ '^\d+$' or (it->>field)::numeric > (case when field='quantity' then 100000 else 100000000 end) then raise exception 'Cantidad, precio o costo inválido.'; end if;
  end loop;
  if (it->>'quantity')::int<1 then raise exception 'La cantidad debe ser mayor que cero.'; end if;
  if nullif(it->>'productId','') is not null and not exists(select 1 from public.products where tenant_id=t and id=(it->>'productId')::uuid and active) then raise exception 'Un producto no está disponible en tu empresa.'; end if;
  total:=total+(it->>'quantity')::bigint*(it->>'priceCents')::bigint;
  subtotal:=subtotal+(it->>'quantity')::bigint*case when (p_input->>'taxIncluded')::boolean then round((it->>'priceCents')::numeric*100/118)::bigint else (it->>'priceCents')::bigint end;
 end loop;
 if p_id is null then
  insert into public.quotation_counters(tenant_id,brand,last_number) values(t,p_input->>'brand',1)
  on conflict(tenant_id,brand) do update set last_number=public.quotation_counters.last_number+1 returning last_number into n;
  insert into public.quotations(tenant_id,number,brand,customer,quote_date,tax_included,items,total_cents,subtotal_cents,tax_cents,created_by)
  values(t,n,p_input->>'brand',trim(p_input->>'customer'),(p_input->>'date')::date,(p_input->>'taxIncluded')::boolean,p_input->'items',total,subtotal,total-subtotal,a) returning * into q;
 else
  select * into q from public.quotations where tenant_id=t and id=p_id for update;
  if not found or q.archived_at is not null then raise exception 'Cotización no encontrada.'; end if;
  if q.sale_id is not null then raise exception 'La cotización ya generó un pedido. Duplica para reformular.'; end if;
  if q.version<>p_version then raise exception 'Otra sesión modificó esta cotización. Vuelve a abrirla.'; end if;
  if q.brand<>p_input->>'brand' then raise exception 'Duplica para cambiar de empresa sin sobrescribir el original.'; end if;
 end if;
 update public.quotations set customer=trim(p_input->>'customer'),ruc=coalesce(p_input->>'ruc',''),address=coalesce(p_input->>'address',''),
 quote_date=(p_input->>'date')::date,tax_included=(p_input->>'taxIncluded')::boolean,items=p_input->'items',total_cents=total,subtotal_cents=subtotal,tax_cents=total-subtotal,
 version=case when p_id is null then 1 else version+1 end where tenant_id=t and id=q.id returning to_jsonb(quotations.*) into result;
 insert into public.quotation_operations values(t,p_key,payload,result);
 return result;
end; $$;
create or replace function public.convert_quotation(p_id uuid,p_version integer,p_payment text,p_delivery date)
returns uuid language plpgsql security definer set search_path='' as $$
declare t uuid:=public.current_tenant_id(); q public.quotations%rowtype; it jsonb; product uuid; list jsonb:='[]'; result jsonb; sale uuid; names jsonb:='{}';
begin
 if t is null or auth.uid() is null then raise exception 'Inicia sesión para continuar.'; end if;
 select * into q from public.quotations where tenant_id=t and id=p_id for update;
 if not found or q.archived_at is not null then raise exception 'Cotización no encontrada.'; end if;
 if q.sale_id is not null then return q.sale_id; end if;
 if q.version<>p_version then raise exception 'La cotización cambió. Vuelve a abrirla.'; end if;
 if p_payment not in ('cash','yape','plin','transfer') or p_payment is null then raise exception 'Método de pago inválido.'; end if;
 for it in select value from jsonb_array_elements(q.items) loop
  product:=nullif(it->>'productId','')::uuid;
  if product is null then
   product:=public.create_product(jsonb_build_object('sku','AUTO','name',it->>'name','priceCents',it->'priceCents','costCents',it->'costCents','retailStock',0,'ordersStock',0));
  end if;
  if exists(select 1 from jsonb_array_elements(list) x where x->>'productId'=product::text) then raise exception 'El mismo producto aparece más de una vez. Unifica sus cantidades antes de generar el pedido.'; end if;
  list:=list||jsonb_build_array(jsonb_build_object('productId',product,'quantity',it->'quantity','priceCents',it->'priceCents','costCents',it->'costCents'));
  names:=names||jsonb_build_object(product::text,it->>'name');
 end loop;
 result:=public.create_sale(jsonb_build_object('channel','orders','customer',q.customer,'payment',p_payment,'scheduledFor',p_delivery,'items',list),q.id);
 sale:=(result->'sale'->>'id')::uuid;
 update public.sale_items set product_name=names->>product_id::text where tenant_id=t and sale_id=sale;
 update public.quotations set sale_id=sale where tenant_id=t and id=q.id;
 return sale;
end; $$;
create or replace function public.archive_quotation(p_id uuid) returns void language plpgsql security definer set search_path='' as $$
begin
 if public.current_tenant_id() is null then raise exception 'Inicia sesión para continuar.'; end if;
 update public.quotations set archived_at=now() where tenant_id=public.current_tenant_id() and id=p_id and sale_id is null;
 if not found then raise exception 'La cotización no existe o ya está vinculada a un pedido.'; end if;
end; $$;
revoke all on function public.save_quotation(uuid,jsonb,integer,uuid),public.convert_quotation(uuid,integer,text,date),public.archive_quotation(uuid) from public,anon;
grant execute on function public.save_quotation(uuid,jsonb,integer,uuid),public.convert_quotation(uuid,integer,text,date),public.archive_quotation(uuid) to authenticated;
commit;
