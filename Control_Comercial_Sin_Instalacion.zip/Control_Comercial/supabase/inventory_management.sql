-- Ejecutar en Supabase → SQL Editor. Conserva productos, stock e historial.
begin;
alter table public.products add column if not exists deleted_at timestamptz;
create or replace view public.product_catalog with (security_invoker = true) as
select p.id, p.tenant_id, p.sku, p.name, p.price_cents, p.cost_cents, p.active,
  coalesce(r.quantity, 0) as retail_stock, coalesce(o.quantity, 0) as orders_stock,
  case when p.sku ~ '^PRD-[0-9]+$' then substring(p.sku from 5)::numeric else null end as code_number
from public.products p
left join public.inventory r on r.tenant_id = p.tenant_id and r.product_id = p.id and r.channel = 'retail'
left join public.inventory o on o.tenant_id = p.tenant_id and o.product_id = p.id and o.channel = 'orders'
where p.deleted_at is null;
revoke all on public.product_catalog from public, anon;
grant select on public.product_catalog to authenticated;
create or replace function public.delete_product(p_product_id uuid)
returns void language plpgsql security definer set search_path = '' as $$
declare
  v_tenant uuid := public.current_tenant_id();
  v_actor uuid := auth.uid();
  v_product public.products%rowtype;
  v_inv record;
begin
  if v_tenant is null or v_actor is null then raise exception 'Inicia sesión para continuar.'; end if;
  select * into v_product from public.products where tenant_id = v_tenant and id = p_product_id for update;
  if not found then raise exception 'Producto no encontrado.'; end if;
  if v_product.deleted_at is not null then return; end if;
  perform 1 from public.inventory where tenant_id = v_tenant and product_id = p_product_id order by channel for update;
  if exists(select 1 from public.sale_items i join public.sales s on s.tenant_id = i.tenant_id and s.id = i.sale_id
    where i.tenant_id = v_tenant and i.product_id = p_product_id and s.status = 'pending') then
    raise exception 'No se puede borrar un producto con pedidos pendientes. Entrega o anula esos pedidos primero.';
  end if;
  for v_inv in select channel, quantity from public.inventory where tenant_id = v_tenant and product_id = p_product_id and quantity <> 0 order by channel loop
    update public.inventory set quantity = 0
      where tenant_id = v_tenant and product_id = p_product_id and channel = v_inv.channel;
    insert into public.inventory_movements(tenant_id, product_id, channel, delta, reason, created_by)
      values (v_tenant, p_product_id, v_inv.channel, -v_inv.quantity, 'Baja por eliminación de producto', v_actor);
  end loop;
  update public.products set deleted_at = now(), active = false where tenant_id = v_tenant and id = p_product_id;
end;
$$;
revoke all on function public.delete_product(uuid) from public, anon;
grant execute on function public.delete_product(uuid) to authenticated;
-- Impide reactivar o ajustar existencias de un producto retirado usando RPC antiguos.
create or replace function public.protect_deleted_product() returns trigger
language plpgsql security definer set search_path = '' as $$
begin
  if old.deleted_at is not null then raise exception 'Este producto fue retirado del catálogo.'; end if;
  return new;
end;
$$;
revoke all on function public.protect_deleted_product() from public, anon, authenticated;
drop trigger if exists protect_deleted_product on public.products;
create trigger protect_deleted_product before update on public.products for each row execute function public.protect_deleted_product();
create or replace function public.protect_deleted_inventory() returns trigger
language plpgsql security definer set search_path = '' as $$
begin
  if exists(select 1 from public.products where tenant_id = new.tenant_id and id = new.product_id and deleted_at is not null) then
    raise exception 'Este producto fue retirado del catálogo.';
  end if;
  return new;
end;
$$;
revoke all on function public.protect_deleted_inventory() from public, anon, authenticated;
drop trigger if exists protect_deleted_inventory on public.inventory;
create trigger protect_deleted_inventory before insert or update on public.inventory for each row execute function public.protect_deleted_inventory();
commit;
