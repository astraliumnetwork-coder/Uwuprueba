-- Ejecutar una vez en el proyecto Supabase del ERP. No reinstalar schema.sql.
begin;
create table if not exists public.quotation_counters (
 tenant_id uuid not null references public.tenants(id), brand text not null, last_number bigint not null,
 primary key(tenant_id,brand));
create table if not exists public.quotations (
 id uuid primary key default gen_random_uuid(), tenant_id uuid not null references public.tenants(id),
 number bigint not null, brand text not null check(brand in ('reypro','juflex','premium')),
 customer varchar(120) not null, ruc varchar(11) not null default '', address varchar(250) not null default '',
 quote_date date not null, tax_included boolean not null, items jsonb not null,
 total_cents bigint not null, subtotal_cents bigint not null, tax_cents bigint not null,
 version integer not null default 1, sale_id uuid, archived_at timestamptz,
 created_at timestamptz not null default now(), created_by uuid not null,
 unique(tenant_id,id), unique(tenant_id,brand,number),
 foreign key(tenant_id,created_by) references public.users(tenant_id,id),
 foreign key(tenant_id,sale_id) references public.sales(tenant_id,id));
create index if not exists quotations_tenant_date_idx on public.quotations(tenant_id,created_at desc,id);
create table if not exists public.quotation_operations (
 tenant_id uuid not null references public.tenants(id), request_key uuid not null, payload jsonb not null,
 result jsonb not null, primary key(tenant_id,request_key));
alter table public.quotations enable row level security;
alter table public.quotations force row level security;
alter table public.quotation_counters enable row level security;
alter table public.quotation_counters force row level security;
alter table public.quotation_operations enable row level security;
alter table public.quotation_operations force row level security;
drop policy if exists quotations_read on public.quotations;
create policy quotations_read on public.quotations for select to authenticated using(tenant_id=public.current_tenant_id());
revoke all on public.quotations,public.quotation_counters,public.quotation_operations from public,anon,authenticated;
grant select on public.quotations to authenticated;
create or replace function public.save_quotation(p_id uuid,p_input jsonb,p_version integer,p_key uuid)
returns jsonb language plpgsql security definer set search_path='' as $$
declare t uuid:=public.current_tenant_id(); a uuid:=auth.uid(); q public.quotations%rowtype;
 op public.quotation_operations%rowtype; payload jsonb:=jsonb_build_object('id',p_id,'input',p_input,'version',p_version);
 it jsonb; field text; total bigint:=0; subtotal bigint:=0; n bigint; result jsonb;
begin
 if t is null or a is null then raise exception 'Inicia sesión para continuar.'; end if;
 if p_key is null then raise exception 'Falta la clave de guardado.'; end if;
 perform pg_advisory_xact_lock(hashtextextended(t::text||':quotation:'||p_key::text,0));
 select * into op from public.quotation_operations where tenant_id=t and request_key=p_key;
 if found then if op.payload<>payload then raise exception 'Clave de guardado reutilizada.'; end if; return op.result; end if;
 if coalesce(p_input->>'brand','') not in ('reypro','juflex','premium')
 or length(trim(coalesce(p_input->>'customer',''))) not between 1 and 120
 or length(coalesce(p_input->>'address',''))>250 or coalesce(p_input->>'ruc','') !~ '^(\d{11})?$'
 or jsonb_typeof(p_input->'taxIncluded') is distinct from 'boolean'
 or coalesce(p_input->>'date','') !~ '^\d{4}-\d{2}-\d{2}$' then raise exception 'Datos de cotización inválidos.'; end if;
 if jsonb_typeof(p_input->'items') is distinct from 'array' then raise exception 'Agrega productos.'; end if;
 if jsonb_array_length(p_input->'items') not between 1 and 100 then raise exception 'Agrega entre 1 y 100 artículos.'; end if;
 for it in select value from jsonb_array_elements(p_input->'items') loop
  if nullif(it->>'id','') is null then raise exception 'Identificador de artículo inválido.'; end if;
  perform (it->>'id')::uuid;
  if jsonb_typeof(it->'name') is distinct from 'string' or length(trim(coalesce(it->>'name',''))) not between 2 and 120 then raise exception 'Nombre de artículo inválido.'; end if;
  foreach field in array array['quantity','priceCents','costCents'] loop
   if jsonb_typeof(it->field) is distinct from 'number' then raise exception 'Cantidad, precio o costo inválido.'; end if;
   if coalesce(it->>field,'') !~ '^\d+$' or (it->>field)::numeric > (case when field='quantity' then 100000 else 100000000 end) then raise exception 'Cantidad, precio o costo inválido.'; end if;
  end loop;
  if (it->>'quantity')::int<1 then raise exception 'La cantidad debe ser mayor que cero.'; end if;
  if nullif(it->>'productId','') is not null and not exists(select 1 from public.products where tenant_id=t and id=(it->>'productId')::uuid and active) then raise exception 'Un producto no está disponible en tu empresa.'; end if;
  total:=total+(it->>'quantity')::bigint*(it->>'priceCents')::bigint;
  subtotal:=subtotal+(it->>'quantity')::bigint*case when (p_input->>'taxIncluded')::boolean then round((it->>'priceCents')::numeric*100/118)::bigint else (it->>'priceCents')::bigint end;
 end loop;
 if p_id is null then
  insert into public.quotation_counters(tenant_id,brand,last_number) values(t,p_input->>'brand',1)
  on conflict(tenant_id,brand) do update set last_number=public.quotation_counters.last_number+1 returning last_number into n;
  insert into public.quotations(tenant_id,number,brand,customer,quote_date,tax_included,items,total_cents,subtotal_cents,tax_cents,created_by)
  values(t,n,p_input->>'brand',trim(p_input->>'customer'),(p_input->>'date')::date,(p_input->>'taxIncluded')::boolean,p_input->'items',total,subtotal,total-subtotal,a) returning * into q;
 else
  select * into q from public.quotations where tenant_id=t and id=p_id for update;
  if not found or q.archived_at is not null then raise exception 'Cotización no encontrada.'; end if;
  if q.sale_id is not null then raise exception 'La cotización ya generó un pedido. Duplica para reformular.'; end if;
  if q.version<>p_version then raise exception 'Otra sesión modificó esta cotización. Vuelve a abrirla.'; end if;
  if q.brand<>p_input->>'brand' then raise exception 'Duplica para cambiar de empresa sin sobrescribir el original.'; end if;
 end if;
 update public.quotations set customer=trim(p_input->>'customer'),ruc=coalesce(p_input->>'ruc',''),address=coalesce(p_input->>'address',''),
 quote_date=(p_input->>'date')::date,tax_included=(p_input->>'taxIncluded')::boolean,items=p_input->'items',total_cents=total,subtotal_cents=subtotal,tax_cents=total-subtotal,
 version=case when p_id is null then 1 else version+1 end where tenant_id=t and id=q.id returning to_jsonb(quotations.*) into result;
 insert into public.quotation_operations values(t,p_key,payload,result);
 return result;
end; $$;
create or replace function public.convert_quotation(p_id uuid,p_version integer,p_payment text,p_delivery date)
returns uuid language plpgsql security definer set search_path='' as $$
declare t uuid:=public.current_tenant_id(); q public.quotations%rowtype; it jsonb; product uuid; list jsonb:='[]'; result jsonb; sale uuid; names jsonb:='{}';
begin
 if t is null or auth.uid() is null then raise exception 'Inicia sesión para continuar.'; end if;
 select * into q from public.quotations where tenant_id=t and id=p_id for update;
 if not found or q.archived_at is not null then raise exception 'Cotización no encontrada.'; end if;
 if q.sale_id is not null then return q.sale_id; end if;
 if q.version<>p_version then raise exception 'La cotización cambió. Vuelve a abrirla.'; end if;
 if p_payment not in ('cash','yape','plin','transfer') or p_payment is null then raise exception 'Método de pago inválido.'; end if;
 for it in select value from jsonb_array_elements(q.items) loop
  product:=nullif(it->>'productId','')::uuid;
  if product is null then
   product:=public.create_product(jsonb_build_object('sku','AUTO','name',it->>'name','priceCents',it->'priceCents','costCents',it->'costCents','retailStock',0,'ordersStock',0));
  end if;
  if exists(select 1 from jsonb_array_elements(list) x where x->>'productId'=product::text) then raise exception 'El mismo producto aparece más de una vez. Unifica sus cantidades antes de generar el pedido.'; end if;
  list:=list||jsonb_build_array(jsonb_build_object('productId',product,'quantity',it->'quantity','priceCents',it->'priceCents','costCents',it->'costCents'));
  names:=names||jsonb_build_object(product::text,it->>'name');
 end loop;
 result:=public.create_sale(jsonb_build_object('channel','orders','customer',q.customer,'payment',p_payment,'scheduledFor',p_delivery,'items',list),q.id);
 sale:=(result->'sale'->>'id')::uuid;
 update public.sale_items set product_name=names->>product_id::text where tenant_id=t and sale_id=sale;
 update public.quotations set sale_id=sale where tenant_id=t and id=q.id;
 return sale;
end; $$;
create or replace function public.archive_quotation(p_id uuid) returns void language plpgsql security definer set search_path='' as $$
begin
 if public.current_tenant_id() is null then raise exception 'Inicia sesión para continuar.'; end if;
 update public.quotations set archived_at=now() where tenant_id=public.current_tenant_id() and id=p_id and sale_id is null;
 if not found then raise exception 'La cotización no existe o ya está vinculada a un pedido.'; end if;
end; $$;
revoke all on function public.save_quotation(uuid,jsonb,integer,uuid),public.convert_quotation(uuid,integer,text,date),public.archive_quotation(uuid) from public,anon;
grant execute on function public.save_quotation(uuid,jsonb,integer,uuid),public.convert_quotation(uuid,integer,text,date),public.archive_quotation(uuid) to authenticated;
commit;
