-- Ejecutar una vez en Supabase SQL Editor para actualizar una base existente.
begin;
create or replace function public.cancel_order(p_sale_id uuid, p_reason text)
returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_tenant uuid := public.current_tenant_id();
  v_actor uuid := auth.uid();
  v_sale public.sales%rowtype;
  v_item record;
begin
  if v_tenant is null or v_actor is null then raise exception 'Sesión no válida.'; end if;
  if length(trim(coalesce(p_reason, ''))) not between 3 and 200 then raise exception 'Indica el motivo de anulación.'; end if;
  -- El bloqueo serializa entrega/anulación y los reintentos de la misma venta.
  select * into v_sale from public.sales where tenant_id = v_tenant and id = p_sale_id for update;
  if not found then raise exception 'Venta no encontrada.'; end if;
  if v_sale.status = 'cancelled' then return jsonb_build_object('id', p_sale_id); end if;
  if v_sale.status = 'posted' then
    for v_item in select product_id, quantity from public.sale_items
      where tenant_id = v_tenant and sale_id = p_sale_id order by product_id loop
      update public.inventory set quantity = quantity + v_item.quantity
      where tenant_id = v_tenant and product_id = v_item.product_id and channel = v_sale.channel
        and quantity <= 1000000000 - v_item.quantity;
      if not found then raise exception 'No se puede restituir el stock. Revisa las existencias del producto.'; end if;
      insert into public.inventory_movements(tenant_id, product_id, channel, delta, reason, sale_id, created_by)
      values (v_tenant, v_item.product_id, v_sale.channel, v_item.quantity, 'Anulación: ' || left(trim(p_reason), 189), p_sale_id, v_actor);
    end loop;
  end if;
  update public.sales set status = 'cancelled', cancelled_at = now(), cancellation_reason = trim(p_reason)
  where tenant_id = v_tenant and id = p_sale_id;
  return jsonb_build_object('id', p_sale_id);
end;
$$;

revoke all on function public.cancel_order(uuid, text) from public, anon;
grant execute on function public.cancel_order(uuid, text) to authenticated;
commit;
