-- Ejecutar una vez en una base existente. Conserva IDs, relaciones e importes.
create sequence if not exists public.product_internal_code_seq;
revoke all on sequence public.product_internal_code_seq from public, anon, authenticated;
create or replace function public.assign_product_internal_code()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare v_number text;
begin
  if new.sku = 'AUTO' or new.sku ~ '^EXCEL-[0-9]+$' then
    loop
      v_number := nextval('public.product_internal_code_seq'::regclass)::text;
      new.sku := 'PRD-' || lpad(v_number, greatest(6, length(v_number)), '0');
      exit when not exists(select 1 from public.products where tenant_id = new.tenant_id and sku = new.sku);
    end loop;
  end if;
  return new;
end;
$$;
revoke all on function public.assign_product_internal_code() from public, anon, authenticated;
drop trigger if exists assign_product_internal_code on public.products;
create trigger assign_product_internal_code before insert or update of sku on public.products
for each row execute function public.assign_product_internal_code();
update public.products set sku = sku where sku ~ '^EXCEL-[0-9]+$';

revoke execute on function public.import_product_catalog(jsonb) from authenticated;
