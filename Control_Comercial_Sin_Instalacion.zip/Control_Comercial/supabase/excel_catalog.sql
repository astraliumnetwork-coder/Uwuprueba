-- Ejecutar una vez en SQL Editor para bases ya instaladas.
create or replace function public.import_product_catalog(p_items jsonb)
returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_tenant uuid := public.current_tenant_id();
  v_item jsonb;
  v_created integer := 0;
  v_skipped integer := 0;
begin
  if v_tenant is null or auth.uid() is null then raise exception 'Inicia sesión para continuar.'; end if;
  if jsonb_typeof(p_items) is distinct from 'array' then raise exception 'Catálogo inválido.'; end if;
  if jsonb_array_length(p_items) not between 1 and 500 then raise exception 'Selecciona entre 1 y 500 artículos.'; end if;
  -- Serializa reintentos y cargas concurrentes del mismo tenant.
  perform pg_advisory_xact_lock(hashtextextended(v_tenant::text, 0));
  for v_item in select value from jsonb_array_elements(p_items) loop
    if jsonb_typeof(v_item->'sku') is distinct from 'string'
      or jsonb_typeof(v_item->'name') is distinct from 'string'
      or jsonb_typeof(v_item->'priceCents') is distinct from 'number'
      or jsonb_typeof(v_item->'costCents') is distinct from 'number'
      or (v_item->>'priceCents') !~ '^[0-9]+$'
      or (v_item->>'costCents') !~ '^[0-9]+$' then
      raise exception 'Artículo inválido.';
    end if;
    if exists(select 1 from public.products where tenant_id = v_tenant and sku = trim(v_item->>'sku')) then
      v_skipped := v_skipped + 1;
    else
      perform public.create_product(jsonb_build_object(
        'sku', v_item->>'sku', 'name', v_item->>'name',
        'priceCents', v_item->'priceCents', 'costCents', v_item->'costCents',
        'retailStock', 0, 'ordersStock', 0
      ));
      v_created := v_created + 1;
    end if;
  end loop;
  return jsonb_build_object('created', v_created, 'skipped', v_skipped);
end;
$$;
revoke all on function public.import_product_catalog(jsonb) from public, anon;
grant execute on function public.import_product_catalog(jsonb) to authenticated;
