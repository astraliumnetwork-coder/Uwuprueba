import { createClient } from '@supabase/supabase-js';
import { createInterface } from 'node:readline/promises';
import { Writable } from 'node:stream';

let hidden = false;
const output = new Writable({
  write(chunk, encoding, done) {
    if (!hidden) process.stdout.write(chunk, encoding);
    done();
  },
});
const input = createInterface({ input: process.stdin, output, terminal: !!process.stdin.isTTY });
const EMAIL = 'admin@sistema.com';
const PASSWORD = 'admin123';
function checked(result) {
  if (result.error) throw new Error(result.error.message);
  return result;
}
try {
  const url =
    process.env.VITE_SUPABASE_URL || (await input.question('URL del proyecto Supabase: ')).trim();
  process.stdout.write(
    'Clave secret o service_role de Supabase (entrada oculta, solo para esta configuración): ',
  );
  hidden = true;
  const key = (await input.question('')).trim();
  hidden = false;
  process.stdout.write('\n');
  if (!url || !key) throw new Error('Faltan URL o clave administrativa.');
  const admin = createClient(url, key, {
    auth: { persistSession: false, autoRefreshToken: false },
  });
  const tenants = [];
  for (let offset = 0; ; offset += 100) {
    const { data } = checked(
      await admin
        .from('tenants')
        .select('id,name')
        .order('id')
        .range(offset, offset + 99),
    );
    tenants.push(...data);
    if (data.length < 100) break;
  }
  if (!tenants.length)
    throw new Error('No hay empresas existentes. Ejecuta primero el esquema del proyecto.');
  const options = await Promise.all(
    tenants.map(async (tenant) => {
      const { count: products } = checked(
        await admin
          .from('products')
          .select('id', { count: 'exact', head: true })
          .eq('tenant_id', tenant.id),
      );
      const { count: sales } = checked(
        await admin
          .from('sales')
          .select('id', { count: 'exact', head: true })
          .eq('tenant_id', tenant.id),
      );
      return { ...tenant, products, sales };
    }),
  );
  options.sort((a, b) => b.products - a.products);
  options.forEach((row, index) =>
    process.stdout.write(
      `${index + 1}. ${row.name} | ${row.products} productos | ${row.sales} operaciones | ${row.id}\n`,
    ),
  );
  const selection = Number(
    await input.question('Número de la empresa que contiene tu inventario: '),
  );
  const target = Number.isInteger(selection) ? options[selection - 1] : undefined;
  if (!target) throw new Error('Selección inválida; no se modificó ninguna cuenta.');

  let user;
  for (let page = 1; ; page++) {
    const { data } = checked(await admin.auth.admin.listUsers({ page, perPage: 100 }));
    user = data.users.find((entry) => entry.email?.toLowerCase() === EMAIL);
    if (user || data.users.length < 100) break;
  }
  if (!user) {
    const { data } = checked(
      await admin.auth.admin.createUser({
        email: EMAIL,
        password: PASSWORD,
        email_confirm: true,
        user_metadata: { organization_name: target.name },
      }),
    );
    user = data.user;
  }
  const profile = checked(
    await admin.from('users').select('tenant_id').eq('id', user.id).single(),
  ).data;
  if (profile.tenant_id !== target.id) {
    // Existing authored records must not be orphaned by moving their user to another tenant.
    for (const table of ['sales', 'expenses', 'inventory_movements']) {
      const { count } = checked(
        await admin
          .from(table)
          .select('id', { count: 'exact', head: true })
          .eq('created_by', user.id),
      );
      if (count)
        throw new Error(
          'Esta cuenta ya registró operaciones en otra empresa. No se cambió su empresa ni contraseña.',
        );
    }
    checked(
      await admin
        .from('users')
        .update({ tenant_id: target.id })
        .eq('id', user.id)
        .eq('tenant_id', profile.tenant_id)
        .select('id')
        .single(),
    );
  }
  checked(
    await admin.auth.admin.updateUserById(user.id, { password: PASSWORD, email_confirm: true }),
  );
  process.stdout.write(
    `Cuenta lista: ${EMAIL}\nEmpresa: ${target.name} (${target.id})\nUsa la contraseña solicitada para entrar desde localhost o Vercel.\n`,
  );
} catch (error) {
  hidden = false;
  process.stderr.write(`\nNo se completó la configuración: ${error.message}\n`);
  process.exitCode = 1;
} finally {
  input.close();
}
