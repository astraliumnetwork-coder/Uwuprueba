import { spawn, spawnSync } from 'node:child_process';
import { createReadStream, existsSync, statSync } from 'node:fs';
import { createServer } from 'node:http';
import { extname, isAbsolute, relative, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = resolve(fileURLToPath(new URL('..', import.meta.url)));
const domainConfig = resolve(root, 'packages/domain/tsconfig.json');
const typeScriptCli = resolve(root, 'node_modules/typescript/bin/tsc');
const viteCli = resolve(root, 'node_modules/vite/bin/vite.js');
const dist = resolve(root, 'dist');
const hasSourceTools = existsSync(typeScriptCli) && existsSync(viteCli);

if (hasSourceTools && process.env.SAAS_STATIC_PREVIEW !== '1') {
  const domainBuild = spawnSync(process.execPath, [typeScriptCli, '-p', domainConfig], {
    cwd: root,
    stdio: 'inherit',
  });

  if (domainBuild.status !== 0) process.exit(domainBuild.status ?? 1);

  const vite = spawn(process.execPath, [viteCli, '--force'], {
    cwd: root,
    stdio: 'inherit',
    env: process.env,
  });

  for (const signal of ['SIGINT', 'SIGTERM']) {
    process.on(signal, () => vite.kill(signal));
  }

  vite.on('exit', (code, signal) => {
    process.exitCode = code ?? (signal ? 1 : 0);
  });
} else if (existsSync(resolve(dist, 'index.html'))) {
  const mimeTypes = {
    '.css': 'text/css; charset=utf-8',
    '.html': 'text/html; charset=utf-8',
    '.ico': 'image/x-icon',
    '.jpg': 'image/jpeg',
    '.jpeg': 'image/jpeg',
    '.js': 'text/javascript; charset=utf-8',
    '.json': 'application/json; charset=utf-8',
    '.mjs': 'text/javascript; charset=utf-8',
    '.png': 'image/png',
    '.svg': 'image/svg+xml',
    '.ttf': 'font/ttf',
    '.woff': 'font/woff',
    '.woff2': 'font/woff2',
  };

  const server = createServer((request, response) => {
    let pathname;
    try {
      pathname = decodeURIComponent(new URL(request.url ?? '/', 'http://localhost').pathname);
    } catch {
      response.writeHead(400).end('Solicitud inválida');
      return;
    }

    let file = resolve(dist, `.${pathname}`);
    const relativeFile = relative(dist, file);
    if (relativeFile.startsWith('..') || isAbsolute(relativeFile)) {
      response.writeHead(403).end('Acceso denegado');
      return;
    }

    if (existsSync(file) && statSync(file).isDirectory()) file = resolve(file, 'index.html');
    if (
      !existsSync(file) &&
      !pathname.startsWith('/assets/') &&
      !pathname.startsWith('/quote-assets/')
    ) {
      file = resolve(dist, 'index.html');
    }

    if (!existsSync(file)) {
      response.writeHead(404).end('Archivo no encontrado');
      return;
    }

    response.writeHead(200, {
      'Cache-Control': 'no-cache',
      'Content-Type': mimeTypes[extname(file).toLowerCase()] ?? 'application/octet-stream',
      'X-Content-Type-Options': 'nosniff',
    });
    if (request.method === 'HEAD') response.end();
    else createReadStream(file).pipe(response);
  });

  const port = Number(process.env.PORT) || 5173;
  server.listen(port, '127.0.0.1', () => {
    console.log('No hay dependencias locales; se está mostrando la versión compilada de dist.');
    console.log(`Abre http://localhost:${port}/`);
    console.log(
      'Este modo sirve una vista previa. Para recompilar cambios se necesitan las dependencias.',
    );
  });
} else {
  console.error('No se encontraron Vite/TypeScript ni la carpeta dist/.');
  console.error(
    'Copia el proyecto completo con dist/ o instala las dependencias para compilar el código fuente.',
  );
  process.exitCode = 1;
}
